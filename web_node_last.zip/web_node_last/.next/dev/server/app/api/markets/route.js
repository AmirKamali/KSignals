var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/markets/route.js")
R.c("server/chunks/2374f_next_b424172e._.js")
R.c("server/chunks/[root-of-the-server]__24d8b1c5._.js")
R.c("server/chunks/web__next-internal_server_app_api_markets_route_actions_2f301b93.js")
R.m("[project]/web/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/web/app/api/markets/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/web/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/web/app/api/markets/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
