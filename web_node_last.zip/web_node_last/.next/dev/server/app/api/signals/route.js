var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/signals/route.js")
R.c("server/chunks/2374f_next_987a0a74._.js")
R.c("server/chunks/[root-of-the-server]__40f00bc0._.js")
R.c("server/chunks/web__next-internal_server_app_api_signals_route_actions_6bf31668.js")
R.m("[project]/web/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/web/app/api/signals/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/web/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/web/app/api/signals/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
