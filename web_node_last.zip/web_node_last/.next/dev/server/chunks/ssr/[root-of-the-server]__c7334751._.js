module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[project]/web/components/HeroSection.module.css [app-ssr] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "actions": "HeroSection-module__suLlPW__actions",
  "backgroundEffects": "HeroSection-module__suLlPW__backgroundEffects",
  "badge": "HeroSection-module__suLlPW__badge",
  "badgeDot": "HeroSection-module__suLlPW__badgeDot",
  "badgeText": "HeroSection-module__suLlPW__badgeText",
  "benefitsList": "HeroSection-module__suLlPW__benefitsList",
  "benefitsTitle": "HeroSection-module__suLlPW__benefitsTitle",
  "bulletList": "HeroSection-module__suLlPW__bulletList",
  "content": "HeroSection-module__suLlPW__content",
  "fadeInDown": "HeroSection-module__suLlPW__fadeInDown",
  "fadeInUp": "HeroSection-module__suLlPW__fadeInUp",
  "featureCard": "HeroSection-module__suLlPW__featureCard",
  "featureGrid": "HeroSection-module__suLlPW__featureGrid",
  "featurePanel": "HeroSection-module__suLlPW__featurePanel",
  "float": "HeroSection-module__suLlPW__float",
  "glowPrimary": "HeroSection-module__suLlPW__glowPrimary",
  "glowSecondary": "HeroSection-module__suLlPW__glowSecondary",
  "gridPattern": "HeroSection-module__suLlPW__gridPattern",
  "hero": "HeroSection-module__suLlPW__hero",
  "iconWrapper": "HeroSection-module__suLlPW__iconWrapper",
  "layout": "HeroSection-module__suLlPW__layout",
  "panelHeader": "HeroSection-module__suLlPW__panelHeader",
  "panelLabel": "HeroSection-module__suLlPW__panelLabel",
  "panelStatus": "HeroSection-module__suLlPW__panelStatus",
  "panelSubtext": "HeroSection-module__suLlPW__panelSubtext",
  "pulse": "HeroSection-module__suLlPW__pulse",
  "statusDot": "HeroSection-module__suLlPW__statusDot",
  "subtitle": "HeroSection-module__suLlPW__subtitle",
  "title": "HeroSection-module__suLlPW__title",
});
}),
"[project]/web/components/HeroSection.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HeroSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__ = __turbopack_context__.i("[project]/web/node_modules/lucide-react/dist/esm/icons/arrow-right.js [app-ssr] (ecmascript) <export default as ArrowRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/web/components/HeroSection.module.css [app-ssr] (css module)");
"use client";
;
;
;
function HeroSection() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].hero,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].backgroundEffects,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].gridPattern
                    }, void 0, false, {
                        fileName: "[project]/web/components/HeroSection.tsx",
                        lineNumber: 10,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].glowPrimary
                    }, void 0, false, {
                        fileName: "[project]/web/components/HeroSection.tsx",
                        lineNumber: 11,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].glowSecondary
                    }, void 0, false, {
                        fileName: "[project]/web/components/HeroSection.tsx",
                        lineNumber: 12,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/web/components/HeroSection.tsx",
                lineNumber: 9,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].layout,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].content,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].badge,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].badgeDot
                                    }, void 0, false, {
                                        fileName: "[project]/web/components/HeroSection.tsx",
                                        lineNumber: 19,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].badgeText,
                                        children: "Live Market Signals Active"
                                    }, void 0, false, {
                                        fileName: "[project]/web/components/HeroSection.tsx",
                                        lineNumber: 20,
                                        columnNumber: 29
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/web/components/HeroSection.tsx",
                                lineNumber: 18,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].title,
                                children: [
                                    "Trade on ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-gradient",
                                        children: "Real World"
                                    }, void 0, false, {
                                        fileName: "[project]/web/components/HeroSection.tsx",
                                        lineNumber: 24,
                                        columnNumber: 38
                                    }, this),
                                    " Events"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/web/components/HeroSection.tsx",
                                lineNumber: 23,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].subtitle,
                                children: "Access AI-powered insights and probability analysis for the first regulated exchange dedicated to trading event outcomes."
                            }, void 0, false, {
                                fileName: "[project]/web/components/HeroSection.tsx",
                                lineNumber: 27,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].actions,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: "btn btn-primary",
                                        children: [
                                            "Start Trading ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                                size: 18,
                                                style: {
                                                    marginLeft: "0.5rem"
                                                }
                                            }, void 0, false, {
                                                fileName: "[project]/web/components/HeroSection.tsx",
                                                lineNumber: 34,
                                                columnNumber: 47
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/web/components/HeroSection.tsx",
                                        lineNumber: 33,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: "btn btn-outline",
                                        children: "View All Markets"
                                    }, void 0, false, {
                                        fileName: "[project]/web/components/HeroSection.tsx",
                                        lineNumber: 36,
                                        columnNumber: 29
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/web/components/HeroSection.tsx",
                                lineNumber: 32,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/web/components/HeroSection.tsx",
                        lineNumber: 17,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/web/components/HeroSection.tsx",
                    lineNumber: 16,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/web/components/HeroSection.tsx",
                lineNumber: 15,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/web/components/HeroSection.tsx",
        lineNumber: 8,
        columnNumber: 9
    }, this);
}
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[project]/web/lib/data:9f0d06 [app-ssr] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"409071e25c2a92798fac6387e9301fdc81bce11cd4":"getSeriesByTags"},"web/lib/kalshi.ts",""] */ __turbopack_context__.s([
    "getSeriesByTags",
    ()=>getSeriesByTags
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
var getSeriesByTags = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("409071e25c2a92798fac6387e9301fdc81bce11cd4", __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "getSeriesByTags"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4va2Fsc2hpLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIHNlcnZlclwiO1xuXG5jb25zdCBCQVNFX1VSTCA9IFwiaHR0cHM6Ly9hcGkuZWxlY3Rpb25zLmthbHNoaS5jb20vdHJhZGUtYXBpL3YyXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgTWFya2V0IHtcbiAgICB0aWNrZXI6IHN0cmluZztcbiAgICBldmVudF90aWNrZXI6IHN0cmluZztcbiAgICB0aXRsZTogc3RyaW5nO1xuICAgIHN1YnRpdGxlPzogc3RyaW5nO1xuICAgIHllc19wcmljZTogbnVtYmVyO1xuICAgIHZvbHVtZTogbnVtYmVyO1xuICAgIG9wZW5faW50ZXJlc3Q6IG51bWJlcjtcbiAgICBsaXF1aWRpdHk6IG51bWJlcjtcbiAgICBzdGF0dXM6IHN0cmluZztcbiAgICBjYXRlZ29yeT86IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBNYXJrZXREZXRhaWwgZXh0ZW5kcyBNYXJrZXQge1xuICAgIGNhdGVnb3J5OiBzdHJpbmc7IC8vIE92ZXJyaWRlIGFzIHJlcXVpcmVkIGZvciBkZXRhaWxzXG4gICAgZXhwaXJhdGlvbl90aW1lOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgT3JkZXJCb29rIHtcbiAgICB5ZXM6IFtudW1iZXIsIG51bWJlcl1bXTtcbiAgICBubzogW251bWJlciwgbnVtYmVyXVtdO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFNlcmllcyB7XG4gICAgdGlja2VyOiBzdHJpbmc7XG4gICAgZnJlcXVlbmN5OiBzdHJpbmc7XG4gICAgdGl0bGU6IHN0cmluZztcbiAgICBjYXRlZ29yeTogc3RyaW5nO1xuICAgIHRhZ3M6IHN0cmluZ1tdO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0SGlnaFZvbHVtZU1hcmtldHMobGltaXQgPSAxMDAsIG1heENyZWF0ZWRUcz86IG51bWJlcik6IFByb21pc2U8TWFya2V0W10+IHtcbiAgICB0cnkge1xuICAgICAgICBsZXQgdXJsID0gYCR7QkFTRV9VUkx9L21hcmtldHM/bGltaXQ9JHtsaW1pdH0mc3RhdHVzPW9wZW5gO1xuICAgICAgICBpZiAobWF4Q3JlYXRlZFRzKSB7XG4gICAgICAgICAgICB1cmwgKz0gYCZtYXhfY3JlYXRlZF90cz0ke21heENyZWF0ZWRUc31gO1xuICAgICAgICB9XG4gICAgICAgIFxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKHVybCwge1xuICAgICAgICAgICAgbmV4dDogeyByZXZhbGlkYXRlOiA2MCB9LFxuICAgICAgICB9KTtcblxuICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggbWFya2V0c1wiKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIGxldCBtYXJrZXRzOiBNYXJrZXRbXSA9IGRhdGEubWFya2V0cyB8fCBbXTtcblxuICAgICAgICAvLyBBc3NpZ24gY2F0ZWdvcmllcyBoZXVyaXN0aWNhbGx5IHNpbmNlIEFQSSByZXR1cm5zIGVtcHR5IHN0cmluZ1xuICAgICAgICBtYXJrZXRzID0gbWFya2V0cy5tYXAobSA9PiAoe1xuICAgICAgICAgICAgLi4ubSxcbiAgICAgICAgICAgIGNhdGVnb3J5OiBhc3NpZ25DYXRlZ29yeShtKVxuICAgICAgICB9KSk7XG5cbiAgICAgICAgcmV0dXJuIG1hcmtldHNcbiAgICAgICAgICAgIC5zb3J0KChhLCBiKSA9PiBiLnZvbHVtZSAtIGEudm9sdW1lKVxuICAgICAgICAgICAgLnNsaWNlKDAsIGxpbWl0KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgaGlnaCB2b2x1bWUgbWFya2V0czpcIiwgZXJyb3IpO1xuICAgICAgICByZXR1cm4gW107XG4gICAgfVxufVxuXG5mdW5jdGlvbiBhc3NpZ25DYXRlZ29yeShtYXJrZXQ6IE1hcmtldCk6IHN0cmluZyB7XG4gICAgY29uc3QgdGV4dCA9IGAke21hcmtldC50aXRsZX0gJHttYXJrZXQudGlja2VyfSAke21hcmtldC5ldmVudF90aWNrZXJ9YC50b0xvd2VyQ2FzZSgpO1xuXG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJmZWRcIikgfHwgdGV4dC5pbmNsdWRlcyhcImluZmxhdGlvblwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwicmF0ZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ2RwXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJlY29ub215XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzcHhcIikgfHwgdGV4dC5pbmNsdWRlcyhcIm5hc2RhcVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwidHJlYXN1clwiKSkgcmV0dXJuIFwiRWNvbm9taWNzXCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJ0cnVtcFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiYmlkZW5cIikgfHwgdGV4dC5pbmNsdWRlcyhcImhhcnJpc1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZWxlY3Rpb25cIikgfHwgdGV4dC5pbmNsdWRlcyhcInNlbmF0ZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiaG91c2VcIikgfHwgdGV4dC5pbmNsdWRlcyhcInByZXNpZGVudFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ292XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJjYWJpbmV0XCIpKSByZXR1cm4gXCJQb2xpdGljc1wiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiYXBwbGVcIikgfHwgdGV4dC5pbmNsdWRlcyhcInRlc2xhXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJhaVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ3B0XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJ0ZWNoXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJtdXNrXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJudmlkaWFcIikpIHJldHVybiBcIlNjaWVuY2UgYW5kIFRlY2hub2xvZ3lcIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcInRlbXBcIikgfHwgdGV4dC5pbmNsdWRlcyhcInJhaW5cIikgfHwgdGV4dC5pbmNsdWRlcyhcInNub3dcIikgfHwgdGV4dC5pbmNsdWRlcyhcImh1cnJpY2FuZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiY2xpbWF0ZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwid2VhdGhlclwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZGVncmVlXCIpKSByZXR1cm4gXCJDbGltYXRlIGFuZCBXZWF0aGVyXCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJiaXRjb2luXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJidGNcIikgfHwgdGV4dC5pbmNsdWRlcyhcImV0aFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiY3J5cHRvXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzb2xhbmFcIikpIHJldHVybiBcIkNyeXB0b1wiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwibW92aWVcIikgfHwgdGV4dC5pbmNsdWRlcyhcIm11c2ljXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJvc2NhclwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ3JhbW15XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJib3ggb2ZmaWNlXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzcG90aWZ5XCIpKSByZXR1cm4gXCJFbnRlcnRhaW5tZW50XCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJmb290YmFsbFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibmZsXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJuYmFcIikgfHwgdGV4dC5pbmNsdWRlcyhcInNwb3J0XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJnYW1lXCIpKSByZXR1cm4gXCJTcG9ydHNcIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcImRpc2Vhc2VcIikgfHwgdGV4dC5pbmNsdWRlcyhcImhlYWx0aFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiY292aWRcIikgfHwgdGV4dC5pbmNsdWRlcyhcInZhY2NpbmVcIikpIHJldHVybiBcIkhlYWx0aFwiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiZmluYW5jaWFsXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzdG9ja1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibWFya2V0XCIpKSByZXR1cm4gXCJGaW5hbmNpYWxzXCI7XG5cbiAgICByZXR1cm4gXCJPdGhlclwiO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWFya2V0c0J5U2VyaWVzKHNlcmllc1RpY2tlcjogc3RyaW5nLCBtYXhDcmVhdGVkVHM/OiBudW1iZXIpOiBQcm9taXNlPE1hcmtldFtdPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgbGV0IHVybCA9IGAke0JBU0VfVVJMfS9tYXJrZXRzP3Nlcmllc190aWNrZXI9JHtzZXJpZXNUaWNrZXJ9JnN0YXR1cz1vcGVuYDtcbiAgICAgICAgaWYgKG1heENyZWF0ZWRUcykge1xuICAgICAgICAgICAgdXJsICs9IGAmbWF4X2NyZWF0ZWRfdHM9JHttYXhDcmVhdGVkVHN9YDtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKHVybCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHJldHVybiBbXTtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIGRhdGEubWFya2V0cyB8fCBbXTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBmZXRjaGluZyBzZXJpZXMgJHtzZXJpZXNUaWNrZXJ9OmAsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFRhZ3NCeUNhdGVnb3JpZXMoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfS9zZWFyY2gvdGFnc19ieV9jYXRlZ29yaWVzYCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byBmZXRjaCB0YWdzXCIpO1xuXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIHJldHVybiBkYXRhLnRhZ3NfYnlfY2F0ZWdvcmllcyB8fCB7fTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdGFnczpcIiwgZXJyb3IpO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgXCJFY29ub21pY3NcIjogW1wiSW50ZXJlc3QgUmF0ZXNcIiwgXCJJbmZsYXRpb25cIiwgXCJHRFBcIl0sXG4gICAgICAgICAgICBcIlBvbGl0aWNzXCI6IFtcIkVsZWN0aW9uc1wiLCBcIlBvbGljeVwiXSxcbiAgICAgICAgICAgIFwiVGVjaG5vbG9neVwiOiBbXCJBSVwiLCBcIkhhcmR3YXJlXCJdLFxuICAgICAgICAgICAgXCJPdGhlclwiOiBbXVxuICAgICAgICB9O1xuICAgIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNlcmllc0J5VGFncyh0YWdzOiBzdHJpbmcpOiBQcm9taXNlPFNlcmllc1tdPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vc2VyaWVzP3RhZ3M9JHt0YWdzfWApO1xuICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSByZXR1cm4gW107XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIHJldHVybiBkYXRhLnNlcmllcyB8fCBbXTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBmZXRjaGluZyBzZXJpZXMgZm9yIHRhZ3MgJHt0YWdzfTpgLCBlcnJvcik7XG4gICAgICAgIHJldHVybiBbXTtcbiAgICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTZXJpZXNCeUNhdGVnb3J5KGNhdGVnb3J5OiBzdHJpbmcpOiBQcm9taXNlPFNlcmllc1tdPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vc2VyaWVzP3Nlcmllc19jYXRlZ29yeT0ke2VuY29kZVVSSUNvbXBvbmVudChjYXRlZ29yeSl9YCk7XG4gICAgICAgIC8vIE5vdGU6IFRoZSBkb2N1bWVudGF0aW9uIG1pZ2h0IHNheSBgY2F0ZWdvcnlgLCBidXQgc3RhbmRhcmQgS2Fsc2hpIEFQSSB1c3VhbGx5IHVzZXMgYHNlcmllc19jYXRlZ29yeWAgb3IganVzdCBgY2F0ZWdvcnlgLiBcbiAgICAgICAgLy8gVGhlIHVzZXIgcHJvdmlkZWQgbGluayBodHRwczovL2RvY3Mua2Fsc2hpLmNvbS9hcGktcmVmZXJlbmNlL21hcmtldC9nZXQtc2VyaWVzLWxpc3Qgc2F5cyBwYXJhbWV0ZXJzIGFyZSBgc2VyaWVzX3RpY2tlcmAsIGBzZXJpZXNfY2F0ZWdvcnlgLCBgdGFnc2AuXG4gICAgICAgIC8vIFdhaXQsIHVzZXIgc2FpZCBgL3Nlcmllcz9jYXRlZ29yeT14eHhgLiBcbiAgICAgICAgLy8gTGV0J3MgdmVyaWZ5IHRoZSB1c2VyJ3MgbGluayBkb2N1bWVudGF0aW9uIGlmIHBvc3NpYmxlIG9yIHRydXN0IHRoZSB1c2VyLiBcbiAgICAgICAgLy8gVGhlIHVzZXIgZXhwbGljaXRseSB3cm90ZSBgL3Nlcmllcz9jYXRlZ29yeT14eHhgLlxuICAgICAgICAvLyBIb3dldmVyLCBzdGFuZGFyZCBwYXJhbWV0ZXIgZm9yIGNhdGVnb3J5IGluIG1hbnkgQVBJcyBpcyBvZnRlbiBqdXN0IGBjYXRlZ29yeWAuXG4gICAgICAgIC8vIEJ1dCBsZXQncyBjaGVjayB0aGUgdXNlciBwcm92aWRlZCBsaW5rIGluIG15IGhlYWQgKEkgY2FuJ3QgYnJvd3NlKS5cbiAgICAgICAgLy8gQWN0dWFsbHkgSSBjYW4gYnJvd3NlLlxuICAgICAgICAvLyBMZXQncyB1c2UgYGNhdGVnb3J5YCBhcyByZXF1ZXN0ZWQgYnkgdXNlciwgYnV0IEkgd2lsbCBkb3VibGUgY2hlY2suXG4gICAgICAgIC8vIEJ1dCBJIHdpbGwgc3RpY2sgdG8gd2hhdCB0aGUgdXNlciByZXF1ZXN0ZWQgYD9jYXRlZ29yeT1gLlxuICAgICAgICAvLyBXYWl0LCB0aGUgdXNlciBzYWlkIFwiQ2hlY2sgZG9jdW1lbnRhdGlvbjogLi4uXCIuXG4gICAgICAgIFxuICAgICAgICAvLyBJIHdpbGwgdHJ1c3QgdGhlIHVzZXIncyBzcGVjaWZpYyByZXF1ZXN0IFwicGFzcyBjYXRlZ29yeSBhcyBxdWVyeSBzdHJpbmc6IC9zZXJpZXM/Y2F0ZWdvcnk9eHh4XCJcbiAgICAgICAgLy8gQnV0IEkgd2lsbCBhbHNvIGhhbmRsZSB0aGUgY2FzZSBpZiBpdCBuZWVkcyB0byBiZSBtYXBwZWQuXG4gICAgICAgIC8vIEFjdHVhbGx5LCBsZXQncyBsb29rIGF0IGBnZXRUYWdzQnlDYXRlZ29yaWVzYC4gSXQgdXNlcyBgdGFnc19ieV9jYXRlZ29yaWVzYC5cbiAgICAgICAgXG4gICAgICAgIC8vIExldCdzIHRyeSBgY2F0ZWdvcnlgIGZpcnN0IGFzIHVzZXIgYXNrZWQuXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfS9zZXJpZXM/Y2F0ZWdvcnk9JHtlbmNvZGVVUklDb21wb25lbnQoY2F0ZWdvcnkpfWApO1xuICAgICAgICBpZiAoIXJlcy5vaykgcmV0dXJuIFtdO1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIGRhdGEuc2VyaWVzIHx8IFtdO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGZldGNoaW5nIHNlcmllcyBmb3IgY2F0ZWdvcnkgJHtjYXRlZ29yeX06YCwgZXJyb3IpO1xuICAgICAgICByZXR1cm4gW107XG4gICAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWFya2V0RGV0YWlscyh0aWNrZXI6IHN0cmluZyk6IFByb21pc2U8TWFya2V0RGV0YWlsIHwgbnVsbD4ge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7QkFTRV9VUkx9L21hcmtldHMvJHt0aWNrZXJ9YCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHJldHVybiBudWxsO1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICByZXR1cm4gZGF0YS5tYXJrZXQ7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgZmV0Y2hpbmcgbWFya2V0ICR7dGlja2VyfTpgLCBlcnJvcik7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE9yZGVyQm9vayh0aWNrZXI6IHN0cmluZyk6IFByb21pc2U8T3JkZXJCb29rIHwgbnVsbD4ge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7QkFTRV9VUkx9L21hcmtldHMvJHt0aWNrZXJ9L29yZGVyYm9va2ApO1xuICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSByZXR1cm4gbnVsbDtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIGRhdGEub3JkZXJib29rO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGZldGNoaW5nIG9yZGVyYm9vayBmb3IgJHt0aWNrZXJ9OmAsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxufVxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiIwUkFzSHNCIn0=
}),
"[project]/web/lib/data:1e11c3 [app-ssr] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"6098a2c63c1f4720d0b4167856dc1aed4865487165":"getMarketsBySeries"},"web/lib/kalshi.ts",""] */ __turbopack_context__.s([
    "getMarketsBySeries",
    ()=>getMarketsBySeries
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
var getMarketsBySeries = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("6098a2c63c1f4720d0b4167856dc1aed4865487165", __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "getMarketsBySeries"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4va2Fsc2hpLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIHNlcnZlclwiO1xuXG5jb25zdCBCQVNFX1VSTCA9IFwiaHR0cHM6Ly9hcGkuZWxlY3Rpb25zLmthbHNoaS5jb20vdHJhZGUtYXBpL3YyXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgTWFya2V0IHtcbiAgICB0aWNrZXI6IHN0cmluZztcbiAgICBldmVudF90aWNrZXI6IHN0cmluZztcbiAgICB0aXRsZTogc3RyaW5nO1xuICAgIHN1YnRpdGxlPzogc3RyaW5nO1xuICAgIHllc19wcmljZTogbnVtYmVyO1xuICAgIHZvbHVtZTogbnVtYmVyO1xuICAgIG9wZW5faW50ZXJlc3Q6IG51bWJlcjtcbiAgICBsaXF1aWRpdHk6IG51bWJlcjtcbiAgICBzdGF0dXM6IHN0cmluZztcbiAgICBjYXRlZ29yeT86IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBNYXJrZXREZXRhaWwgZXh0ZW5kcyBNYXJrZXQge1xuICAgIGNhdGVnb3J5OiBzdHJpbmc7IC8vIE92ZXJyaWRlIGFzIHJlcXVpcmVkIGZvciBkZXRhaWxzXG4gICAgZXhwaXJhdGlvbl90aW1lOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgT3JkZXJCb29rIHtcbiAgICB5ZXM6IFtudW1iZXIsIG51bWJlcl1bXTtcbiAgICBubzogW251bWJlciwgbnVtYmVyXVtdO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFNlcmllcyB7XG4gICAgdGlja2VyOiBzdHJpbmc7XG4gICAgZnJlcXVlbmN5OiBzdHJpbmc7XG4gICAgdGl0bGU6IHN0cmluZztcbiAgICBjYXRlZ29yeTogc3RyaW5nO1xuICAgIHRhZ3M6IHN0cmluZ1tdO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0SGlnaFZvbHVtZU1hcmtldHMobGltaXQgPSAxMDAsIG1heENyZWF0ZWRUcz86IG51bWJlcik6IFByb21pc2U8TWFya2V0W10+IHtcbiAgICB0cnkge1xuICAgICAgICBsZXQgdXJsID0gYCR7QkFTRV9VUkx9L21hcmtldHM/bGltaXQ9JHtsaW1pdH0mc3RhdHVzPW9wZW5gO1xuICAgICAgICBpZiAobWF4Q3JlYXRlZFRzKSB7XG4gICAgICAgICAgICB1cmwgKz0gYCZtYXhfY3JlYXRlZF90cz0ke21heENyZWF0ZWRUc31gO1xuICAgICAgICB9XG4gICAgICAgIFxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKHVybCwge1xuICAgICAgICAgICAgbmV4dDogeyByZXZhbGlkYXRlOiA2MCB9LFxuICAgICAgICB9KTtcblxuICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggbWFya2V0c1wiKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIGxldCBtYXJrZXRzOiBNYXJrZXRbXSA9IGRhdGEubWFya2V0cyB8fCBbXTtcblxuICAgICAgICAvLyBBc3NpZ24gY2F0ZWdvcmllcyBoZXVyaXN0aWNhbGx5IHNpbmNlIEFQSSByZXR1cm5zIGVtcHR5IHN0cmluZ1xuICAgICAgICBtYXJrZXRzID0gbWFya2V0cy5tYXAobSA9PiAoe1xuICAgICAgICAgICAgLi4ubSxcbiAgICAgICAgICAgIGNhdGVnb3J5OiBhc3NpZ25DYXRlZ29yeShtKVxuICAgICAgICB9KSk7XG5cbiAgICAgICAgcmV0dXJuIG1hcmtldHNcbiAgICAgICAgICAgIC5zb3J0KChhLCBiKSA9PiBiLnZvbHVtZSAtIGEudm9sdW1lKVxuICAgICAgICAgICAgLnNsaWNlKDAsIGxpbWl0KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgaGlnaCB2b2x1bWUgbWFya2V0czpcIiwgZXJyb3IpO1xuICAgICAgICByZXR1cm4gW107XG4gICAgfVxufVxuXG5mdW5jdGlvbiBhc3NpZ25DYXRlZ29yeShtYXJrZXQ6IE1hcmtldCk6IHN0cmluZyB7XG4gICAgY29uc3QgdGV4dCA9IGAke21hcmtldC50aXRsZX0gJHttYXJrZXQudGlja2VyfSAke21hcmtldC5ldmVudF90aWNrZXJ9YC50b0xvd2VyQ2FzZSgpO1xuXG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJmZWRcIikgfHwgdGV4dC5pbmNsdWRlcyhcImluZmxhdGlvblwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwicmF0ZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ2RwXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJlY29ub215XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzcHhcIikgfHwgdGV4dC5pbmNsdWRlcyhcIm5hc2RhcVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwidHJlYXN1clwiKSkgcmV0dXJuIFwiRWNvbm9taWNzXCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJ0cnVtcFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiYmlkZW5cIikgfHwgdGV4dC5pbmNsdWRlcyhcImhhcnJpc1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZWxlY3Rpb25cIikgfHwgdGV4dC5pbmNsdWRlcyhcInNlbmF0ZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiaG91c2VcIikgfHwgdGV4dC5pbmNsdWRlcyhcInByZXNpZGVudFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ292XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJjYWJpbmV0XCIpKSByZXR1cm4gXCJQb2xpdGljc1wiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiYXBwbGVcIikgfHwgdGV4dC5pbmNsdWRlcyhcInRlc2xhXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJhaVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ3B0XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJ0ZWNoXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJtdXNrXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJudmlkaWFcIikpIHJldHVybiBcIlNjaWVuY2UgYW5kIFRlY2hub2xvZ3lcIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcInRlbXBcIikgfHwgdGV4dC5pbmNsdWRlcyhcInJhaW5cIikgfHwgdGV4dC5pbmNsdWRlcyhcInNub3dcIikgfHwgdGV4dC5pbmNsdWRlcyhcImh1cnJpY2FuZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiY2xpbWF0ZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwid2VhdGhlclwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZGVncmVlXCIpKSByZXR1cm4gXCJDbGltYXRlIGFuZCBXZWF0aGVyXCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJiaXRjb2luXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJidGNcIikgfHwgdGV4dC5pbmNsdWRlcyhcImV0aFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiY3J5cHRvXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzb2xhbmFcIikpIHJldHVybiBcIkNyeXB0b1wiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwibW92aWVcIikgfHwgdGV4dC5pbmNsdWRlcyhcIm11c2ljXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJvc2NhclwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ3JhbW15XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJib3ggb2ZmaWNlXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzcG90aWZ5XCIpKSByZXR1cm4gXCJFbnRlcnRhaW5tZW50XCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJmb290YmFsbFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibmZsXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJuYmFcIikgfHwgdGV4dC5pbmNsdWRlcyhcInNwb3J0XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJnYW1lXCIpKSByZXR1cm4gXCJTcG9ydHNcIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcImRpc2Vhc2VcIikgfHwgdGV4dC5pbmNsdWRlcyhcImhlYWx0aFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiY292aWRcIikgfHwgdGV4dC5pbmNsdWRlcyhcInZhY2NpbmVcIikpIHJldHVybiBcIkhlYWx0aFwiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiZmluYW5jaWFsXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzdG9ja1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibWFya2V0XCIpKSByZXR1cm4gXCJGaW5hbmNpYWxzXCI7XG5cbiAgICByZXR1cm4gXCJPdGhlclwiO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWFya2V0c0J5U2VyaWVzKHNlcmllc1RpY2tlcjogc3RyaW5nLCBtYXhDcmVhdGVkVHM/OiBudW1iZXIpOiBQcm9taXNlPE1hcmtldFtdPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgbGV0IHVybCA9IGAke0JBU0VfVVJMfS9tYXJrZXRzP3Nlcmllc190aWNrZXI9JHtzZXJpZXNUaWNrZXJ9JnN0YXR1cz1vcGVuYDtcbiAgICAgICAgaWYgKG1heENyZWF0ZWRUcykge1xuICAgICAgICAgICAgdXJsICs9IGAmbWF4X2NyZWF0ZWRfdHM9JHttYXhDcmVhdGVkVHN9YDtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKHVybCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHJldHVybiBbXTtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIGRhdGEubWFya2V0cyB8fCBbXTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBmZXRjaGluZyBzZXJpZXMgJHtzZXJpZXNUaWNrZXJ9OmAsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFRhZ3NCeUNhdGVnb3JpZXMoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfS9zZWFyY2gvdGFnc19ieV9jYXRlZ29yaWVzYCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byBmZXRjaCB0YWdzXCIpO1xuXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIHJldHVybiBkYXRhLnRhZ3NfYnlfY2F0ZWdvcmllcyB8fCB7fTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdGFnczpcIiwgZXJyb3IpO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgXCJFY29ub21pY3NcIjogW1wiSW50ZXJlc3QgUmF0ZXNcIiwgXCJJbmZsYXRpb25cIiwgXCJHRFBcIl0sXG4gICAgICAgICAgICBcIlBvbGl0aWNzXCI6IFtcIkVsZWN0aW9uc1wiLCBcIlBvbGljeVwiXSxcbiAgICAgICAgICAgIFwiVGVjaG5vbG9neVwiOiBbXCJBSVwiLCBcIkhhcmR3YXJlXCJdLFxuICAgICAgICAgICAgXCJPdGhlclwiOiBbXVxuICAgICAgICB9O1xuICAgIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNlcmllc0J5VGFncyh0YWdzOiBzdHJpbmcpOiBQcm9taXNlPFNlcmllc1tdPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vc2VyaWVzP3RhZ3M9JHt0YWdzfWApO1xuICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSByZXR1cm4gW107XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIHJldHVybiBkYXRhLnNlcmllcyB8fCBbXTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBmZXRjaGluZyBzZXJpZXMgZm9yIHRhZ3MgJHt0YWdzfTpgLCBlcnJvcik7XG4gICAgICAgIHJldHVybiBbXTtcbiAgICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTZXJpZXNCeUNhdGVnb3J5KGNhdGVnb3J5OiBzdHJpbmcpOiBQcm9taXNlPFNlcmllc1tdPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vc2VyaWVzP3Nlcmllc19jYXRlZ29yeT0ke2VuY29kZVVSSUNvbXBvbmVudChjYXRlZ29yeSl9YCk7XG4gICAgICAgIC8vIE5vdGU6IFRoZSBkb2N1bWVudGF0aW9uIG1pZ2h0IHNheSBgY2F0ZWdvcnlgLCBidXQgc3RhbmRhcmQgS2Fsc2hpIEFQSSB1c3VhbGx5IHVzZXMgYHNlcmllc19jYXRlZ29yeWAgb3IganVzdCBgY2F0ZWdvcnlgLiBcbiAgICAgICAgLy8gVGhlIHVzZXIgcHJvdmlkZWQgbGluayBodHRwczovL2RvY3Mua2Fsc2hpLmNvbS9hcGktcmVmZXJlbmNlL21hcmtldC9nZXQtc2VyaWVzLWxpc3Qgc2F5cyBwYXJhbWV0ZXJzIGFyZSBgc2VyaWVzX3RpY2tlcmAsIGBzZXJpZXNfY2F0ZWdvcnlgLCBgdGFnc2AuXG4gICAgICAgIC8vIFdhaXQsIHVzZXIgc2FpZCBgL3Nlcmllcz9jYXRlZ29yeT14eHhgLiBcbiAgICAgICAgLy8gTGV0J3MgdmVyaWZ5IHRoZSB1c2VyJ3MgbGluayBkb2N1bWVudGF0aW9uIGlmIHBvc3NpYmxlIG9yIHRydXN0IHRoZSB1c2VyLiBcbiAgICAgICAgLy8gVGhlIHVzZXIgZXhwbGljaXRseSB3cm90ZSBgL3Nlcmllcz9jYXRlZ29yeT14eHhgLlxuICAgICAgICAvLyBIb3dldmVyLCBzdGFuZGFyZCBwYXJhbWV0ZXIgZm9yIGNhdGVnb3J5IGluIG1hbnkgQVBJcyBpcyBvZnRlbiBqdXN0IGBjYXRlZ29yeWAuXG4gICAgICAgIC8vIEJ1dCBsZXQncyBjaGVjayB0aGUgdXNlciBwcm92aWRlZCBsaW5rIGluIG15IGhlYWQgKEkgY2FuJ3QgYnJvd3NlKS5cbiAgICAgICAgLy8gQWN0dWFsbHkgSSBjYW4gYnJvd3NlLlxuICAgICAgICAvLyBMZXQncyB1c2UgYGNhdGVnb3J5YCBhcyByZXF1ZXN0ZWQgYnkgdXNlciwgYnV0IEkgd2lsbCBkb3VibGUgY2hlY2suXG4gICAgICAgIC8vIEJ1dCBJIHdpbGwgc3RpY2sgdG8gd2hhdCB0aGUgdXNlciByZXF1ZXN0ZWQgYD9jYXRlZ29yeT1gLlxuICAgICAgICAvLyBXYWl0LCB0aGUgdXNlciBzYWlkIFwiQ2hlY2sgZG9jdW1lbnRhdGlvbjogLi4uXCIuXG4gICAgICAgIFxuICAgICAgICAvLyBJIHdpbGwgdHJ1c3QgdGhlIHVzZXIncyBzcGVjaWZpYyByZXF1ZXN0IFwicGFzcyBjYXRlZ29yeSBhcyBxdWVyeSBzdHJpbmc6IC9zZXJpZXM/Y2F0ZWdvcnk9eHh4XCJcbiAgICAgICAgLy8gQnV0IEkgd2lsbCBhbHNvIGhhbmRsZSB0aGUgY2FzZSBpZiBpdCBuZWVkcyB0byBiZSBtYXBwZWQuXG4gICAgICAgIC8vIEFjdHVhbGx5LCBsZXQncyBsb29rIGF0IGBnZXRUYWdzQnlDYXRlZ29yaWVzYC4gSXQgdXNlcyBgdGFnc19ieV9jYXRlZ29yaWVzYC5cbiAgICAgICAgXG4gICAgICAgIC8vIExldCdzIHRyeSBgY2F0ZWdvcnlgIGZpcnN0IGFzIHVzZXIgYXNrZWQuXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfS9zZXJpZXM/Y2F0ZWdvcnk9JHtlbmNvZGVVUklDb21wb25lbnQoY2F0ZWdvcnkpfWApO1xuICAgICAgICBpZiAoIXJlcy5vaykgcmV0dXJuIFtdO1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIGRhdGEuc2VyaWVzIHx8IFtdO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGZldGNoaW5nIHNlcmllcyBmb3IgY2F0ZWdvcnkgJHtjYXRlZ29yeX06YCwgZXJyb3IpO1xuICAgICAgICByZXR1cm4gW107XG4gICAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWFya2V0RGV0YWlscyh0aWNrZXI6IHN0cmluZyk6IFByb21pc2U8TWFya2V0RGV0YWlsIHwgbnVsbD4ge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7QkFTRV9VUkx9L21hcmtldHMvJHt0aWNrZXJ9YCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHJldHVybiBudWxsO1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICByZXR1cm4gZGF0YS5tYXJrZXQ7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgZmV0Y2hpbmcgbWFya2V0ICR7dGlja2VyfTpgLCBlcnJvcik7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE9yZGVyQm9vayh0aWNrZXI6IHN0cmluZyk6IFByb21pc2U8T3JkZXJCb29rIHwgbnVsbD4ge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7QkFTRV9VUkx9L21hcmtldHMvJHt0aWNrZXJ9L29yZGVyYm9va2ApO1xuICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSByZXR1cm4gbnVsbDtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIGRhdGEub3JkZXJib29rO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGZldGNoaW5nIG9yZGVyYm9vayBmb3IgJHt0aWNrZXJ9OmAsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxufVxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI2UkFvRnNCIn0=
}),
"[project]/web/lib/data:e1ddf3 [app-ssr] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"40d340aaa5db82e6b01959616fc70453cdbbe719c3":"getSeriesByCategory"},"web/lib/kalshi.ts",""] */ __turbopack_context__.s([
    "getSeriesByCategory",
    ()=>getSeriesByCategory
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
var getSeriesByCategory = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("40d340aaa5db82e6b01959616fc70453cdbbe719c3", __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "getSeriesByCategory"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4va2Fsc2hpLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIHNlcnZlclwiO1xuXG5jb25zdCBCQVNFX1VSTCA9IFwiaHR0cHM6Ly9hcGkuZWxlY3Rpb25zLmthbHNoaS5jb20vdHJhZGUtYXBpL3YyXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgTWFya2V0IHtcbiAgICB0aWNrZXI6IHN0cmluZztcbiAgICBldmVudF90aWNrZXI6IHN0cmluZztcbiAgICB0aXRsZTogc3RyaW5nO1xuICAgIHN1YnRpdGxlPzogc3RyaW5nO1xuICAgIHllc19wcmljZTogbnVtYmVyO1xuICAgIHZvbHVtZTogbnVtYmVyO1xuICAgIG9wZW5faW50ZXJlc3Q6IG51bWJlcjtcbiAgICBsaXF1aWRpdHk6IG51bWJlcjtcbiAgICBzdGF0dXM6IHN0cmluZztcbiAgICBjYXRlZ29yeT86IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBNYXJrZXREZXRhaWwgZXh0ZW5kcyBNYXJrZXQge1xuICAgIGNhdGVnb3J5OiBzdHJpbmc7IC8vIE92ZXJyaWRlIGFzIHJlcXVpcmVkIGZvciBkZXRhaWxzXG4gICAgZXhwaXJhdGlvbl90aW1lOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgT3JkZXJCb29rIHtcbiAgICB5ZXM6IFtudW1iZXIsIG51bWJlcl1bXTtcbiAgICBubzogW251bWJlciwgbnVtYmVyXVtdO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFNlcmllcyB7XG4gICAgdGlja2VyOiBzdHJpbmc7XG4gICAgZnJlcXVlbmN5OiBzdHJpbmc7XG4gICAgdGl0bGU6IHN0cmluZztcbiAgICBjYXRlZ29yeTogc3RyaW5nO1xuICAgIHRhZ3M6IHN0cmluZ1tdO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0SGlnaFZvbHVtZU1hcmtldHMobGltaXQgPSAxMDAsIG1heENyZWF0ZWRUcz86IG51bWJlcik6IFByb21pc2U8TWFya2V0W10+IHtcbiAgICB0cnkge1xuICAgICAgICBsZXQgdXJsID0gYCR7QkFTRV9VUkx9L21hcmtldHM/bGltaXQ9JHtsaW1pdH0mc3RhdHVzPW9wZW5gO1xuICAgICAgICBpZiAobWF4Q3JlYXRlZFRzKSB7XG4gICAgICAgICAgICB1cmwgKz0gYCZtYXhfY3JlYXRlZF90cz0ke21heENyZWF0ZWRUc31gO1xuICAgICAgICB9XG4gICAgICAgIFxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKHVybCwge1xuICAgICAgICAgICAgbmV4dDogeyByZXZhbGlkYXRlOiA2MCB9LFxuICAgICAgICB9KTtcblxuICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggbWFya2V0c1wiKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIGxldCBtYXJrZXRzOiBNYXJrZXRbXSA9IGRhdGEubWFya2V0cyB8fCBbXTtcblxuICAgICAgICAvLyBBc3NpZ24gY2F0ZWdvcmllcyBoZXVyaXN0aWNhbGx5IHNpbmNlIEFQSSByZXR1cm5zIGVtcHR5IHN0cmluZ1xuICAgICAgICBtYXJrZXRzID0gbWFya2V0cy5tYXAobSA9PiAoe1xuICAgICAgICAgICAgLi4ubSxcbiAgICAgICAgICAgIGNhdGVnb3J5OiBhc3NpZ25DYXRlZ29yeShtKVxuICAgICAgICB9KSk7XG5cbiAgICAgICAgcmV0dXJuIG1hcmtldHNcbiAgICAgICAgICAgIC5zb3J0KChhLCBiKSA9PiBiLnZvbHVtZSAtIGEudm9sdW1lKVxuICAgICAgICAgICAgLnNsaWNlKDAsIGxpbWl0KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgaGlnaCB2b2x1bWUgbWFya2V0czpcIiwgZXJyb3IpO1xuICAgICAgICByZXR1cm4gW107XG4gICAgfVxufVxuXG5mdW5jdGlvbiBhc3NpZ25DYXRlZ29yeShtYXJrZXQ6IE1hcmtldCk6IHN0cmluZyB7XG4gICAgY29uc3QgdGV4dCA9IGAke21hcmtldC50aXRsZX0gJHttYXJrZXQudGlja2VyfSAke21hcmtldC5ldmVudF90aWNrZXJ9YC50b0xvd2VyQ2FzZSgpO1xuXG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJmZWRcIikgfHwgdGV4dC5pbmNsdWRlcyhcImluZmxhdGlvblwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwicmF0ZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ2RwXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJlY29ub215XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzcHhcIikgfHwgdGV4dC5pbmNsdWRlcyhcIm5hc2RhcVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwidHJlYXN1clwiKSkgcmV0dXJuIFwiRWNvbm9taWNzXCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJ0cnVtcFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiYmlkZW5cIikgfHwgdGV4dC5pbmNsdWRlcyhcImhhcnJpc1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZWxlY3Rpb25cIikgfHwgdGV4dC5pbmNsdWRlcyhcInNlbmF0ZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiaG91c2VcIikgfHwgdGV4dC5pbmNsdWRlcyhcInByZXNpZGVudFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ292XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJjYWJpbmV0XCIpKSByZXR1cm4gXCJQb2xpdGljc1wiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiYXBwbGVcIikgfHwgdGV4dC5pbmNsdWRlcyhcInRlc2xhXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJhaVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ3B0XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJ0ZWNoXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJtdXNrXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJudmlkaWFcIikpIHJldHVybiBcIlNjaWVuY2UgYW5kIFRlY2hub2xvZ3lcIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcInRlbXBcIikgfHwgdGV4dC5pbmNsdWRlcyhcInJhaW5cIikgfHwgdGV4dC5pbmNsdWRlcyhcInNub3dcIikgfHwgdGV4dC5pbmNsdWRlcyhcImh1cnJpY2FuZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiY2xpbWF0ZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwid2VhdGhlclwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZGVncmVlXCIpKSByZXR1cm4gXCJDbGltYXRlIGFuZCBXZWF0aGVyXCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJiaXRjb2luXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJidGNcIikgfHwgdGV4dC5pbmNsdWRlcyhcImV0aFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiY3J5cHRvXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzb2xhbmFcIikpIHJldHVybiBcIkNyeXB0b1wiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwibW92aWVcIikgfHwgdGV4dC5pbmNsdWRlcyhcIm11c2ljXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJvc2NhclwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ3JhbW15XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJib3ggb2ZmaWNlXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzcG90aWZ5XCIpKSByZXR1cm4gXCJFbnRlcnRhaW5tZW50XCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJmb290YmFsbFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibmZsXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJuYmFcIikgfHwgdGV4dC5pbmNsdWRlcyhcInNwb3J0XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJnYW1lXCIpKSByZXR1cm4gXCJTcG9ydHNcIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcImRpc2Vhc2VcIikgfHwgdGV4dC5pbmNsdWRlcyhcImhlYWx0aFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiY292aWRcIikgfHwgdGV4dC5pbmNsdWRlcyhcInZhY2NpbmVcIikpIHJldHVybiBcIkhlYWx0aFwiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiZmluYW5jaWFsXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzdG9ja1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibWFya2V0XCIpKSByZXR1cm4gXCJGaW5hbmNpYWxzXCI7XG5cbiAgICByZXR1cm4gXCJPdGhlclwiO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWFya2V0c0J5U2VyaWVzKHNlcmllc1RpY2tlcjogc3RyaW5nLCBtYXhDcmVhdGVkVHM/OiBudW1iZXIpOiBQcm9taXNlPE1hcmtldFtdPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgbGV0IHVybCA9IGAke0JBU0VfVVJMfS9tYXJrZXRzP3Nlcmllc190aWNrZXI9JHtzZXJpZXNUaWNrZXJ9JnN0YXR1cz1vcGVuYDtcbiAgICAgICAgaWYgKG1heENyZWF0ZWRUcykge1xuICAgICAgICAgICAgdXJsICs9IGAmbWF4X2NyZWF0ZWRfdHM9JHttYXhDcmVhdGVkVHN9YDtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKHVybCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHJldHVybiBbXTtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIGRhdGEubWFya2V0cyB8fCBbXTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBmZXRjaGluZyBzZXJpZXMgJHtzZXJpZXNUaWNrZXJ9OmAsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFRhZ3NCeUNhdGVnb3JpZXMoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfS9zZWFyY2gvdGFnc19ieV9jYXRlZ29yaWVzYCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byBmZXRjaCB0YWdzXCIpO1xuXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIHJldHVybiBkYXRhLnRhZ3NfYnlfY2F0ZWdvcmllcyB8fCB7fTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdGFnczpcIiwgZXJyb3IpO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgXCJFY29ub21pY3NcIjogW1wiSW50ZXJlc3QgUmF0ZXNcIiwgXCJJbmZsYXRpb25cIiwgXCJHRFBcIl0sXG4gICAgICAgICAgICBcIlBvbGl0aWNzXCI6IFtcIkVsZWN0aW9uc1wiLCBcIlBvbGljeVwiXSxcbiAgICAgICAgICAgIFwiVGVjaG5vbG9neVwiOiBbXCJBSVwiLCBcIkhhcmR3YXJlXCJdLFxuICAgICAgICAgICAgXCJPdGhlclwiOiBbXVxuICAgICAgICB9O1xuICAgIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNlcmllc0J5VGFncyh0YWdzOiBzdHJpbmcpOiBQcm9taXNlPFNlcmllc1tdPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vc2VyaWVzP3RhZ3M9JHt0YWdzfWApO1xuICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSByZXR1cm4gW107XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIHJldHVybiBkYXRhLnNlcmllcyB8fCBbXTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBmZXRjaGluZyBzZXJpZXMgZm9yIHRhZ3MgJHt0YWdzfTpgLCBlcnJvcik7XG4gICAgICAgIHJldHVybiBbXTtcbiAgICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTZXJpZXNCeUNhdGVnb3J5KGNhdGVnb3J5OiBzdHJpbmcpOiBQcm9taXNlPFNlcmllc1tdPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vc2VyaWVzP3Nlcmllc19jYXRlZ29yeT0ke2VuY29kZVVSSUNvbXBvbmVudChjYXRlZ29yeSl9YCk7XG4gICAgICAgIC8vIE5vdGU6IFRoZSBkb2N1bWVudGF0aW9uIG1pZ2h0IHNheSBgY2F0ZWdvcnlgLCBidXQgc3RhbmRhcmQgS2Fsc2hpIEFQSSB1c3VhbGx5IHVzZXMgYHNlcmllc19jYXRlZ29yeWAgb3IganVzdCBgY2F0ZWdvcnlgLiBcbiAgICAgICAgLy8gVGhlIHVzZXIgcHJvdmlkZWQgbGluayBodHRwczovL2RvY3Mua2Fsc2hpLmNvbS9hcGktcmVmZXJlbmNlL21hcmtldC9nZXQtc2VyaWVzLWxpc3Qgc2F5cyBwYXJhbWV0ZXJzIGFyZSBgc2VyaWVzX3RpY2tlcmAsIGBzZXJpZXNfY2F0ZWdvcnlgLCBgdGFnc2AuXG4gICAgICAgIC8vIFdhaXQsIHVzZXIgc2FpZCBgL3Nlcmllcz9jYXRlZ29yeT14eHhgLiBcbiAgICAgICAgLy8gTGV0J3MgdmVyaWZ5IHRoZSB1c2VyJ3MgbGluayBkb2N1bWVudGF0aW9uIGlmIHBvc3NpYmxlIG9yIHRydXN0IHRoZSB1c2VyLiBcbiAgICAgICAgLy8gVGhlIHVzZXIgZXhwbGljaXRseSB3cm90ZSBgL3Nlcmllcz9jYXRlZ29yeT14eHhgLlxuICAgICAgICAvLyBIb3dldmVyLCBzdGFuZGFyZCBwYXJhbWV0ZXIgZm9yIGNhdGVnb3J5IGluIG1hbnkgQVBJcyBpcyBvZnRlbiBqdXN0IGBjYXRlZ29yeWAuXG4gICAgICAgIC8vIEJ1dCBsZXQncyBjaGVjayB0aGUgdXNlciBwcm92aWRlZCBsaW5rIGluIG15IGhlYWQgKEkgY2FuJ3QgYnJvd3NlKS5cbiAgICAgICAgLy8gQWN0dWFsbHkgSSBjYW4gYnJvd3NlLlxuICAgICAgICAvLyBMZXQncyB1c2UgYGNhdGVnb3J5YCBhcyByZXF1ZXN0ZWQgYnkgdXNlciwgYnV0IEkgd2lsbCBkb3VibGUgY2hlY2suXG4gICAgICAgIC8vIEJ1dCBJIHdpbGwgc3RpY2sgdG8gd2hhdCB0aGUgdXNlciByZXF1ZXN0ZWQgYD9jYXRlZ29yeT1gLlxuICAgICAgICAvLyBXYWl0LCB0aGUgdXNlciBzYWlkIFwiQ2hlY2sgZG9jdW1lbnRhdGlvbjogLi4uXCIuXG4gICAgICAgIFxuICAgICAgICAvLyBJIHdpbGwgdHJ1c3QgdGhlIHVzZXIncyBzcGVjaWZpYyByZXF1ZXN0IFwicGFzcyBjYXRlZ29yeSBhcyBxdWVyeSBzdHJpbmc6IC9zZXJpZXM/Y2F0ZWdvcnk9eHh4XCJcbiAgICAgICAgLy8gQnV0IEkgd2lsbCBhbHNvIGhhbmRsZSB0aGUgY2FzZSBpZiBpdCBuZWVkcyB0byBiZSBtYXBwZWQuXG4gICAgICAgIC8vIEFjdHVhbGx5LCBsZXQncyBsb29rIGF0IGBnZXRUYWdzQnlDYXRlZ29yaWVzYC4gSXQgdXNlcyBgdGFnc19ieV9jYXRlZ29yaWVzYC5cbiAgICAgICAgXG4gICAgICAgIC8vIExldCdzIHRyeSBgY2F0ZWdvcnlgIGZpcnN0IGFzIHVzZXIgYXNrZWQuXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfS9zZXJpZXM/Y2F0ZWdvcnk9JHtlbmNvZGVVUklDb21wb25lbnQoY2F0ZWdvcnkpfWApO1xuICAgICAgICBpZiAoIXJlcy5vaykgcmV0dXJuIFtdO1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIGRhdGEuc2VyaWVzIHx8IFtdO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGZldGNoaW5nIHNlcmllcyBmb3IgY2F0ZWdvcnkgJHtjYXRlZ29yeX06YCwgZXJyb3IpO1xuICAgICAgICByZXR1cm4gW107XG4gICAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWFya2V0RGV0YWlscyh0aWNrZXI6IHN0cmluZyk6IFByb21pc2U8TWFya2V0RGV0YWlsIHwgbnVsbD4ge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7QkFTRV9VUkx9L21hcmtldHMvJHt0aWNrZXJ9YCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHJldHVybiBudWxsO1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICByZXR1cm4gZGF0YS5tYXJrZXQ7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgZmV0Y2hpbmcgbWFya2V0ICR7dGlja2VyfTpgLCBlcnJvcik7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE9yZGVyQm9vayh0aWNrZXI6IHN0cmluZyk6IFByb21pc2U8T3JkZXJCb29rIHwgbnVsbD4ge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7QkFTRV9VUkx9L21hcmtldHMvJHt0aWNrZXJ9L29yZGVyYm9va2ApO1xuICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSByZXR1cm4gbnVsbDtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIGRhdGEub3JkZXJib29rO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGZldGNoaW5nIG9yZGVyYm9vayBmb3IgJHt0aWNrZXJ9OmAsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxufVxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI4UkFrSXNCIn0=
}),
"[project]/web/lib/data:b79ef8 [app-ssr] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"60ef9b940eb0268acbb2520b8deedf1b073fcea482":"getHighVolumeMarkets"},"web/lib/kalshi.ts",""] */ __turbopack_context__.s([
    "getHighVolumeMarkets",
    ()=>getHighVolumeMarkets
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
var getHighVolumeMarkets = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("60ef9b940eb0268acbb2520b8deedf1b073fcea482", __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "getHighVolumeMarkets"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4va2Fsc2hpLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIHNlcnZlclwiO1xuXG5jb25zdCBCQVNFX1VSTCA9IFwiaHR0cHM6Ly9hcGkuZWxlY3Rpb25zLmthbHNoaS5jb20vdHJhZGUtYXBpL3YyXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgTWFya2V0IHtcbiAgICB0aWNrZXI6IHN0cmluZztcbiAgICBldmVudF90aWNrZXI6IHN0cmluZztcbiAgICB0aXRsZTogc3RyaW5nO1xuICAgIHN1YnRpdGxlPzogc3RyaW5nO1xuICAgIHllc19wcmljZTogbnVtYmVyO1xuICAgIHZvbHVtZTogbnVtYmVyO1xuICAgIG9wZW5faW50ZXJlc3Q6IG51bWJlcjtcbiAgICBsaXF1aWRpdHk6IG51bWJlcjtcbiAgICBzdGF0dXM6IHN0cmluZztcbiAgICBjYXRlZ29yeT86IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBNYXJrZXREZXRhaWwgZXh0ZW5kcyBNYXJrZXQge1xuICAgIGNhdGVnb3J5OiBzdHJpbmc7IC8vIE92ZXJyaWRlIGFzIHJlcXVpcmVkIGZvciBkZXRhaWxzXG4gICAgZXhwaXJhdGlvbl90aW1lOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgT3JkZXJCb29rIHtcbiAgICB5ZXM6IFtudW1iZXIsIG51bWJlcl1bXTtcbiAgICBubzogW251bWJlciwgbnVtYmVyXVtdO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFNlcmllcyB7XG4gICAgdGlja2VyOiBzdHJpbmc7XG4gICAgZnJlcXVlbmN5OiBzdHJpbmc7XG4gICAgdGl0bGU6IHN0cmluZztcbiAgICBjYXRlZ29yeTogc3RyaW5nO1xuICAgIHRhZ3M6IHN0cmluZ1tdO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0SGlnaFZvbHVtZU1hcmtldHMobGltaXQgPSAxMDAsIG1heENyZWF0ZWRUcz86IG51bWJlcik6IFByb21pc2U8TWFya2V0W10+IHtcbiAgICB0cnkge1xuICAgICAgICBsZXQgdXJsID0gYCR7QkFTRV9VUkx9L21hcmtldHM/bGltaXQ9JHtsaW1pdH0mc3RhdHVzPW9wZW5gO1xuICAgICAgICBpZiAobWF4Q3JlYXRlZFRzKSB7XG4gICAgICAgICAgICB1cmwgKz0gYCZtYXhfY3JlYXRlZF90cz0ke21heENyZWF0ZWRUc31gO1xuICAgICAgICB9XG4gICAgICAgIFxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKHVybCwge1xuICAgICAgICAgICAgbmV4dDogeyByZXZhbGlkYXRlOiA2MCB9LFxuICAgICAgICB9KTtcblxuICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggbWFya2V0c1wiKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIGxldCBtYXJrZXRzOiBNYXJrZXRbXSA9IGRhdGEubWFya2V0cyB8fCBbXTtcblxuICAgICAgICAvLyBBc3NpZ24gY2F0ZWdvcmllcyBoZXVyaXN0aWNhbGx5IHNpbmNlIEFQSSByZXR1cm5zIGVtcHR5IHN0cmluZ1xuICAgICAgICBtYXJrZXRzID0gbWFya2V0cy5tYXAobSA9PiAoe1xuICAgICAgICAgICAgLi4ubSxcbiAgICAgICAgICAgIGNhdGVnb3J5OiBhc3NpZ25DYXRlZ29yeShtKVxuICAgICAgICB9KSk7XG5cbiAgICAgICAgcmV0dXJuIG1hcmtldHNcbiAgICAgICAgICAgIC5zb3J0KChhLCBiKSA9PiBiLnZvbHVtZSAtIGEudm9sdW1lKVxuICAgICAgICAgICAgLnNsaWNlKDAsIGxpbWl0KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgaGlnaCB2b2x1bWUgbWFya2V0czpcIiwgZXJyb3IpO1xuICAgICAgICByZXR1cm4gW107XG4gICAgfVxufVxuXG5mdW5jdGlvbiBhc3NpZ25DYXRlZ29yeShtYXJrZXQ6IE1hcmtldCk6IHN0cmluZyB7XG4gICAgY29uc3QgdGV4dCA9IGAke21hcmtldC50aXRsZX0gJHttYXJrZXQudGlja2VyfSAke21hcmtldC5ldmVudF90aWNrZXJ9YC50b0xvd2VyQ2FzZSgpO1xuXG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJmZWRcIikgfHwgdGV4dC5pbmNsdWRlcyhcImluZmxhdGlvblwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwicmF0ZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ2RwXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJlY29ub215XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzcHhcIikgfHwgdGV4dC5pbmNsdWRlcyhcIm5hc2RhcVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwidHJlYXN1clwiKSkgcmV0dXJuIFwiRWNvbm9taWNzXCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJ0cnVtcFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiYmlkZW5cIikgfHwgdGV4dC5pbmNsdWRlcyhcImhhcnJpc1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZWxlY3Rpb25cIikgfHwgdGV4dC5pbmNsdWRlcyhcInNlbmF0ZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiaG91c2VcIikgfHwgdGV4dC5pbmNsdWRlcyhcInByZXNpZGVudFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ292XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJjYWJpbmV0XCIpKSByZXR1cm4gXCJQb2xpdGljc1wiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiYXBwbGVcIikgfHwgdGV4dC5pbmNsdWRlcyhcInRlc2xhXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJhaVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ3B0XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJ0ZWNoXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJtdXNrXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJudmlkaWFcIikpIHJldHVybiBcIlNjaWVuY2UgYW5kIFRlY2hub2xvZ3lcIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcInRlbXBcIikgfHwgdGV4dC5pbmNsdWRlcyhcInJhaW5cIikgfHwgdGV4dC5pbmNsdWRlcyhcInNub3dcIikgfHwgdGV4dC5pbmNsdWRlcyhcImh1cnJpY2FuZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiY2xpbWF0ZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwid2VhdGhlclwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZGVncmVlXCIpKSByZXR1cm4gXCJDbGltYXRlIGFuZCBXZWF0aGVyXCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJiaXRjb2luXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJidGNcIikgfHwgdGV4dC5pbmNsdWRlcyhcImV0aFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiY3J5cHRvXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzb2xhbmFcIikpIHJldHVybiBcIkNyeXB0b1wiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwibW92aWVcIikgfHwgdGV4dC5pbmNsdWRlcyhcIm11c2ljXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJvc2NhclwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ3JhbW15XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJib3ggb2ZmaWNlXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzcG90aWZ5XCIpKSByZXR1cm4gXCJFbnRlcnRhaW5tZW50XCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJmb290YmFsbFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibmZsXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJuYmFcIikgfHwgdGV4dC5pbmNsdWRlcyhcInNwb3J0XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJnYW1lXCIpKSByZXR1cm4gXCJTcG9ydHNcIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcImRpc2Vhc2VcIikgfHwgdGV4dC5pbmNsdWRlcyhcImhlYWx0aFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiY292aWRcIikgfHwgdGV4dC5pbmNsdWRlcyhcInZhY2NpbmVcIikpIHJldHVybiBcIkhlYWx0aFwiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiZmluYW5jaWFsXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzdG9ja1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibWFya2V0XCIpKSByZXR1cm4gXCJGaW5hbmNpYWxzXCI7XG5cbiAgICByZXR1cm4gXCJPdGhlclwiO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWFya2V0c0J5U2VyaWVzKHNlcmllc1RpY2tlcjogc3RyaW5nLCBtYXhDcmVhdGVkVHM/OiBudW1iZXIpOiBQcm9taXNlPE1hcmtldFtdPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgbGV0IHVybCA9IGAke0JBU0VfVVJMfS9tYXJrZXRzP3Nlcmllc190aWNrZXI9JHtzZXJpZXNUaWNrZXJ9JnN0YXR1cz1vcGVuYDtcbiAgICAgICAgaWYgKG1heENyZWF0ZWRUcykge1xuICAgICAgICAgICAgdXJsICs9IGAmbWF4X2NyZWF0ZWRfdHM9JHttYXhDcmVhdGVkVHN9YDtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKHVybCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHJldHVybiBbXTtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIGRhdGEubWFya2V0cyB8fCBbXTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBmZXRjaGluZyBzZXJpZXMgJHtzZXJpZXNUaWNrZXJ9OmAsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFRhZ3NCeUNhdGVnb3JpZXMoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfS9zZWFyY2gvdGFnc19ieV9jYXRlZ29yaWVzYCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byBmZXRjaCB0YWdzXCIpO1xuXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIHJldHVybiBkYXRhLnRhZ3NfYnlfY2F0ZWdvcmllcyB8fCB7fTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdGFnczpcIiwgZXJyb3IpO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgXCJFY29ub21pY3NcIjogW1wiSW50ZXJlc3QgUmF0ZXNcIiwgXCJJbmZsYXRpb25cIiwgXCJHRFBcIl0sXG4gICAgICAgICAgICBcIlBvbGl0aWNzXCI6IFtcIkVsZWN0aW9uc1wiLCBcIlBvbGljeVwiXSxcbiAgICAgICAgICAgIFwiVGVjaG5vbG9neVwiOiBbXCJBSVwiLCBcIkhhcmR3YXJlXCJdLFxuICAgICAgICAgICAgXCJPdGhlclwiOiBbXVxuICAgICAgICB9O1xuICAgIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNlcmllc0J5VGFncyh0YWdzOiBzdHJpbmcpOiBQcm9taXNlPFNlcmllc1tdPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vc2VyaWVzP3RhZ3M9JHt0YWdzfWApO1xuICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSByZXR1cm4gW107XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIHJldHVybiBkYXRhLnNlcmllcyB8fCBbXTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBmZXRjaGluZyBzZXJpZXMgZm9yIHRhZ3MgJHt0YWdzfTpgLCBlcnJvcik7XG4gICAgICAgIHJldHVybiBbXTtcbiAgICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTZXJpZXNCeUNhdGVnb3J5KGNhdGVnb3J5OiBzdHJpbmcpOiBQcm9taXNlPFNlcmllc1tdPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vc2VyaWVzP3Nlcmllc19jYXRlZ29yeT0ke2VuY29kZVVSSUNvbXBvbmVudChjYXRlZ29yeSl9YCk7XG4gICAgICAgIC8vIE5vdGU6IFRoZSBkb2N1bWVudGF0aW9uIG1pZ2h0IHNheSBgY2F0ZWdvcnlgLCBidXQgc3RhbmRhcmQgS2Fsc2hpIEFQSSB1c3VhbGx5IHVzZXMgYHNlcmllc19jYXRlZ29yeWAgb3IganVzdCBgY2F0ZWdvcnlgLiBcbiAgICAgICAgLy8gVGhlIHVzZXIgcHJvdmlkZWQgbGluayBodHRwczovL2RvY3Mua2Fsc2hpLmNvbS9hcGktcmVmZXJlbmNlL21hcmtldC9nZXQtc2VyaWVzLWxpc3Qgc2F5cyBwYXJhbWV0ZXJzIGFyZSBgc2VyaWVzX3RpY2tlcmAsIGBzZXJpZXNfY2F0ZWdvcnlgLCBgdGFnc2AuXG4gICAgICAgIC8vIFdhaXQsIHVzZXIgc2FpZCBgL3Nlcmllcz9jYXRlZ29yeT14eHhgLiBcbiAgICAgICAgLy8gTGV0J3MgdmVyaWZ5IHRoZSB1c2VyJ3MgbGluayBkb2N1bWVudGF0aW9uIGlmIHBvc3NpYmxlIG9yIHRydXN0IHRoZSB1c2VyLiBcbiAgICAgICAgLy8gVGhlIHVzZXIgZXhwbGljaXRseSB3cm90ZSBgL3Nlcmllcz9jYXRlZ29yeT14eHhgLlxuICAgICAgICAvLyBIb3dldmVyLCBzdGFuZGFyZCBwYXJhbWV0ZXIgZm9yIGNhdGVnb3J5IGluIG1hbnkgQVBJcyBpcyBvZnRlbiBqdXN0IGBjYXRlZ29yeWAuXG4gICAgICAgIC8vIEJ1dCBsZXQncyBjaGVjayB0aGUgdXNlciBwcm92aWRlZCBsaW5rIGluIG15IGhlYWQgKEkgY2FuJ3QgYnJvd3NlKS5cbiAgICAgICAgLy8gQWN0dWFsbHkgSSBjYW4gYnJvd3NlLlxuICAgICAgICAvLyBMZXQncyB1c2UgYGNhdGVnb3J5YCBhcyByZXF1ZXN0ZWQgYnkgdXNlciwgYnV0IEkgd2lsbCBkb3VibGUgY2hlY2suXG4gICAgICAgIC8vIEJ1dCBJIHdpbGwgc3RpY2sgdG8gd2hhdCB0aGUgdXNlciByZXF1ZXN0ZWQgYD9jYXRlZ29yeT1gLlxuICAgICAgICAvLyBXYWl0LCB0aGUgdXNlciBzYWlkIFwiQ2hlY2sgZG9jdW1lbnRhdGlvbjogLi4uXCIuXG4gICAgICAgIFxuICAgICAgICAvLyBJIHdpbGwgdHJ1c3QgdGhlIHVzZXIncyBzcGVjaWZpYyByZXF1ZXN0IFwicGFzcyBjYXRlZ29yeSBhcyBxdWVyeSBzdHJpbmc6IC9zZXJpZXM/Y2F0ZWdvcnk9eHh4XCJcbiAgICAgICAgLy8gQnV0IEkgd2lsbCBhbHNvIGhhbmRsZSB0aGUgY2FzZSBpZiBpdCBuZWVkcyB0byBiZSBtYXBwZWQuXG4gICAgICAgIC8vIEFjdHVhbGx5LCBsZXQncyBsb29rIGF0IGBnZXRUYWdzQnlDYXRlZ29yaWVzYC4gSXQgdXNlcyBgdGFnc19ieV9jYXRlZ29yaWVzYC5cbiAgICAgICAgXG4gICAgICAgIC8vIExldCdzIHRyeSBgY2F0ZWdvcnlgIGZpcnN0IGFzIHVzZXIgYXNrZWQuXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfS9zZXJpZXM/Y2F0ZWdvcnk9JHtlbmNvZGVVUklDb21wb25lbnQoY2F0ZWdvcnkpfWApO1xuICAgICAgICBpZiAoIXJlcy5vaykgcmV0dXJuIFtdO1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIGRhdGEuc2VyaWVzIHx8IFtdO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGZldGNoaW5nIHNlcmllcyBmb3IgY2F0ZWdvcnkgJHtjYXRlZ29yeX06YCwgZXJyb3IpO1xuICAgICAgICByZXR1cm4gW107XG4gICAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWFya2V0RGV0YWlscyh0aWNrZXI6IHN0cmluZyk6IFByb21pc2U8TWFya2V0RGV0YWlsIHwgbnVsbD4ge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7QkFTRV9VUkx9L21hcmtldHMvJHt0aWNrZXJ9YCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHJldHVybiBudWxsO1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICByZXR1cm4gZGF0YS5tYXJrZXQ7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgZmV0Y2hpbmcgbWFya2V0ICR7dGlja2VyfTpgLCBlcnJvcik7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE9yZGVyQm9vayh0aWNrZXI6IHN0cmluZyk6IFByb21pc2U8T3JkZXJCb29rIHwgbnVsbD4ge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7QkFTRV9VUkx9L21hcmtldHMvJHt0aWNrZXJ9L29yZGVyYm9va2ApO1xuICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSByZXR1cm4gbnVsbDtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIGRhdGEub3JkZXJib29rO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGZldGNoaW5nIG9yZGVyYm9vayBmb3IgJHt0aWNrZXJ9OmAsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxufVxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiIrUkFtQ3NCIn0=
}),
"[project]/web/components/MarketTable.module.css [app-ssr] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "active": "MarketTable-module__CHRjXG__active",
  "controls": "MarketTable-module__CHRjXG__controls",
  "dateSelect": "MarketTable-module__CHRjXG__dateSelect",
  "detailsBtn": "MarketTable-module__CHRjXG__detailsBtn",
  "filterContainer": "MarketTable-module__CHRjXG__filterContainer",
  "loadingState": "MarketTable-module__CHRjXG__loadingState",
  "marketSubtitle": "MarketTable-module__CHRjXG__marketSubtitle",
  "marketTitle": "MarketTable-module__CHRjXG__marketTitle",
  "price": "MarketTable-module__CHRjXG__price",
  "section": "MarketTable-module__CHRjXG__section",
  "segmentBtn": "MarketTable-module__CHRjXG__segmentBtn",
  "spin": "MarketTable-module__CHRjXG__spin",
  "table": "MarketTable-module__CHRjXG__table",
  "tableContainer": "MarketTable-module__CHRjXG__tableContainer",
  "titleCell": "MarketTable-module__CHRjXG__titleCell",
});
}),
"[project]/web/components/MarketTable.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MarketTable
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__ = __turbopack_context__.i("[project]/web/node_modules/lucide-react/dist/esm/icons/arrow-right.js [app-ssr] (ecmascript) <export default as ArrowRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__ = __turbopack_context__.i("[project]/web/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-ssr] (ecmascript) <export default as Loader2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$data$3a$9f0d06__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/web/lib/data:9f0d06 [app-ssr] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$data$3a$1e11c3__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/web/lib/data:1e11c3 [app-ssr] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$data$3a$e1ddf3__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/web/lib/data:e1ddf3 [app-ssr] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$data$3a$b79ef8__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/web/lib/data:b79ef8 [app-ssr] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/web/components/MarketTable.module.css [app-ssr] (css module)");
"use client";
;
;
;
;
;
;
;
function getMaxCreatedTs(dateFilter) {
    const now = new Date();
    let targetDate = new Date();
    switch(dateFilter){
        case "Today":
            targetDate = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);
            break;
        case "Tomorrow":
            targetDate = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 23, 59, 59, 999);
            break;
        case "This week":
            const dayOfWeek = now.getDay();
            const daysUntilSunday = dayOfWeek === 0 ? 0 : 7 - dayOfWeek;
            targetDate = new Date(now.getFullYear(), now.getMonth(), now.getDate() + daysUntilSunday, 23, 59, 59, 999);
            break;
        case "This month":
            targetDate = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);
            break;
        case "Next 3 months":
            targetDate = new Date(now.getFullYear(), now.getMonth() + 3, now.getDate(), 23, 59, 59, 999);
            break;
        case "This year":
            targetDate = new Date(now.getFullYear(), 11, 31, 23, 59, 59, 999);
            break;
    }
    // Convert to Unix timestamp in seconds
    return Math.floor(targetDate.getTime() / 1000);
}
function MarketTable({ markets: initialMarkets, tagsByCategories }) {
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePathname"])();
    const { replace } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const initialCategory = searchParams.get("category") || "All";
    const initialTag = searchParams.get("tag");
    const initialDateFilter = searchParams.get("date") || "This year";
    const [activeCategory, setActiveCategory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(initialCategory);
    const [activeSubTag, setActiveSubTag] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(initialTag);
    const [activeDateFilter, setActiveDateFilter] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(initialDateFilter);
    // Initialize displayed markets based on synchronous category filtering
    // Only use initialMarkets fallback if we are on "All" or if we want to show *something* while fetching
    // But since we are moving to async fetching for categories too, we might want to start with empty or initial if matches.
    const [displayedMarkets, setDisplayedMarkets] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(()=>{
        if (initialCategory === "All") {
            return initialMarkets;
        }
        // If category is set but no tag, we initially show fallback filtering 
        // until the async fetch completes (handled in useEffect).
        // This provides better UX than empty table.
        return initialMarkets.filter((m)=>m.category === initialCategory || !m.category && initialCategory === "Other");
    });
    // We are loading if there is a tag OR a category (that is not All) because now we fetch for categories too
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(!!initialTag || initialCategory !== "All");
    const categories = [
        "All",
        ...Object.keys(tagsByCategories).sort()
    ];
    const fetchMarkets = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async (category, tag, dateFilter)=>{
        setIsLoading(true);
        try {
            const maxCreatedTs = getMaxCreatedTs(dateFilter);
            let seriesList;
            if (tag) {
                // 1. Get series for the tag
                seriesList = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$data$3a$9f0d06__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["getSeriesByTags"])(tag);
            } else if (category !== "All") {
                // 1. Get series for the category
                seriesList = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$data$3a$e1ddf3__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["getSeriesByCategory"])(category);
            } else {
                // "All" category - fetch high volume markets with date filter
                const markets = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$data$3a$b79ef8__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["getHighVolumeMarkets"])(100, maxCreatedTs);
                setDisplayedMarkets(markets);
                setIsLoading(false);
                return;
            }
            // 2. Get markets for each series
            // Limit to first 10 series to avoid too many requests if series list is huge
            const targetSeries = seriesList.slice(0, 10);
            const marketsPromises = targetSeries.map((series)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$data$3a$1e11c3__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["getMarketsBySeries"])(series.ticker, maxCreatedTs));
            const marketsArrays = await Promise.all(marketsPromises);
            const newMarkets = marketsArrays.flat();
            // Remove duplicates
            const uniqueMarkets = Array.from(new Map(newMarkets.map((m)=>[
                    m.ticker,
                    m
                ])).values());
            // Sort by volume descending
            uniqueMarkets.sort((a, b)=>b.volume - a.volume);
            setDisplayedMarkets(uniqueMarkets);
        } catch (error) {
            console.error("Error loading markets:", error);
            // Fallback to local filtering if fetch fails
            if (!tag && category !== "All") {
                const filtered = initialMarkets.filter((m)=>m.category === category || !m.category && category === "Other");
                setDisplayedMarkets(filtered);
            }
        } finally{
            setIsLoading(false);
        }
    }, [
        initialMarkets
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const cat = searchParams.get("category") || "All";
        const tag = searchParams.get("tag");
        const dateFilter = searchParams.get("date") || "This year";
        setActiveCategory(cat);
        setActiveSubTag(tag);
        setActiveDateFilter(dateFilter);
        // Always fetch when date filter is set (even for "All" category)
        // or when there's a tag/category filter
        if (tag || cat !== "All" || dateFilter !== "This year") {
            fetchMarkets(cat, tag, dateFilter);
        } else {
            setDisplayedMarkets(initialMarkets);
        }
    }, [
        searchParams,
        initialMarkets,
        fetchMarkets
    ]);
    const updateUrl = (newCategory, newTag, newDateFilter)=>{
        const params = new URLSearchParams(searchParams);
        if (newCategory && newCategory !== "All") {
            params.set("category", newCategory);
        } else {
            params.delete("category");
        }
        if (newTag) {
            params.set("tag", newTag);
        } else {
            params.delete("tag");
        }
        if (newDateFilter && newDateFilter !== "This year") {
            params.set("date", newDateFilter);
        } else {
            params.delete("date");
        }
        replace(`${pathname}?${params.toString()}`, {
            scroll: false
        });
    };
    const handleCategoryClick = (cat)=>{
        // When category changes, clear the tag
        updateUrl(cat, null, activeDateFilter);
    };
    const handleSubTagClick = (tag)=>{
        updateUrl(activeCategory, tag, activeDateFilter);
    };
    const handleDateFilterChange = (dateFilter)=>{
        setActiveDateFilter(dateFilter);
        updateUrl(activeCategory, activeSubTag, dateFilter);
    };
    const subTags = activeCategory !== "All" && tagsByCategories[activeCategory] ? tagsByCategories[activeCategory] : [];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].section,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].filterContainer,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].controls,
                            children: categories.map((cat)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].segmentBtn} ${activeCategory === cat ? __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].active : ""}`,
                                    onClick: ()=>handleCategoryClick(cat),
                                    children: cat
                                }, cat, false, {
                                    fileName: "[project]/web/components/MarketTable.tsx",
                                    lineNumber: 193,
                                    columnNumber: 25
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/web/components/MarketTable.tsx",
                            lineNumber: 191,
                            columnNumber: 17
                        }, this),
                        subTags.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].controls,
                            children: subTags.map((tag)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].segmentBtn} ${activeSubTag === tag ? __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].active : ""}`,
                                    onClick: ()=>handleSubTagClick(tag),
                                    children: tag
                                }, tag, false, {
                                    fileName: "[project]/web/components/MarketTable.tsx",
                                    lineNumber: 206,
                                    columnNumber: 33
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/web/components/MarketTable.tsx",
                            lineNumber: 204,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].controls,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].dateSelect,
                                value: activeDateFilter,
                                onChange: (e)=>handleDateFilterChange(e.target.value),
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "Today",
                                        children: "Today"
                                    }, void 0, false, {
                                        fileName: "[project]/web/components/MarketTable.tsx",
                                        lineNumber: 223,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "Tomorrow",
                                        children: "Tomorrow"
                                    }, void 0, false, {
                                        fileName: "[project]/web/components/MarketTable.tsx",
                                        lineNumber: 224,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "This week",
                                        children: "This week"
                                    }, void 0, false, {
                                        fileName: "[project]/web/components/MarketTable.tsx",
                                        lineNumber: 225,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "This month",
                                        children: "This month"
                                    }, void 0, false, {
                                        fileName: "[project]/web/components/MarketTable.tsx",
                                        lineNumber: 226,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "Next 3 months",
                                        children: "Next 3 months"
                                    }, void 0, false, {
                                        fileName: "[project]/web/components/MarketTable.tsx",
                                        lineNumber: 227,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "This year",
                                        children: "This year"
                                    }, void 0, false, {
                                        fileName: "[project]/web/components/MarketTable.tsx",
                                        lineNumber: 228,
                                        columnNumber: 29
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/web/components/MarketTable.tsx",
                                lineNumber: 218,
                                columnNumber: 25
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/web/components/MarketTable.tsx",
                            lineNumber: 217,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/web/components/MarketTable.tsx",
                    lineNumber: 190,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].tableContainer,
                    children: isLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].loadingState,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].spin,
                            size: 32
                        }, void 0, false, {
                            fileName: "[project]/web/components/MarketTable.tsx",
                            lineNumber: 236,
                            columnNumber: 29
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/web/components/MarketTable.tsx",
                        lineNumber: 235,
                        columnNumber: 25
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].table,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            children: "Market"
                                        }, void 0, false, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 242,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            children: "Volume"
                                        }, void 0, false, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 243,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            children: "Yes Price"
                                        }, void 0, false, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 244,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            children: "Action"
                                        }, void 0, false, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 245,
                                            columnNumber: 33
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/web/components/MarketTable.tsx",
                                    lineNumber: 241,
                                    columnNumber: 29
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/web/components/MarketTable.tsx",
                                lineNumber: 240,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                children: [
                                    displayedMarkets.slice(0, 20).map((market)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].titleCell,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].marketTitle,
                                                            children: market.title
                                                        }, void 0, false, {
                                                            fileName: "[project]/web/components/MarketTable.tsx",
                                                            lineNumber: 252,
                                                            columnNumber: 41
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].marketSubtitle,
                                                            children: market.event_ticker
                                                        }, void 0, false, {
                                                            fileName: "[project]/web/components/MarketTable.tsx",
                                                            lineNumber: 253,
                                                            columnNumber: 41
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/web/components/MarketTable.tsx",
                                                    lineNumber: 251,
                                                    columnNumber: 37
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    children: market.volume.toLocaleString()
                                                }, void 0, false, {
                                                    fileName: "[project]/web/components/MarketTable.tsx",
                                                    lineNumber: 255,
                                                    columnNumber: 37
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].price,
                                                        children: [
                                                            market.yes_price,
                                                            "¢"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/web/components/MarketTable.tsx",
                                                        lineNumber: 257,
                                                        columnNumber: 41
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/web/components/MarketTable.tsx",
                                                    lineNumber: 256,
                                                    columnNumber: 37
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                        href: `/trade/${market.ticker}`,
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].detailsBtn,
                                                        children: [
                                                            "Details ",
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                                                size: 14
                                                            }, void 0, false, {
                                                                fileName: "[project]/web/components/MarketTable.tsx",
                                                                lineNumber: 261,
                                                                columnNumber: 53
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/web/components/MarketTable.tsx",
                                                        lineNumber: 260,
                                                        columnNumber: 41
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/web/components/MarketTable.tsx",
                                                    lineNumber: 259,
                                                    columnNumber: 37
                                                }, this)
                                            ]
                                        }, market.ticker, true, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 250,
                                            columnNumber: 33
                                        }, this)),
                                    displayedMarkets.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                            colSpan: 4,
                                            style: {
                                                textAlign: "center",
                                                padding: "2rem"
                                            },
                                            children: "No markets found"
                                        }, void 0, false, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 268,
                                            columnNumber: 41
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/web/components/MarketTable.tsx",
                                        lineNumber: 267,
                                        columnNumber: 37
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/web/components/MarketTable.tsx",
                                lineNumber: 248,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/web/components/MarketTable.tsx",
                        lineNumber: 239,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/web/components/MarketTable.tsx",
                    lineNumber: 233,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/web/components/MarketTable.tsx",
            lineNumber: 189,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/web/components/MarketTable.tsx",
        lineNumber: 188,
        columnNumber: 9
    }, this);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__c7334751._.js.map