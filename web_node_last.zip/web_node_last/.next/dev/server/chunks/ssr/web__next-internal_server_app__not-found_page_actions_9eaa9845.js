module.exports = [
"[project]/web/.next-internal/server/app/_not-found/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=web__next-internal_server_app__not-found_page_actions_9eaa9845.js.map