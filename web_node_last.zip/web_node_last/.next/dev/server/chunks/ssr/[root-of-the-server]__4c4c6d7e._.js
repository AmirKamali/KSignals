module.exports = [
"[project]/web/app/favicon.ico.mjs { IMAGE => \"[project]/web/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/web/app/favicon.ico.mjs { IMAGE => \"[project]/web/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/web/app/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/web/app/layout.tsx [app-rsc] (ecmascript)"));
}),
"[project]/web/lib/kalshi.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getBackendMarkets",
    ()=>getBackendMarkets,
    "getHighVolumeMarkets",
    ()=>getHighVolumeMarkets,
    "getMarketDetails",
    ()=>getMarketDetails,
    "getMarketsBySeries",
    ()=>getMarketsBySeries,
    "getOrderBook",
    ()=>getOrderBook,
    "getSeriesByCategory",
    ()=>getSeriesByCategory,
    "getSeriesByTags",
    ()=>getSeriesByTags,
    "getTagsByCategories",
    ()=>getTagsByCategories
]);
const BACKEND_BASE_URL = process.env.BACKEND_API_BASE_URL ?? "http://localhost:3006";
const KALSHI_BASE_URL = "https://api.elections.kalshi.com/trade-api/v2";
async function getHighVolumeMarkets(limit = 100) {
    const backend = await getBackendMarkets({
        pageSize: limit
    });
    if (backend.markets.length > 0) {
        return backend.markets.sort((a, b)=>b.volume - a.volume).slice(0, limit);
    }
    // Fallback to Kalshi directly if backend is unavailable
    try {
        const response = await fetch(`${KALSHI_BASE_URL}/markets?limit=${limit}&status=open`, {
            next: {
                revalidate: 60
            }
        });
        if (!response.ok) {
            console.warn(`Kalshi API returned ${response.status}`);
            return [];
        }
        const data = await response.json();
        const markets = data.markets || [];
        return markets.sort((a, b)=>b.volume - a.volume).slice(0, limit);
    } catch (error) {
        console.warn("Fallback fetch from Kalshi failed:", error);
        return [];
    }
}
async function getMarketsBySeries(seriesTicker, maxCloseTs = null) {
    try {
        let url = `${KALSHI_BASE_URL}/markets?series_ticker=${seriesTicker}&status=open`;
        if (maxCloseTs) {
            url += `&max_close_ts=${maxCloseTs}`;
        }
        const controller = new AbortController();
        const timeoutId = setTimeout(()=>controller.abort(), 10000); // 10 second timeout
        const response = await fetch(url, {
            signal: controller.signal,
            next: {
                revalidate: 60
            }
        });
        clearTimeout(timeoutId);
        if (!response.ok) {
            console.warn(`API returned ${response.status} for series ${seriesTicker}`);
            return [];
        }
        const data = await response.json();
        return data.markets || [];
    } catch (error) {
        if (error instanceof Error && error.name === 'AbortError') {
            console.error(`Request timeout for series ${seriesTicker}`);
        } else {
            console.error(`Error fetching series ${seriesTicker}:`, error);
        }
        return [];
    }
}
async function getTagsByCategories() {
    try {
        const response = await fetch(`${BACKEND_BASE_URL}/api/events/categories`, {
            next: {
                revalidate: 300
            }
        });
        if (!response.ok) {
            console.warn(`Backend tags response ${response.status}`);
            throw new Error("Failed to fetch tags");
        }
        const data = await response.json();
        const tags = data.tagsByCategories || data.tags_by_categories;
        return tags || {};
    } catch (error) {
        console.warn("Error fetching tags from backend, using defaults:", error);
        return {
            "Economics": [
                "Interest Rates",
                "Inflation",
                "GDP"
            ],
            "Politics": [
                "Elections",
                "Policy"
            ],
            "Technology": [
                "AI",
                "Hardware"
            ],
            "Other": []
        };
    }
}
async function getSeriesByTags(tags) {
    try {
        const response = await fetch(`${KALSHI_BASE_URL}/series?tags=${tags}`);
        if (!response.ok) return [];
        const data = await response.json();
        return data.series || [];
    } catch (error) {
        console.error(`Error fetching series for tags ${tags}:`, error);
        return [];
    }
}
async function getSeriesByCategory(category) {
    try {
        const res = await fetch(`${KALSHI_BASE_URL}/series?series_category=${encodeURIComponent(category)}`);
        if (!res.ok) return [];
        const data = await res.json();
        return data.series || [];
    } catch (error) {
        console.error(`Error fetching series for category ${category}:`, error);
        return [];
    }
}
async function getMarketDetails(ticker) {
    try {
        const response = await fetch(`${KALSHI_BASE_URL}/markets/${ticker}`);
        if (!response.ok) return null;
        const data = await response.json();
        return data.market;
    } catch (error) {
        console.error(`Error fetching market ${ticker}:`, error);
        return null;
    }
}
async function getOrderBook(ticker) {
    try {
        const response = await fetch(`${KALSHI_BASE_URL}/markets/${ticker}/orderbook`);
        if (!response.ok) return null;
        const data = await response.json();
        return data.orderbook;
    } catch (error) {
        console.error(`Error fetching orderbook for ${ticker}:`, error);
        return null;
    }
}
async function getBackendMarkets(params) {
    // Use Next.js API route for client-side calls, direct backend for server-side
    const isServer = ("TURBOPACK compile-time value", "undefined") === 'undefined';
    const baseUrl = ("TURBOPACK compile-time truthy", 1) ? BACKEND_BASE_URL : "TURBOPACK unreachable";
    const endpoint = ("TURBOPACK compile-time truthy", 1) ? '/api/markets' : "TURBOPACK unreachable";
    const url = new URL(endpoint, ("TURBOPACK compile-time truthy", 1) ? baseUrl : "TURBOPACK unreachable");
    if (params?.category) url.searchParams.set("category", params.category);
    if (params?.tag) url.searchParams.set("tag", params.tag);
    // Default to next 30 days when no filter is provided; allow explicit null to mean all_time
    const closeDateType = params?.close_date_type === undefined ? "next_30_days" : params.close_date_type;
    if (closeDateType) url.searchParams.set("close_date_type", closeDateType);
    if (params?.query) url.searchParams.set("query", params.query);
    url.searchParams.set("sort_type", params?.sort ?? "volume");
    url.searchParams.set("direction", params?.direction ?? "desc");
    if (params?.page && params.page > 1) url.searchParams.set("page", params.page.toString());
    if (params?.pageSize) url.searchParams.set("pageSize", params.pageSize.toString());
    try {
        const response = await fetch(url.toString(), {
            cache: 'no-store'
        });
        if (!response.ok) {
            console.warn(`Backend markets response ${response.status}`);
            return {
                markets: [],
                totalPages: 0,
                totalCount: 0,
                currentPage: params?.page ?? 1,
                pageSize: params?.pageSize ?? 50
            };
        }
        const data = await response.json();
        const markets = (data.markets || []).map(normalizeBackendMarket);
        const totalPages = Number(data.totalPages ?? 0);
        const totalCount = Number(data.count ?? markets.length);
        const currentPage = Number(data.currentPage ?? params?.page ?? 1);
        const pageSize = Number(data.pageSize ?? params?.pageSize ?? 50);
        return {
            markets,
            totalPages,
            totalCount,
            currentPage,
            pageSize,
            sort: data.sort_type ?? data.sort ?? params?.sort ?? "volume",
            direction: data.direction ?? params?.direction ?? "desc"
        };
    } catch (error) {
        console.warn("Falling back: unable to fetch backend markets", error instanceof Error ? error.message : error);
        return {
            markets: [],
            totalPages: 0,
            totalCount: 0,
            currentPage: params?.page ?? 1,
            pageSize: params?.pageSize ?? 50
        };
    }
}
function normalizeBackendMarket(raw) {
    const ticker = raw.tickerId ?? raw.ticker;
    const seriesTicker = raw.seriesTicker ?? raw.eventTicker ?? ticker;
    // Prefer lastPrice over yesBid as yesBid is often 0
    const lastPrice = raw.lastPrice;
    const noBid = raw.noBid ?? raw.no_price ?? raw.noPrice;
    const noAsk = raw.noAsk ?? raw.no_ask;
    const noPrice = noBid ?? noAsk;
    const yesBid = raw.yesBid ?? raw.yes_price ?? raw.yesPrice;
    const yesPrice = lastPrice ?? yesBid ?? (typeof noPrice === "number" ? Math.max(0, 100 - noPrice) : 0);
    const previousYesPrice = raw.previousPrice ?? raw.previousYesBid ?? raw.previous_yes_price ?? raw.previous_yes_bid;
    const previousNoPrice = raw.previousNoBid ?? raw.previous_no_price ?? raw.previous_no_bid ?? (typeof previousYesPrice === "number" ? 100 - previousYesPrice : undefined);
    const liquidity = raw.liquidity;
    const volume = raw.volume;
    const closeTime = raw.closeTime ?? raw.close_time;
    return {
        ticker: ticker ?? "",
        event_ticker: seriesTicker ?? "",
        title: raw.title ?? "",
        subtitle: raw.subtitle ?? "",
        yes_price: yesPrice,
        no_price: noPrice ?? (typeof yesPrice === "number" ? Math.max(0, 100 - yesPrice) : undefined),
        previous_yes_price: previousYesPrice,
        previous_no_price: previousNoPrice,
        volume: volume ?? 0,
        open_interest: liquidity ?? 0,
        liquidity: liquidity ?? 0,
        status: raw.status ?? "",
        category: raw.category ?? seriesTicker ?? "",
        close_time: closeTime,
        closeTime: closeTime
    };
}
}),
"[project]/web/components/MarketTable.module.css [app-rsc] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "active": "MarketTable-module__CHRjXG__active",
  "calendarIcon": "MarketTable-module__CHRjXG__calendarIcon",
  "clearButton": "MarketTable-module__CHRjXG__clearButton",
  "controls": "MarketTable-module__CHRjXG__controls",
  "dateApply": "MarketTable-module__CHRjXG__dateApply",
  "dateFilterContainer": "MarketTable-module__CHRjXG__dateFilterContainer",
  "dateSelect": "MarketTable-module__CHRjXG__dateSelect",
  "delta": "MarketTable-module__CHRjXG__delta",
  "filterContainer": "MarketTable-module__CHRjXG__filterContainer",
  "loadingState": "MarketTable-module__CHRjXG__loadingState",
  "marketSubtitle": "MarketTable-module__CHRjXG__marketSubtitle",
  "marketTitle": "MarketTable-module__CHRjXG__marketTitle",
  "noPrice": "MarketTable-module__CHRjXG__noPrice",
  "pageButton": "MarketTable-module__CHRjXG__pageButton",
  "pageIndicator": "MarketTable-module__CHRjXG__pageIndicator",
  "pagination": "MarketTable-module__CHRjXG__pagination",
  "price": "MarketTable-module__CHRjXG__price",
  "priceCell": "MarketTable-module__CHRjXG__priceCell",
  "searchBar": "MarketTable-module__CHRjXG__searchBar",
  "searchButton": "MarketTable-module__CHRjXG__searchButton",
  "searchIcon": "MarketTable-module__CHRjXG__searchIcon",
  "searchInput": "MarketTable-module__CHRjXG__searchInput",
  "section": "MarketTable-module__CHRjXG__section",
  "segmentBtn": "MarketTable-module__CHRjXG__segmentBtn",
  "sortActive": "MarketTable-module__CHRjXG__sortActive",
  "sortButton": "MarketTable-module__CHRjXG__sortButton",
  "sortIcon": "MarketTable-module__CHRjXG__sortIcon",
  "spin": "MarketTable-module__CHRjXG__spin",
  "table": "MarketTable-module__CHRjXG__table",
  "tableContainer": "MarketTable-module__CHRjXG__tableContainer",
  "titleCell": "MarketTable-module__CHRjXG__titleCell",
  "titleLink": "MarketTable-module__CHRjXG__titleLink",
  "trend": "MarketTable-module__CHRjXG__trend",
  "trendDown": "MarketTable-module__CHRjXG__trendDown",
  "trendIcon": "MarketTable-module__CHRjXG__trendIcon",
  "trendUp": "MarketTable-module__CHRjXG__trendUp",
});
}),
"[project]/web/app/markets/page.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MarketsPage,
    "dynamic",
    ()=>dynamic
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$kalshi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/lib/kalshi.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/web/components/MarketTable.module.css [app-rsc] (css module)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/client/app-dir/link.react-server.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__ = __turbopack_context__.i("[project]/web/node_modules/lucide-react/dist/esm/icons/calendar.js [app-rsc] (ecmascript) <export default as Calendar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__ = __turbopack_context__.i("[project]/web/node_modules/lucide-react/dist/esm/icons/search.js [app-rsc] (ecmascript) <export default as Search>");
;
;
;
;
;
const dynamic = "force-dynamic";
const PAGE_SIZE = 20;
function buildQuery(params) {
    const search = new URLSearchParams();
    Object.entries(params).forEach(([key, value])=>{
        if (value === null || value === undefined || value === "") return;
        search.set(key, String(value));
    });
    return search.toString();
}
async function MarketsPage({ searchParams }) {
    const params = await searchParams;
    const categoryParam = typeof params.category === "string" ? params.category : undefined;
    const tagParam = typeof params.tag === "string" ? params.tag : undefined;
    const dateParam = typeof params.date === "string" ? params.date : "next_30_days";
    const sortParam = typeof params.sort_type === "string" ? params.sort_type : "volume";
    const dirParam = typeof params.direction === "string" ? params.direction : "desc";
    const pageParam = typeof params.page === "string" ? parseInt(params.page, 10) : 1;
    const queryParam = typeof params.query === "string" ? params.query : "";
    const activeCategory = categoryParam || "All";
    const activeTag = tagParam || null;
    const activeDate = dateParam || "next_30_days";
    const activeSort = sortParam;
    const sortDirection = dirParam === "asc" ? "asc" : "desc";
    const currentPage = Math.max(1, pageParam || 1);
    const query = queryParam || "";
    const hasQuery = query.trim().length > 0;
    const tagsByCategories = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$kalshi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getTagsByCategories"])();
    const backendResponse = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$kalshi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getBackendMarkets"])({
        category: activeCategory !== "All" ? activeCategory : null,
        tag: activeTag,
        close_date_type: activeDate !== "all_time" ? activeDate : null,
        sort: activeSort,
        direction: sortDirection,
        page: currentPage,
        pageSize: PAGE_SIZE,
        query: query || null
    });
    const categories = [
        "All",
        ...Object.keys(tagsByCategories).sort()
    ];
    const dateOptions = [
        {
            value: "all_time",
            label: "All time"
        },
        {
            value: "next_24_hr",
            label: "Next 24 Hours"
        },
        {
            value: "next_48_hr",
            label: "Next 48 Hours"
        },
        {
            value: "next_7_days",
            label: "Next 7 Days"
        },
        {
            value: "next_30_days",
            label: "Next 30 Days"
        },
        {
            value: "next_90_days",
            label: "Next 90 Days"
        },
        {
            value: "this_year",
            label: "This Year"
        },
        {
            value: "next_year",
            label: "Next Year"
        }
    ];
    const subTags = activeCategory !== "All" && tagsByCategories[activeCategory] ? tagsByCategories[activeCategory] : [];
    const markets = backendResponse.markets || [];
    const totalPages = Math.max(1, backendResponse.totalPages || 1);
    const totalCount = backendResponse.totalCount || markets.length;
    const normalizedQuery = hasQuery ? query.trim().toLowerCase() : null;
    const filteredMarkets = normalizedQuery ? markets.filter((m)=>{
        const fields = [
            m.title,
            m.subtitle,
            m.ticker,
            m.event_ticker
        ].filter(Boolean);
        return fields.some((f)=>f.toLowerCase().includes(normalizedQuery));
    }) : markets;
    const renderMarkets = filteredMarkets;
    const renderTotalCount = normalizedQuery ? filteredMarkets.length : totalCount;
    const renderTotalPages = normalizedQuery ? 1 : totalPages;
    const renderCurrentPage = normalizedQuery ? 1 : currentPage;
    const makeLink = (overrides)=>{
        const queryString = buildQuery({
            category: activeCategory !== "All" ? activeCategory : null,
            tag: activeTag,
            date: activeDate,
            sort_type: activeSort,
            direction: sortDirection,
            page: currentPage,
            query,
            ...overrides
        });
        return `/markets?${queryString}`;
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].section,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].filterContainer,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].controls,
                                children: categories.map((cat)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                        href: makeLink({
                                            category: cat === "All" ? null : cat,
                                            tag: null,
                                            page: 1
                                        }),
                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].segmentBtn} ${activeCategory === cat ? __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].active : ""}`,
                                        children: cat
                                    }, cat, false, {
                                        fileName: "[project]/web/app/markets/page.tsx",
                                        lineNumber: 124,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/web/app/markets/page.tsx",
                                lineNumber: 122,
                                columnNumber: 13
                            }, this),
                            subTags.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].controls,
                                children: subTags.map((tag)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                        href: makeLink({
                                            tag,
                                            page: 1
                                        }),
                                        className: `${__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].segmentBtn} ${activeTag === tag ? __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].active : ""}`,
                                        children: tag
                                    }, tag, false, {
                                        fileName: "[project]/web/app/markets/page.tsx",
                                        lineNumber: 137,
                                        columnNumber: 19
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/web/app/markets/page.tsx",
                                lineNumber: 135,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].dateFilterContainer,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__["Calendar"], {
                                        size: 16,
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].calendarIcon
                                    }, void 0, false, {
                                        fileName: "[project]/web/app/markets/page.tsx",
                                        lineNumber: 149,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                        name: "date",
                                        defaultValue: activeDate,
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].dateSelect,
                                        "data-href-prefix": "/markets",
                                        "data-category": activeCategory !== "All" ? activeCategory : "",
                                        "data-tag": activeTag ?? "",
                                        "data-sort": activeSort,
                                        "data-direction": sortDirection,
                                        "data-query": hasQuery ? query : "",
                                        "data-pagesize": PAGE_SIZE.toString(),
                                        children: dateOptions.map((option)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: option.value,
                                                children: option.label
                                            }, option.value, false, {
                                                fileName: "[project]/web/app/markets/page.tsx",
                                                lineNumber: 163,
                                                columnNumber: 19
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/web/app/markets/page.tsx",
                                        lineNumber: 150,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/web/app/markets/page.tsx",
                                lineNumber: 148,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/web/app/markets/page.tsx",
                        lineNumber: 121,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                        action: "/markets",
                        method: "GET",
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].searchBar,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "hidden",
                                name: "category",
                                value: activeCategory !== "All" ? activeCategory : ""
                            }, void 0, false, {
                                fileName: "[project]/web/app/markets/page.tsx",
                                lineNumber: 172,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "hidden",
                                name: "tag",
                                value: activeTag ?? ""
                            }, void 0, false, {
                                fileName: "[project]/web/app/markets/page.tsx",
                                lineNumber: 173,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "hidden",
                                name: "date",
                                value: activeDate
                            }, void 0, false, {
                                fileName: "[project]/web/app/markets/page.tsx",
                                lineNumber: 174,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "hidden",
                                name: "sort_type",
                                value: activeSort
                            }, void 0, false, {
                                fileName: "[project]/web/app/markets/page.tsx",
                                lineNumber: 175,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "hidden",
                                name: "direction",
                                value: sortDirection
                            }, void 0, false, {
                                fileName: "[project]/web/app/markets/page.tsx",
                                lineNumber: 176,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "hidden",
                                name: "page",
                                value: "1"
                            }, void 0, false, {
                                fileName: "[project]/web/app/markets/page.tsx",
                                lineNumber: 177,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "hidden",
                                name: "pageSize",
                                value: PAGE_SIZE
                            }, void 0, false, {
                                fileName: "[project]/web/app/markets/page.tsx",
                                lineNumber: 178,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__["Search"], {
                                size: 18,
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].searchIcon,
                                "aria-hidden": true
                            }, void 0, false, {
                                fileName: "[project]/web/app/markets/page.tsx",
                                lineNumber: 179,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "text",
                                name: "query",
                                defaultValue: query,
                                placeholder: "Search markets by title or ticker",
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].searchInput
                            }, void 0, false, {
                                fileName: "[project]/web/app/markets/page.tsx",
                                lineNumber: 180,
                                columnNumber: 13
                            }, this),
                            hasQuery && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                href: makeLink({
                                    query: null,
                                    page: 1
                                }),
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].clearButton,
                                children: "Clear"
                            }, void 0, false, {
                                fileName: "[project]/web/app/markets/page.tsx",
                                lineNumber: 188,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "submit",
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].searchButton,
                                children: "Search"
                            }, void 0, false, {
                                fileName: "[project]/web/app/markets/page.tsx",
                                lineNumber: 192,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/web/app/markets/page.tsx",
                        lineNumber: 171,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].tableContainer,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].table,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                children: "Market"
                                            }, void 0, false, {
                                                fileName: "[project]/web/app/markets/page.tsx",
                                                lineNumber: 201,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                children: "Volume"
                                            }, void 0, false, {
                                                fileName: "[project]/web/app/markets/page.tsx",
                                                lineNumber: 202,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                children: "Yes Price"
                                            }, void 0, false, {
                                                fileName: "[project]/web/app/markets/page.tsx",
                                                lineNumber: 203,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                children: "No Price"
                                            }, void 0, false, {
                                                fileName: "[project]/web/app/markets/page.tsx",
                                                lineNumber: 204,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/web/app/markets/page.tsx",
                                        lineNumber: 200,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/web/app/markets/page.tsx",
                                    lineNumber: 199,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                    children: [
                                        renderMarkets.map((market, index)=>{
                                            const rowKey = market.ticker || market.event_ticker || `market-${index}`;
                                            const yesPrice = market.yes_price;
                                            const noPrice = market.no_price ?? Math.max(0, 100 - yesPrice);
                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].titleCell,
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                                            href: `/trade/${market.ticker}`,
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].titleLink,
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].marketTitle,
                                                                children: market.title
                                                            }, void 0, false, {
                                                                fileName: "[project]/web/app/markets/page.tsx",
                                                                lineNumber: 216,
                                                                columnNumber: 27
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/web/app/markets/page.tsx",
                                                            lineNumber: 215,
                                                            columnNumber: 25
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/web/app/markets/page.tsx",
                                                        lineNumber: 214,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                        children: market.volume.toLocaleString()
                                                    }, void 0, false, {
                                                        fileName: "[project]/web/app/markets/page.tsx",
                                                        lineNumber: 219,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                        children: [
                                                            yesPrice,
                                                            "¢"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/web/app/markets/page.tsx",
                                                        lineNumber: 220,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                        children: [
                                                            noPrice,
                                                            "¢"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/web/app/markets/page.tsx",
                                                        lineNumber: 221,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, rowKey, true, {
                                                fileName: "[project]/web/app/markets/page.tsx",
                                                lineNumber: 213,
                                                columnNumber: 21
                                            }, this);
                                        }),
                                        renderMarkets.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                colSpan: 4,
                                                style: {
                                                    textAlign: "center",
                                                    padding: "2rem"
                                                },
                                                children: "No markets found"
                                            }, void 0, false, {
                                                fileName: "[project]/web/app/markets/page.tsx",
                                                lineNumber: 227,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/web/app/markets/page.tsx",
                                            lineNumber: 226,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/web/app/markets/page.tsx",
                                    lineNumber: 207,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/web/app/markets/page.tsx",
                            lineNumber: 198,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/web/app/markets/page.tsx",
                        lineNumber: 197,
                        columnNumber: 11
                    }, this),
                    renderTotalPages > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].pagination,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].pageButton,
                                href: makeLink({
                                    page: Math.max(1, renderCurrentPage - 1)
                                }),
                                "aria-disabled": renderCurrentPage <= 1,
                                children: "Previous"
                            }, void 0, false, {
                                fileName: "[project]/web/app/markets/page.tsx",
                                lineNumber: 238,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].pageIndicator,
                                children: [
                                    "Page ",
                                    renderCurrentPage,
                                    " of ",
                                    renderTotalPages,
                                    " ",
                                    renderTotalCount > 0 ? `• ${renderTotalCount} markets` : ""
                                ]
                            }, void 0, true, {
                                fileName: "[project]/web/app/markets/page.tsx",
                                lineNumber: 245,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].pageButton,
                                href: makeLink({
                                    page: Math.min(renderTotalPages, renderCurrentPage + 1)
                                }),
                                "aria-disabled": renderCurrentPage >= renderTotalPages,
                                children: "Next"
                            }, void 0, false, {
                                fileName: "[project]/web/app/markets/page.tsx",
                                lineNumber: 248,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/web/app/markets/page.tsx",
                        lineNumber: 237,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/web/app/markets/page.tsx",
                lineNumber: 120,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/web/app/markets/page.tsx",
            lineNumber: 119,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/web/app/markets/page.tsx",
        lineNumber: 118,
        columnNumber: 5
    }, this);
}
}),
"[project]/web/app/markets/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/web/app/markets/page.tsx [app-rsc] (ecmascript)"));
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__4c4c6d7e._.js.map