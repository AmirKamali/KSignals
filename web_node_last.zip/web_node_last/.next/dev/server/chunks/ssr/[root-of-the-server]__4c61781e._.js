module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[project]/web/components/HeroSection.module.css [app-ssr] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "actions": "HeroSection-module__suLlPW__actions",
  "backgroundEffects": "HeroSection-module__suLlPW__backgroundEffects",
  "badge": "HeroSection-module__suLlPW__badge",
  "badgeDot": "HeroSection-module__suLlPW__badgeDot",
  "badgeText": "HeroSection-module__suLlPW__badgeText",
  "benefitsList": "HeroSection-module__suLlPW__benefitsList",
  "benefitsTitle": "HeroSection-module__suLlPW__benefitsTitle",
  "bulletList": "HeroSection-module__suLlPW__bulletList",
  "content": "HeroSection-module__suLlPW__content",
  "fadeInDown": "HeroSection-module__suLlPW__fadeInDown",
  "fadeInUp": "HeroSection-module__suLlPW__fadeInUp",
  "featureCard": "HeroSection-module__suLlPW__featureCard",
  "featureGrid": "HeroSection-module__suLlPW__featureGrid",
  "featurePanel": "HeroSection-module__suLlPW__featurePanel",
  "float": "HeroSection-module__suLlPW__float",
  "glowPrimary": "HeroSection-module__suLlPW__glowPrimary",
  "glowSecondary": "HeroSection-module__suLlPW__glowSecondary",
  "gridPattern": "HeroSection-module__suLlPW__gridPattern",
  "hero": "HeroSection-module__suLlPW__hero",
  "iconWrapper": "HeroSection-module__suLlPW__iconWrapper",
  "layout": "HeroSection-module__suLlPW__layout",
  "panelHeader": "HeroSection-module__suLlPW__panelHeader",
  "panelLabel": "HeroSection-module__suLlPW__panelLabel",
  "panelStatus": "HeroSection-module__suLlPW__panelStatus",
  "panelSubtext": "HeroSection-module__suLlPW__panelSubtext",
  "pulse": "HeroSection-module__suLlPW__pulse",
  "statusDot": "HeroSection-module__suLlPW__statusDot",
  "subtitle": "HeroSection-module__suLlPW__subtitle",
  "title": "HeroSection-module__suLlPW__title",
});
}),
"[project]/web/components/HeroSection.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HeroSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__ = __turbopack_context__.i("[project]/web/node_modules/lucide-react/dist/esm/icons/arrow-right.js [app-ssr] (ecmascript) <export default as ArrowRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/web/components/HeroSection.module.css [app-ssr] (css module)");
"use client";
;
;
;
function HeroSection() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].hero,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].backgroundEffects,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].gridPattern
                    }, void 0, false, {
                        fileName: "[project]/web/components/HeroSection.tsx",
                        lineNumber: 10,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].glowPrimary
                    }, void 0, false, {
                        fileName: "[project]/web/components/HeroSection.tsx",
                        lineNumber: 11,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].glowSecondary
                    }, void 0, false, {
                        fileName: "[project]/web/components/HeroSection.tsx",
                        lineNumber: 12,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/web/components/HeroSection.tsx",
                lineNumber: 9,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].layout,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].content,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].badge,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].badgeDot
                                    }, void 0, false, {
                                        fileName: "[project]/web/components/HeroSection.tsx",
                                        lineNumber: 19,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].badgeText,
                                        children: "Live Market Signals Active"
                                    }, void 0, false, {
                                        fileName: "[project]/web/components/HeroSection.tsx",
                                        lineNumber: 20,
                                        columnNumber: 29
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/web/components/HeroSection.tsx",
                                lineNumber: 18,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].title,
                                children: [
                                    "Trade on ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-gradient",
                                        children: "Real World"
                                    }, void 0, false, {
                                        fileName: "[project]/web/components/HeroSection.tsx",
                                        lineNumber: 24,
                                        columnNumber: 38
                                    }, this),
                                    " Events"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/web/components/HeroSection.tsx",
                                lineNumber: 23,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].subtitle,
                                children: "Access AI-powered insights and probability analysis for the first regulated exchange dedicated to trading event outcomes."
                            }, void 0, false, {
                                fileName: "[project]/web/components/HeroSection.tsx",
                                lineNumber: 27,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].actions,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: "btn btn-primary",
                                        children: [
                                            "Start Trading ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                                size: 18,
                                                style: {
                                                    marginLeft: "0.5rem"
                                                }
                                            }, void 0, false, {
                                                fileName: "[project]/web/components/HeroSection.tsx",
                                                lineNumber: 34,
                                                columnNumber: 47
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/web/components/HeroSection.tsx",
                                        lineNumber: 33,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: "btn btn-outline",
                                        children: "View All Markets"
                                    }, void 0, false, {
                                        fileName: "[project]/web/components/HeroSection.tsx",
                                        lineNumber: 36,
                                        columnNumber: 29
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/web/components/HeroSection.tsx",
                                lineNumber: 32,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/web/components/HeroSection.tsx",
                        lineNumber: 17,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/web/components/HeroSection.tsx",
                    lineNumber: 16,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/web/components/HeroSection.tsx",
                lineNumber: 15,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/web/components/HeroSection.tsx",
        lineNumber: 8,
        columnNumber: 9
    }, this);
}
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[project]/web/lib/data:9a5879 [app-ssr] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"409071e25c2a92798fac6387e9301fdc81bce11cd4":"getSeriesByTags"},"web/lib/kalshi.ts",""] */ __turbopack_context__.s([
    "getSeriesByTags",
    ()=>getSeriesByTags
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
var getSeriesByTags = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("409071e25c2a92798fac6387e9301fdc81bce11cd4", __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "getSeriesByTags"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4va2Fsc2hpLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIHNlcnZlclwiO1xuXG5jb25zdCBCQVNFX1VSTCA9IFwiaHR0cHM6Ly9hcGkuZWxlY3Rpb25zLmthbHNoaS5jb20vdHJhZGUtYXBpL3YyXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgTWFya2V0IHtcbiAgICB0aWNrZXI6IHN0cmluZztcbiAgICBldmVudF90aWNrZXI6IHN0cmluZztcbiAgICB0aXRsZTogc3RyaW5nO1xuICAgIHN1YnRpdGxlPzogc3RyaW5nO1xuICAgIHllc19wcmljZTogbnVtYmVyO1xuICAgIHZvbHVtZTogbnVtYmVyO1xuICAgIG9wZW5faW50ZXJlc3Q6IG51bWJlcjtcbiAgICBsaXF1aWRpdHk6IG51bWJlcjtcbiAgICBzdGF0dXM6IHN0cmluZztcbiAgICBjYXRlZ29yeT86IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBNYXJrZXREZXRhaWwgZXh0ZW5kcyBNYXJrZXQge1xuICAgIGNhdGVnb3J5OiBzdHJpbmc7IC8vIE92ZXJyaWRlIGFzIHJlcXVpcmVkIGZvciBkZXRhaWxzXG4gICAgZXhwaXJhdGlvbl90aW1lOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgT3JkZXJCb29rIHtcbiAgICB5ZXM6IFtudW1iZXIsIG51bWJlcl1bXTtcbiAgICBubzogW251bWJlciwgbnVtYmVyXVtdO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFNlcmllcyB7XG4gICAgdGlja2VyOiBzdHJpbmc7XG4gICAgZnJlcXVlbmN5OiBzdHJpbmc7XG4gICAgdGl0bGU6IHN0cmluZztcbiAgICBjYXRlZ29yeTogc3RyaW5nO1xuICAgIHRhZ3M6IHN0cmluZ1tdO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0SGlnaFZvbHVtZU1hcmtldHMobGltaXQgPSAxMDAsIG1heENyZWF0ZWRUcz86IG51bWJlcik6IFByb21pc2U8TWFya2V0W10+IHtcbiAgICB0cnkge1xuICAgICAgICBsZXQgdXJsID0gYCR7QkFTRV9VUkx9L21hcmtldHM/bGltaXQ9JHtsaW1pdH0mc3RhdHVzPW9wZW5gO1xuICAgICAgICBpZiAobWF4Q3JlYXRlZFRzKSB7XG4gICAgICAgICAgICB1cmwgKz0gYCZtYXhfY3JlYXRlZF90cz0ke21heENyZWF0ZWRUc31gO1xuICAgICAgICB9XG4gICAgICAgIFxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKHVybCwge1xuICAgICAgICAgICAgbmV4dDogeyByZXZhbGlkYXRlOiA2MCB9LFxuICAgICAgICB9KTtcblxuICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggbWFya2V0c1wiKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIGxldCBtYXJrZXRzOiBNYXJrZXRbXSA9IGRhdGEubWFya2V0cyB8fCBbXTtcblxuICAgICAgICAvLyBBc3NpZ24gY2F0ZWdvcmllcyBoZXVyaXN0aWNhbGx5IHNpbmNlIEFQSSByZXR1cm5zIGVtcHR5IHN0cmluZ1xuICAgICAgICBtYXJrZXRzID0gbWFya2V0cy5tYXAobSA9PiAoe1xuICAgICAgICAgICAgLi4ubSxcbiAgICAgICAgICAgIGNhdGVnb3J5OiBhc3NpZ25DYXRlZ29yeShtKVxuICAgICAgICB9KSk7XG5cbiAgICAgICAgcmV0dXJuIG1hcmtldHNcbiAgICAgICAgICAgIC5zb3J0KChhLCBiKSA9PiBiLnZvbHVtZSAtIGEudm9sdW1lKVxuICAgICAgICAgICAgLnNsaWNlKDAsIGxpbWl0KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgaGlnaCB2b2x1bWUgbWFya2V0czpcIiwgZXJyb3IpO1xuICAgICAgICByZXR1cm4gW107XG4gICAgfVxufVxuXG5mdW5jdGlvbiBhc3NpZ25DYXRlZ29yeShtYXJrZXQ6IE1hcmtldCk6IHN0cmluZyB7XG4gICAgY29uc3QgdGV4dCA9IGAke21hcmtldC50aXRsZX0gJHttYXJrZXQudGlja2VyfSAke21hcmtldC5ldmVudF90aWNrZXJ9YC50b0xvd2VyQ2FzZSgpO1xuXG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJmZWRcIikgfHwgdGV4dC5pbmNsdWRlcyhcImluZmxhdGlvblwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwicmF0ZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ2RwXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJlY29ub215XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzcHhcIikgfHwgdGV4dC5pbmNsdWRlcyhcIm5hc2RhcVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwidHJlYXN1clwiKSkgcmV0dXJuIFwiRWNvbm9taWNzXCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJ0cnVtcFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiYmlkZW5cIikgfHwgdGV4dC5pbmNsdWRlcyhcImhhcnJpc1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZWxlY3Rpb25cIikgfHwgdGV4dC5pbmNsdWRlcyhcInNlbmF0ZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiaG91c2VcIikgfHwgdGV4dC5pbmNsdWRlcyhcInByZXNpZGVudFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ292XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJjYWJpbmV0XCIpKSByZXR1cm4gXCJQb2xpdGljc1wiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiYXBwbGVcIikgfHwgdGV4dC5pbmNsdWRlcyhcInRlc2xhXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJhaVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ3B0XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJ0ZWNoXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJtdXNrXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJudmlkaWFcIikpIHJldHVybiBcIlNjaWVuY2UgYW5kIFRlY2hub2xvZ3lcIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcInRlbXBcIikgfHwgdGV4dC5pbmNsdWRlcyhcInJhaW5cIikgfHwgdGV4dC5pbmNsdWRlcyhcInNub3dcIikgfHwgdGV4dC5pbmNsdWRlcyhcImh1cnJpY2FuZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiY2xpbWF0ZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwid2VhdGhlclwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZGVncmVlXCIpKSByZXR1cm4gXCJDbGltYXRlIGFuZCBXZWF0aGVyXCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJiaXRjb2luXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJidGNcIikgfHwgdGV4dC5pbmNsdWRlcyhcImV0aFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiY3J5cHRvXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzb2xhbmFcIikpIHJldHVybiBcIkNyeXB0b1wiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwibW92aWVcIikgfHwgdGV4dC5pbmNsdWRlcyhcIm11c2ljXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJvc2NhclwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ3JhbW15XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJib3ggb2ZmaWNlXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzcG90aWZ5XCIpKSByZXR1cm4gXCJFbnRlcnRhaW5tZW50XCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJmb290YmFsbFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibmZsXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJuYmFcIikgfHwgdGV4dC5pbmNsdWRlcyhcInNwb3J0XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJnYW1lXCIpKSByZXR1cm4gXCJTcG9ydHNcIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcImRpc2Vhc2VcIikgfHwgdGV4dC5pbmNsdWRlcyhcImhlYWx0aFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiY292aWRcIikgfHwgdGV4dC5pbmNsdWRlcyhcInZhY2NpbmVcIikpIHJldHVybiBcIkhlYWx0aFwiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiZmluYW5jaWFsXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzdG9ja1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibWFya2V0XCIpKSByZXR1cm4gXCJGaW5hbmNpYWxzXCI7XG5cbiAgICByZXR1cm4gXCJPdGhlclwiO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWFya2V0c0J5U2VyaWVzKHNlcmllc1RpY2tlcjogc3RyaW5nKTogUHJvbWlzZTxNYXJrZXRbXT4ge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7QkFTRV9VUkx9L21hcmtldHM/c2VyaWVzX3RpY2tlcj0ke3Nlcmllc1RpY2tlcn0mc3RhdHVzPW9wZW5gKTtcbiAgICAgICAgaWYgKCFyZXNwb25zZS5vaykgcmV0dXJuIFtdO1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICByZXR1cm4gZGF0YS5tYXJrZXRzIHx8IFtdO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGZldGNoaW5nIHNlcmllcyAke3Nlcmllc1RpY2tlcn06YCwgZXJyb3IpO1xuICAgICAgICByZXR1cm4gW107XG4gICAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0VGFnc0J5Q2F0ZWdvcmllcygpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPj4ge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7QkFTRV9VUkx9L3NlYXJjaC90YWdzX2J5X2NhdGVnb3JpZXNgKTtcbiAgICAgICAgaWYgKCFyZXNwb25zZS5vaykgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIGZldGNoIHRhZ3NcIik7XG5cbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIGRhdGEudGFnc19ieV9jYXRlZ29yaWVzIHx8IHt9O1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB0YWdzOlwiLCBlcnJvcik7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBcIkVjb25vbWljc1wiOiBbXCJJbnRlcmVzdCBSYXRlc1wiLCBcIkluZmxhdGlvblwiLCBcIkdEUFwiXSxcbiAgICAgICAgICAgIFwiUG9saXRpY3NcIjogW1wiRWxlY3Rpb25zXCIsIFwiUG9saWN5XCJdLFxuICAgICAgICAgICAgXCJUZWNobm9sb2d5XCI6IFtcIkFJXCIsIFwiSGFyZHdhcmVcIl0sXG4gICAgICAgICAgICBcIk90aGVyXCI6IFtdXG4gICAgICAgIH07XG4gICAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2VyaWVzQnlUYWdzKHRhZ3M6IHN0cmluZyk6IFByb21pc2U8U2VyaWVzW10+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfS9zZXJpZXM/dGFncz0ke3RhZ3N9YCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHJldHVybiBbXTtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIGRhdGEuc2VyaWVzIHx8IFtdO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGZldGNoaW5nIHNlcmllcyBmb3IgdGFncyAke3RhZ3N9OmAsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNlcmllc0J5Q2F0ZWdvcnkoY2F0ZWdvcnk6IHN0cmluZyk6IFByb21pc2U8U2VyaWVzW10+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfS9zZXJpZXM/c2VyaWVzX2NhdGVnb3J5PSR7ZW5jb2RlVVJJQ29tcG9uZW50KGNhdGVnb3J5KX1gKTtcbiAgICAgICAgLy8gTm90ZTogVGhlIGRvY3VtZW50YXRpb24gbWlnaHQgc2F5IGBjYXRlZ29yeWAsIGJ1dCBzdGFuZGFyZCBLYWxzaGkgQVBJIHVzdWFsbHkgdXNlcyBgc2VyaWVzX2NhdGVnb3J5YCBvciBqdXN0IGBjYXRlZ29yeWAuIFxuICAgICAgICAvLyBUaGUgdXNlciBwcm92aWRlZCBsaW5rIGh0dHBzOi8vZG9jcy5rYWxzaGkuY29tL2FwaS1yZWZlcmVuY2UvbWFya2V0L2dldC1zZXJpZXMtbGlzdCBzYXlzIHBhcmFtZXRlcnMgYXJlIGBzZXJpZXNfdGlja2VyYCwgYHNlcmllc19jYXRlZ29yeWAsIGB0YWdzYC5cbiAgICAgICAgLy8gV2FpdCwgdXNlciBzYWlkIGAvc2VyaWVzP2NhdGVnb3J5PXh4eGAuIFxuICAgICAgICAvLyBMZXQncyB2ZXJpZnkgdGhlIHVzZXIncyBsaW5rIGRvY3VtZW50YXRpb24gaWYgcG9zc2libGUgb3IgdHJ1c3QgdGhlIHVzZXIuIFxuICAgICAgICAvLyBUaGUgdXNlciBleHBsaWNpdGx5IHdyb3RlIGAvc2VyaWVzP2NhdGVnb3J5PXh4eGAuXG4gICAgICAgIC8vIEhvd2V2ZXIsIHN0YW5kYXJkIHBhcmFtZXRlciBmb3IgY2F0ZWdvcnkgaW4gbWFueSBBUElzIGlzIG9mdGVuIGp1c3QgYGNhdGVnb3J5YC5cbiAgICAgICAgLy8gQnV0IGxldCdzIGNoZWNrIHRoZSB1c2VyIHByb3ZpZGVkIGxpbmsgaW4gbXkgaGVhZCAoSSBjYW4ndCBicm93c2UpLlxuICAgICAgICAvLyBBY3R1YWxseSBJIGNhbiBicm93c2UuXG4gICAgICAgIC8vIExldCdzIHVzZSBgY2F0ZWdvcnlgIGFzIHJlcXVlc3RlZCBieSB1c2VyLCBidXQgSSB3aWxsIGRvdWJsZSBjaGVjay5cbiAgICAgICAgLy8gQnV0IEkgd2lsbCBzdGljayB0byB3aGF0IHRoZSB1c2VyIHJlcXVlc3RlZCBgP2NhdGVnb3J5PWAuXG4gICAgICAgIC8vIFdhaXQsIHRoZSB1c2VyIHNhaWQgXCJDaGVjayBkb2N1bWVudGF0aW9uOiAuLi5cIi5cbiAgICAgICAgXG4gICAgICAgIC8vIEkgd2lsbCB0cnVzdCB0aGUgdXNlcidzIHNwZWNpZmljIHJlcXVlc3QgXCJwYXNzIGNhdGVnb3J5IGFzIHF1ZXJ5IHN0cmluZzogL3Nlcmllcz9jYXRlZ29yeT14eHhcIlxuICAgICAgICAvLyBCdXQgSSB3aWxsIGFsc28gaGFuZGxlIHRoZSBjYXNlIGlmIGl0IG5lZWRzIHRvIGJlIG1hcHBlZC5cbiAgICAgICAgLy8gQWN0dWFsbHksIGxldCdzIGxvb2sgYXQgYGdldFRhZ3NCeUNhdGVnb3JpZXNgLiBJdCB1c2VzIGB0YWdzX2J5X2NhdGVnb3JpZXNgLlxuICAgICAgICBcbiAgICAgICAgLy8gTGV0J3MgdHJ5IGBjYXRlZ29yeWAgZmlyc3QgYXMgdXNlciBhc2tlZC5cbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYCR7QkFTRV9VUkx9L3Nlcmllcz9jYXRlZ29yeT0ke2VuY29kZVVSSUNvbXBvbmVudChjYXRlZ29yeSl9YCk7XG4gICAgICAgIGlmICghcmVzLm9rKSByZXR1cm4gW107XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXMuanNvbigpO1xuICAgICAgICByZXR1cm4gZGF0YS5zZXJpZXMgfHwgW107XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgZmV0Y2hpbmcgc2VyaWVzIGZvciBjYXRlZ29yeSAke2NhdGVnb3J5fTpgLCBlcnJvcik7XG4gICAgICAgIHJldHVybiBbXTtcbiAgICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRNYXJrZXREZXRhaWxzKHRpY2tlcjogc3RyaW5nKTogUHJvbWlzZTxNYXJrZXREZXRhaWwgfCBudWxsPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vbWFya2V0cy8ke3RpY2tlcn1gKTtcbiAgICAgICAgaWYgKCFyZXNwb25zZS5vaykgcmV0dXJuIG51bGw7XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIHJldHVybiBkYXRhLm1hcmtldDtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBmZXRjaGluZyBtYXJrZXQgJHt0aWNrZXJ9OmAsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0T3JkZXJCb29rKHRpY2tlcjogc3RyaW5nKTogUHJvbWlzZTxPcmRlckJvb2sgfCBudWxsPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vbWFya2V0cy8ke3RpY2tlcn0vb3JkZXJib29rYCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHJldHVybiBudWxsO1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICByZXR1cm4gZGF0YS5vcmRlcmJvb2s7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgZmV0Y2hpbmcgb3JkZXJib29rIGZvciAke3RpY2tlcn06YCwgZXJyb3IpO1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG59XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjBSQWtIc0IifQ==
}),
"[project]/web/lib/data:4341c7 [app-ssr] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"4098a2c63c1f4720d0b4167856dc1aed4865487165":"getMarketsBySeries"},"web/lib/kalshi.ts",""] */ __turbopack_context__.s([
    "getMarketsBySeries",
    ()=>getMarketsBySeries
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
var getMarketsBySeries = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("4098a2c63c1f4720d0b4167856dc1aed4865487165", __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "getMarketsBySeries"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4va2Fsc2hpLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIHNlcnZlclwiO1xuXG5jb25zdCBCQVNFX1VSTCA9IFwiaHR0cHM6Ly9hcGkuZWxlY3Rpb25zLmthbHNoaS5jb20vdHJhZGUtYXBpL3YyXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgTWFya2V0IHtcbiAgICB0aWNrZXI6IHN0cmluZztcbiAgICBldmVudF90aWNrZXI6IHN0cmluZztcbiAgICB0aXRsZTogc3RyaW5nO1xuICAgIHN1YnRpdGxlPzogc3RyaW5nO1xuICAgIHllc19wcmljZTogbnVtYmVyO1xuICAgIHZvbHVtZTogbnVtYmVyO1xuICAgIG9wZW5faW50ZXJlc3Q6IG51bWJlcjtcbiAgICBsaXF1aWRpdHk6IG51bWJlcjtcbiAgICBzdGF0dXM6IHN0cmluZztcbiAgICBjYXRlZ29yeT86IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBNYXJrZXREZXRhaWwgZXh0ZW5kcyBNYXJrZXQge1xuICAgIGNhdGVnb3J5OiBzdHJpbmc7IC8vIE92ZXJyaWRlIGFzIHJlcXVpcmVkIGZvciBkZXRhaWxzXG4gICAgZXhwaXJhdGlvbl90aW1lOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgT3JkZXJCb29rIHtcbiAgICB5ZXM6IFtudW1iZXIsIG51bWJlcl1bXTtcbiAgICBubzogW251bWJlciwgbnVtYmVyXVtdO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFNlcmllcyB7XG4gICAgdGlja2VyOiBzdHJpbmc7XG4gICAgZnJlcXVlbmN5OiBzdHJpbmc7XG4gICAgdGl0bGU6IHN0cmluZztcbiAgICBjYXRlZ29yeTogc3RyaW5nO1xuICAgIHRhZ3M6IHN0cmluZ1tdO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0SGlnaFZvbHVtZU1hcmtldHMobGltaXQgPSAxMDAsIG1heENyZWF0ZWRUcz86IG51bWJlcik6IFByb21pc2U8TWFya2V0W10+IHtcbiAgICB0cnkge1xuICAgICAgICBsZXQgdXJsID0gYCR7QkFTRV9VUkx9L21hcmtldHM/bGltaXQ9JHtsaW1pdH0mc3RhdHVzPW9wZW5gO1xuICAgICAgICBpZiAobWF4Q3JlYXRlZFRzKSB7XG4gICAgICAgICAgICB1cmwgKz0gYCZtYXhfY3JlYXRlZF90cz0ke21heENyZWF0ZWRUc31gO1xuICAgICAgICB9XG4gICAgICAgIFxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKHVybCwge1xuICAgICAgICAgICAgbmV4dDogeyByZXZhbGlkYXRlOiA2MCB9LFxuICAgICAgICB9KTtcblxuICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggbWFya2V0c1wiKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIGxldCBtYXJrZXRzOiBNYXJrZXRbXSA9IGRhdGEubWFya2V0cyB8fCBbXTtcblxuICAgICAgICAvLyBBc3NpZ24gY2F0ZWdvcmllcyBoZXVyaXN0aWNhbGx5IHNpbmNlIEFQSSByZXR1cm5zIGVtcHR5IHN0cmluZ1xuICAgICAgICBtYXJrZXRzID0gbWFya2V0cy5tYXAobSA9PiAoe1xuICAgICAgICAgICAgLi4ubSxcbiAgICAgICAgICAgIGNhdGVnb3J5OiBhc3NpZ25DYXRlZ29yeShtKVxuICAgICAgICB9KSk7XG5cbiAgICAgICAgcmV0dXJuIG1hcmtldHNcbiAgICAgICAgICAgIC5zb3J0KChhLCBiKSA9PiBiLnZvbHVtZSAtIGEudm9sdW1lKVxuICAgICAgICAgICAgLnNsaWNlKDAsIGxpbWl0KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgaGlnaCB2b2x1bWUgbWFya2V0czpcIiwgZXJyb3IpO1xuICAgICAgICByZXR1cm4gW107XG4gICAgfVxufVxuXG5mdW5jdGlvbiBhc3NpZ25DYXRlZ29yeShtYXJrZXQ6IE1hcmtldCk6IHN0cmluZyB7XG4gICAgY29uc3QgdGV4dCA9IGAke21hcmtldC50aXRsZX0gJHttYXJrZXQudGlja2VyfSAke21hcmtldC5ldmVudF90aWNrZXJ9YC50b0xvd2VyQ2FzZSgpO1xuXG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJmZWRcIikgfHwgdGV4dC5pbmNsdWRlcyhcImluZmxhdGlvblwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwicmF0ZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ2RwXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJlY29ub215XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzcHhcIikgfHwgdGV4dC5pbmNsdWRlcyhcIm5hc2RhcVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwidHJlYXN1clwiKSkgcmV0dXJuIFwiRWNvbm9taWNzXCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJ0cnVtcFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiYmlkZW5cIikgfHwgdGV4dC5pbmNsdWRlcyhcImhhcnJpc1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZWxlY3Rpb25cIikgfHwgdGV4dC5pbmNsdWRlcyhcInNlbmF0ZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiaG91c2VcIikgfHwgdGV4dC5pbmNsdWRlcyhcInByZXNpZGVudFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ292XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJjYWJpbmV0XCIpKSByZXR1cm4gXCJQb2xpdGljc1wiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiYXBwbGVcIikgfHwgdGV4dC5pbmNsdWRlcyhcInRlc2xhXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJhaVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ3B0XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJ0ZWNoXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJtdXNrXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJudmlkaWFcIikpIHJldHVybiBcIlNjaWVuY2UgYW5kIFRlY2hub2xvZ3lcIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcInRlbXBcIikgfHwgdGV4dC5pbmNsdWRlcyhcInJhaW5cIikgfHwgdGV4dC5pbmNsdWRlcyhcInNub3dcIikgfHwgdGV4dC5pbmNsdWRlcyhcImh1cnJpY2FuZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiY2xpbWF0ZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwid2VhdGhlclwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZGVncmVlXCIpKSByZXR1cm4gXCJDbGltYXRlIGFuZCBXZWF0aGVyXCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJiaXRjb2luXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJidGNcIikgfHwgdGV4dC5pbmNsdWRlcyhcImV0aFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiY3J5cHRvXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzb2xhbmFcIikpIHJldHVybiBcIkNyeXB0b1wiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwibW92aWVcIikgfHwgdGV4dC5pbmNsdWRlcyhcIm11c2ljXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJvc2NhclwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ3JhbW15XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJib3ggb2ZmaWNlXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzcG90aWZ5XCIpKSByZXR1cm4gXCJFbnRlcnRhaW5tZW50XCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJmb290YmFsbFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibmZsXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJuYmFcIikgfHwgdGV4dC5pbmNsdWRlcyhcInNwb3J0XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJnYW1lXCIpKSByZXR1cm4gXCJTcG9ydHNcIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcImRpc2Vhc2VcIikgfHwgdGV4dC5pbmNsdWRlcyhcImhlYWx0aFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiY292aWRcIikgfHwgdGV4dC5pbmNsdWRlcyhcInZhY2NpbmVcIikpIHJldHVybiBcIkhlYWx0aFwiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiZmluYW5jaWFsXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzdG9ja1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibWFya2V0XCIpKSByZXR1cm4gXCJGaW5hbmNpYWxzXCI7XG5cbiAgICByZXR1cm4gXCJPdGhlclwiO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWFya2V0c0J5U2VyaWVzKHNlcmllc1RpY2tlcjogc3RyaW5nKTogUHJvbWlzZTxNYXJrZXRbXT4ge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7QkFTRV9VUkx9L21hcmtldHM/c2VyaWVzX3RpY2tlcj0ke3Nlcmllc1RpY2tlcn0mc3RhdHVzPW9wZW5gKTtcbiAgICAgICAgaWYgKCFyZXNwb25zZS5vaykgcmV0dXJuIFtdO1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICByZXR1cm4gZGF0YS5tYXJrZXRzIHx8IFtdO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGZldGNoaW5nIHNlcmllcyAke3Nlcmllc1RpY2tlcn06YCwgZXJyb3IpO1xuICAgICAgICByZXR1cm4gW107XG4gICAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0VGFnc0J5Q2F0ZWdvcmllcygpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPj4ge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7QkFTRV9VUkx9L3NlYXJjaC90YWdzX2J5X2NhdGVnb3JpZXNgKTtcbiAgICAgICAgaWYgKCFyZXNwb25zZS5vaykgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIGZldGNoIHRhZ3NcIik7XG5cbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIGRhdGEudGFnc19ieV9jYXRlZ29yaWVzIHx8IHt9O1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB0YWdzOlwiLCBlcnJvcik7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBcIkVjb25vbWljc1wiOiBbXCJJbnRlcmVzdCBSYXRlc1wiLCBcIkluZmxhdGlvblwiLCBcIkdEUFwiXSxcbiAgICAgICAgICAgIFwiUG9saXRpY3NcIjogW1wiRWxlY3Rpb25zXCIsIFwiUG9saWN5XCJdLFxuICAgICAgICAgICAgXCJUZWNobm9sb2d5XCI6IFtcIkFJXCIsIFwiSGFyZHdhcmVcIl0sXG4gICAgICAgICAgICBcIk90aGVyXCI6IFtdXG4gICAgICAgIH07XG4gICAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2VyaWVzQnlUYWdzKHRhZ3M6IHN0cmluZyk6IFByb21pc2U8U2VyaWVzW10+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfS9zZXJpZXM/dGFncz0ke3RhZ3N9YCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHJldHVybiBbXTtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIGRhdGEuc2VyaWVzIHx8IFtdO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGZldGNoaW5nIHNlcmllcyBmb3IgdGFncyAke3RhZ3N9OmAsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNlcmllc0J5Q2F0ZWdvcnkoY2F0ZWdvcnk6IHN0cmluZyk6IFByb21pc2U8U2VyaWVzW10+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfS9zZXJpZXM/c2VyaWVzX2NhdGVnb3J5PSR7ZW5jb2RlVVJJQ29tcG9uZW50KGNhdGVnb3J5KX1gKTtcbiAgICAgICAgLy8gTm90ZTogVGhlIGRvY3VtZW50YXRpb24gbWlnaHQgc2F5IGBjYXRlZ29yeWAsIGJ1dCBzdGFuZGFyZCBLYWxzaGkgQVBJIHVzdWFsbHkgdXNlcyBgc2VyaWVzX2NhdGVnb3J5YCBvciBqdXN0IGBjYXRlZ29yeWAuIFxuICAgICAgICAvLyBUaGUgdXNlciBwcm92aWRlZCBsaW5rIGh0dHBzOi8vZG9jcy5rYWxzaGkuY29tL2FwaS1yZWZlcmVuY2UvbWFya2V0L2dldC1zZXJpZXMtbGlzdCBzYXlzIHBhcmFtZXRlcnMgYXJlIGBzZXJpZXNfdGlja2VyYCwgYHNlcmllc19jYXRlZ29yeWAsIGB0YWdzYC5cbiAgICAgICAgLy8gV2FpdCwgdXNlciBzYWlkIGAvc2VyaWVzP2NhdGVnb3J5PXh4eGAuIFxuICAgICAgICAvLyBMZXQncyB2ZXJpZnkgdGhlIHVzZXIncyBsaW5rIGRvY3VtZW50YXRpb24gaWYgcG9zc2libGUgb3IgdHJ1c3QgdGhlIHVzZXIuIFxuICAgICAgICAvLyBUaGUgdXNlciBleHBsaWNpdGx5IHdyb3RlIGAvc2VyaWVzP2NhdGVnb3J5PXh4eGAuXG4gICAgICAgIC8vIEhvd2V2ZXIsIHN0YW5kYXJkIHBhcmFtZXRlciBmb3IgY2F0ZWdvcnkgaW4gbWFueSBBUElzIGlzIG9mdGVuIGp1c3QgYGNhdGVnb3J5YC5cbiAgICAgICAgLy8gQnV0IGxldCdzIGNoZWNrIHRoZSB1c2VyIHByb3ZpZGVkIGxpbmsgaW4gbXkgaGVhZCAoSSBjYW4ndCBicm93c2UpLlxuICAgICAgICAvLyBBY3R1YWxseSBJIGNhbiBicm93c2UuXG4gICAgICAgIC8vIExldCdzIHVzZSBgY2F0ZWdvcnlgIGFzIHJlcXVlc3RlZCBieSB1c2VyLCBidXQgSSB3aWxsIGRvdWJsZSBjaGVjay5cbiAgICAgICAgLy8gQnV0IEkgd2lsbCBzdGljayB0byB3aGF0IHRoZSB1c2VyIHJlcXVlc3RlZCBgP2NhdGVnb3J5PWAuXG4gICAgICAgIC8vIFdhaXQsIHRoZSB1c2VyIHNhaWQgXCJDaGVjayBkb2N1bWVudGF0aW9uOiAuLi5cIi5cbiAgICAgICAgXG4gICAgICAgIC8vIEkgd2lsbCB0cnVzdCB0aGUgdXNlcidzIHNwZWNpZmljIHJlcXVlc3QgXCJwYXNzIGNhdGVnb3J5IGFzIHF1ZXJ5IHN0cmluZzogL3Nlcmllcz9jYXRlZ29yeT14eHhcIlxuICAgICAgICAvLyBCdXQgSSB3aWxsIGFsc28gaGFuZGxlIHRoZSBjYXNlIGlmIGl0IG5lZWRzIHRvIGJlIG1hcHBlZC5cbiAgICAgICAgLy8gQWN0dWFsbHksIGxldCdzIGxvb2sgYXQgYGdldFRhZ3NCeUNhdGVnb3JpZXNgLiBJdCB1c2VzIGB0YWdzX2J5X2NhdGVnb3JpZXNgLlxuICAgICAgICBcbiAgICAgICAgLy8gTGV0J3MgdHJ5IGBjYXRlZ29yeWAgZmlyc3QgYXMgdXNlciBhc2tlZC5cbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYCR7QkFTRV9VUkx9L3Nlcmllcz9jYXRlZ29yeT0ke2VuY29kZVVSSUNvbXBvbmVudChjYXRlZ29yeSl9YCk7XG4gICAgICAgIGlmICghcmVzLm9rKSByZXR1cm4gW107XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXMuanNvbigpO1xuICAgICAgICByZXR1cm4gZGF0YS5zZXJpZXMgfHwgW107XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgZmV0Y2hpbmcgc2VyaWVzIGZvciBjYXRlZ29yeSAke2NhdGVnb3J5fTpgLCBlcnJvcik7XG4gICAgICAgIHJldHVybiBbXTtcbiAgICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRNYXJrZXREZXRhaWxzKHRpY2tlcjogc3RyaW5nKTogUHJvbWlzZTxNYXJrZXREZXRhaWwgfCBudWxsPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vbWFya2V0cy8ke3RpY2tlcn1gKTtcbiAgICAgICAgaWYgKCFyZXNwb25zZS5vaykgcmV0dXJuIG51bGw7XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIHJldHVybiBkYXRhLm1hcmtldDtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBmZXRjaGluZyBtYXJrZXQgJHt0aWNrZXJ9OmAsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0T3JkZXJCb29rKHRpY2tlcjogc3RyaW5nKTogUHJvbWlzZTxPcmRlckJvb2sgfCBudWxsPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vbWFya2V0cy8ke3RpY2tlcn0vb3JkZXJib29rYCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHJldHVybiBudWxsO1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICByZXR1cm4gZGF0YS5vcmRlcmJvb2s7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgZmV0Y2hpbmcgb3JkZXJib29rIGZvciAke3RpY2tlcn06YCwgZXJyb3IpO1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG59XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjZSQW9Gc0IifQ==
}),
"[project]/web/lib/data:94497f [app-ssr] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"40d340aaa5db82e6b01959616fc70453cdbbe719c3":"getSeriesByCategory"},"web/lib/kalshi.ts",""] */ __turbopack_context__.s([
    "getSeriesByCategory",
    ()=>getSeriesByCategory
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
var getSeriesByCategory = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("40d340aaa5db82e6b01959616fc70453cdbbe719c3", __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "getSeriesByCategory"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4va2Fsc2hpLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIHNlcnZlclwiO1xuXG5jb25zdCBCQVNFX1VSTCA9IFwiaHR0cHM6Ly9hcGkuZWxlY3Rpb25zLmthbHNoaS5jb20vdHJhZGUtYXBpL3YyXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgTWFya2V0IHtcbiAgICB0aWNrZXI6IHN0cmluZztcbiAgICBldmVudF90aWNrZXI6IHN0cmluZztcbiAgICB0aXRsZTogc3RyaW5nO1xuICAgIHN1YnRpdGxlPzogc3RyaW5nO1xuICAgIHllc19wcmljZTogbnVtYmVyO1xuICAgIHZvbHVtZTogbnVtYmVyO1xuICAgIG9wZW5faW50ZXJlc3Q6IG51bWJlcjtcbiAgICBsaXF1aWRpdHk6IG51bWJlcjtcbiAgICBzdGF0dXM6IHN0cmluZztcbiAgICBjYXRlZ29yeT86IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBNYXJrZXREZXRhaWwgZXh0ZW5kcyBNYXJrZXQge1xuICAgIGNhdGVnb3J5OiBzdHJpbmc7IC8vIE92ZXJyaWRlIGFzIHJlcXVpcmVkIGZvciBkZXRhaWxzXG4gICAgZXhwaXJhdGlvbl90aW1lOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgT3JkZXJCb29rIHtcbiAgICB5ZXM6IFtudW1iZXIsIG51bWJlcl1bXTtcbiAgICBubzogW251bWJlciwgbnVtYmVyXVtdO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFNlcmllcyB7XG4gICAgdGlja2VyOiBzdHJpbmc7XG4gICAgZnJlcXVlbmN5OiBzdHJpbmc7XG4gICAgdGl0bGU6IHN0cmluZztcbiAgICBjYXRlZ29yeTogc3RyaW5nO1xuICAgIHRhZ3M6IHN0cmluZ1tdO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0SGlnaFZvbHVtZU1hcmtldHMobGltaXQgPSAxMDAsIG1heENyZWF0ZWRUcz86IG51bWJlcik6IFByb21pc2U8TWFya2V0W10+IHtcbiAgICB0cnkge1xuICAgICAgICBsZXQgdXJsID0gYCR7QkFTRV9VUkx9L21hcmtldHM/bGltaXQ9JHtsaW1pdH0mc3RhdHVzPW9wZW5gO1xuICAgICAgICBpZiAobWF4Q3JlYXRlZFRzKSB7XG4gICAgICAgICAgICB1cmwgKz0gYCZtYXhfY3JlYXRlZF90cz0ke21heENyZWF0ZWRUc31gO1xuICAgICAgICB9XG4gICAgICAgIFxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKHVybCwge1xuICAgICAgICAgICAgbmV4dDogeyByZXZhbGlkYXRlOiA2MCB9LFxuICAgICAgICB9KTtcblxuICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggbWFya2V0c1wiKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIGxldCBtYXJrZXRzOiBNYXJrZXRbXSA9IGRhdGEubWFya2V0cyB8fCBbXTtcblxuICAgICAgICAvLyBBc3NpZ24gY2F0ZWdvcmllcyBoZXVyaXN0aWNhbGx5IHNpbmNlIEFQSSByZXR1cm5zIGVtcHR5IHN0cmluZ1xuICAgICAgICBtYXJrZXRzID0gbWFya2V0cy5tYXAobSA9PiAoe1xuICAgICAgICAgICAgLi4ubSxcbiAgICAgICAgICAgIGNhdGVnb3J5OiBhc3NpZ25DYXRlZ29yeShtKVxuICAgICAgICB9KSk7XG5cbiAgICAgICAgcmV0dXJuIG1hcmtldHNcbiAgICAgICAgICAgIC5zb3J0KChhLCBiKSA9PiBiLnZvbHVtZSAtIGEudm9sdW1lKVxuICAgICAgICAgICAgLnNsaWNlKDAsIGxpbWl0KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgaGlnaCB2b2x1bWUgbWFya2V0czpcIiwgZXJyb3IpO1xuICAgICAgICByZXR1cm4gW107XG4gICAgfVxufVxuXG5mdW5jdGlvbiBhc3NpZ25DYXRlZ29yeShtYXJrZXQ6IE1hcmtldCk6IHN0cmluZyB7XG4gICAgY29uc3QgdGV4dCA9IGAke21hcmtldC50aXRsZX0gJHttYXJrZXQudGlja2VyfSAke21hcmtldC5ldmVudF90aWNrZXJ9YC50b0xvd2VyQ2FzZSgpO1xuXG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJmZWRcIikgfHwgdGV4dC5pbmNsdWRlcyhcImluZmxhdGlvblwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwicmF0ZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ2RwXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJlY29ub215XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzcHhcIikgfHwgdGV4dC5pbmNsdWRlcyhcIm5hc2RhcVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwidHJlYXN1clwiKSkgcmV0dXJuIFwiRWNvbm9taWNzXCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJ0cnVtcFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiYmlkZW5cIikgfHwgdGV4dC5pbmNsdWRlcyhcImhhcnJpc1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZWxlY3Rpb25cIikgfHwgdGV4dC5pbmNsdWRlcyhcInNlbmF0ZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiaG91c2VcIikgfHwgdGV4dC5pbmNsdWRlcyhcInByZXNpZGVudFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ292XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJjYWJpbmV0XCIpKSByZXR1cm4gXCJQb2xpdGljc1wiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiYXBwbGVcIikgfHwgdGV4dC5pbmNsdWRlcyhcInRlc2xhXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJhaVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ3B0XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJ0ZWNoXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJtdXNrXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJudmlkaWFcIikpIHJldHVybiBcIlNjaWVuY2UgYW5kIFRlY2hub2xvZ3lcIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcInRlbXBcIikgfHwgdGV4dC5pbmNsdWRlcyhcInJhaW5cIikgfHwgdGV4dC5pbmNsdWRlcyhcInNub3dcIikgfHwgdGV4dC5pbmNsdWRlcyhcImh1cnJpY2FuZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiY2xpbWF0ZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwid2VhdGhlclwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZGVncmVlXCIpKSByZXR1cm4gXCJDbGltYXRlIGFuZCBXZWF0aGVyXCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJiaXRjb2luXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJidGNcIikgfHwgdGV4dC5pbmNsdWRlcyhcImV0aFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiY3J5cHRvXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzb2xhbmFcIikpIHJldHVybiBcIkNyeXB0b1wiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwibW92aWVcIikgfHwgdGV4dC5pbmNsdWRlcyhcIm11c2ljXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJvc2NhclwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ3JhbW15XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJib3ggb2ZmaWNlXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzcG90aWZ5XCIpKSByZXR1cm4gXCJFbnRlcnRhaW5tZW50XCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJmb290YmFsbFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibmZsXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJuYmFcIikgfHwgdGV4dC5pbmNsdWRlcyhcInNwb3J0XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJnYW1lXCIpKSByZXR1cm4gXCJTcG9ydHNcIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcImRpc2Vhc2VcIikgfHwgdGV4dC5pbmNsdWRlcyhcImhlYWx0aFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiY292aWRcIikgfHwgdGV4dC5pbmNsdWRlcyhcInZhY2NpbmVcIikpIHJldHVybiBcIkhlYWx0aFwiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiZmluYW5jaWFsXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzdG9ja1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibWFya2V0XCIpKSByZXR1cm4gXCJGaW5hbmNpYWxzXCI7XG5cbiAgICByZXR1cm4gXCJPdGhlclwiO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWFya2V0c0J5U2VyaWVzKHNlcmllc1RpY2tlcjogc3RyaW5nKTogUHJvbWlzZTxNYXJrZXRbXT4ge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7QkFTRV9VUkx9L21hcmtldHM/c2VyaWVzX3RpY2tlcj0ke3Nlcmllc1RpY2tlcn0mc3RhdHVzPW9wZW5gKTtcbiAgICAgICAgaWYgKCFyZXNwb25zZS5vaykgcmV0dXJuIFtdO1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICByZXR1cm4gZGF0YS5tYXJrZXRzIHx8IFtdO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGZldGNoaW5nIHNlcmllcyAke3Nlcmllc1RpY2tlcn06YCwgZXJyb3IpO1xuICAgICAgICByZXR1cm4gW107XG4gICAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0VGFnc0J5Q2F0ZWdvcmllcygpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPj4ge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7QkFTRV9VUkx9L3NlYXJjaC90YWdzX2J5X2NhdGVnb3JpZXNgKTtcbiAgICAgICAgaWYgKCFyZXNwb25zZS5vaykgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIGZldGNoIHRhZ3NcIik7XG5cbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIGRhdGEudGFnc19ieV9jYXRlZ29yaWVzIHx8IHt9O1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB0YWdzOlwiLCBlcnJvcik7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBcIkVjb25vbWljc1wiOiBbXCJJbnRlcmVzdCBSYXRlc1wiLCBcIkluZmxhdGlvblwiLCBcIkdEUFwiXSxcbiAgICAgICAgICAgIFwiUG9saXRpY3NcIjogW1wiRWxlY3Rpb25zXCIsIFwiUG9saWN5XCJdLFxuICAgICAgICAgICAgXCJUZWNobm9sb2d5XCI6IFtcIkFJXCIsIFwiSGFyZHdhcmVcIl0sXG4gICAgICAgICAgICBcIk90aGVyXCI6IFtdXG4gICAgICAgIH07XG4gICAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2VyaWVzQnlUYWdzKHRhZ3M6IHN0cmluZyk6IFByb21pc2U8U2VyaWVzW10+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfS9zZXJpZXM/dGFncz0ke3RhZ3N9YCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHJldHVybiBbXTtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIGRhdGEuc2VyaWVzIHx8IFtdO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGZldGNoaW5nIHNlcmllcyBmb3IgdGFncyAke3RhZ3N9OmAsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNlcmllc0J5Q2F0ZWdvcnkoY2F0ZWdvcnk6IHN0cmluZyk6IFByb21pc2U8U2VyaWVzW10+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfS9zZXJpZXM/c2VyaWVzX2NhdGVnb3J5PSR7ZW5jb2RlVVJJQ29tcG9uZW50KGNhdGVnb3J5KX1gKTtcbiAgICAgICAgLy8gTm90ZTogVGhlIGRvY3VtZW50YXRpb24gbWlnaHQgc2F5IGBjYXRlZ29yeWAsIGJ1dCBzdGFuZGFyZCBLYWxzaGkgQVBJIHVzdWFsbHkgdXNlcyBgc2VyaWVzX2NhdGVnb3J5YCBvciBqdXN0IGBjYXRlZ29yeWAuIFxuICAgICAgICAvLyBUaGUgdXNlciBwcm92aWRlZCBsaW5rIGh0dHBzOi8vZG9jcy5rYWxzaGkuY29tL2FwaS1yZWZlcmVuY2UvbWFya2V0L2dldC1zZXJpZXMtbGlzdCBzYXlzIHBhcmFtZXRlcnMgYXJlIGBzZXJpZXNfdGlja2VyYCwgYHNlcmllc19jYXRlZ29yeWAsIGB0YWdzYC5cbiAgICAgICAgLy8gV2FpdCwgdXNlciBzYWlkIGAvc2VyaWVzP2NhdGVnb3J5PXh4eGAuIFxuICAgICAgICAvLyBMZXQncyB2ZXJpZnkgdGhlIHVzZXIncyBsaW5rIGRvY3VtZW50YXRpb24gaWYgcG9zc2libGUgb3IgdHJ1c3QgdGhlIHVzZXIuIFxuICAgICAgICAvLyBUaGUgdXNlciBleHBsaWNpdGx5IHdyb3RlIGAvc2VyaWVzP2NhdGVnb3J5PXh4eGAuXG4gICAgICAgIC8vIEhvd2V2ZXIsIHN0YW5kYXJkIHBhcmFtZXRlciBmb3IgY2F0ZWdvcnkgaW4gbWFueSBBUElzIGlzIG9mdGVuIGp1c3QgYGNhdGVnb3J5YC5cbiAgICAgICAgLy8gQnV0IGxldCdzIGNoZWNrIHRoZSB1c2VyIHByb3ZpZGVkIGxpbmsgaW4gbXkgaGVhZCAoSSBjYW4ndCBicm93c2UpLlxuICAgICAgICAvLyBBY3R1YWxseSBJIGNhbiBicm93c2UuXG4gICAgICAgIC8vIExldCdzIHVzZSBgY2F0ZWdvcnlgIGFzIHJlcXVlc3RlZCBieSB1c2VyLCBidXQgSSB3aWxsIGRvdWJsZSBjaGVjay5cbiAgICAgICAgLy8gQnV0IEkgd2lsbCBzdGljayB0byB3aGF0IHRoZSB1c2VyIHJlcXVlc3RlZCBgP2NhdGVnb3J5PWAuXG4gICAgICAgIC8vIFdhaXQsIHRoZSB1c2VyIHNhaWQgXCJDaGVjayBkb2N1bWVudGF0aW9uOiAuLi5cIi5cbiAgICAgICAgXG4gICAgICAgIC8vIEkgd2lsbCB0cnVzdCB0aGUgdXNlcidzIHNwZWNpZmljIHJlcXVlc3QgXCJwYXNzIGNhdGVnb3J5IGFzIHF1ZXJ5IHN0cmluZzogL3Nlcmllcz9jYXRlZ29yeT14eHhcIlxuICAgICAgICAvLyBCdXQgSSB3aWxsIGFsc28gaGFuZGxlIHRoZSBjYXNlIGlmIGl0IG5lZWRzIHRvIGJlIG1hcHBlZC5cbiAgICAgICAgLy8gQWN0dWFsbHksIGxldCdzIGxvb2sgYXQgYGdldFRhZ3NCeUNhdGVnb3JpZXNgLiBJdCB1c2VzIGB0YWdzX2J5X2NhdGVnb3JpZXNgLlxuICAgICAgICBcbiAgICAgICAgLy8gTGV0J3MgdHJ5IGBjYXRlZ29yeWAgZmlyc3QgYXMgdXNlciBhc2tlZC5cbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYCR7QkFTRV9VUkx9L3Nlcmllcz9jYXRlZ29yeT0ke2VuY29kZVVSSUNvbXBvbmVudChjYXRlZ29yeSl9YCk7XG4gICAgICAgIGlmICghcmVzLm9rKSByZXR1cm4gW107XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXMuanNvbigpO1xuICAgICAgICByZXR1cm4gZGF0YS5zZXJpZXMgfHwgW107XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgZmV0Y2hpbmcgc2VyaWVzIGZvciBjYXRlZ29yeSAke2NhdGVnb3J5fTpgLCBlcnJvcik7XG4gICAgICAgIHJldHVybiBbXTtcbiAgICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRNYXJrZXREZXRhaWxzKHRpY2tlcjogc3RyaW5nKTogUHJvbWlzZTxNYXJrZXREZXRhaWwgfCBudWxsPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vbWFya2V0cy8ke3RpY2tlcn1gKTtcbiAgICAgICAgaWYgKCFyZXNwb25zZS5vaykgcmV0dXJuIG51bGw7XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIHJldHVybiBkYXRhLm1hcmtldDtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBmZXRjaGluZyBtYXJrZXQgJHt0aWNrZXJ9OmAsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0T3JkZXJCb29rKHRpY2tlcjogc3RyaW5nKTogUHJvbWlzZTxPcmRlckJvb2sgfCBudWxsPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vbWFya2V0cy8ke3RpY2tlcn0vb3JkZXJib29rYCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHJldHVybiBudWxsO1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICByZXR1cm4gZGF0YS5vcmRlcmJvb2s7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgZmV0Y2hpbmcgb3JkZXJib29rIGZvciAke3RpY2tlcn06YCwgZXJyb3IpO1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG59XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjhSQThIc0IifQ==
}),
"[project]/web/components/MarketTable.module.css [app-ssr] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "active": "MarketTable-module__CHRjXG__active",
  "controls": "MarketTable-module__CHRjXG__controls",
  "detailsBtn": "MarketTable-module__CHRjXG__detailsBtn",
  "filterContainer": "MarketTable-module__CHRjXG__filterContainer",
  "loadingState": "MarketTable-module__CHRjXG__loadingState",
  "marketSubtitle": "MarketTable-module__CHRjXG__marketSubtitle",
  "marketTitle": "MarketTable-module__CHRjXG__marketTitle",
  "price": "MarketTable-module__CHRjXG__price",
  "section": "MarketTable-module__CHRjXG__section",
  "segmentBtn": "MarketTable-module__CHRjXG__segmentBtn",
  "spin": "MarketTable-module__CHRjXG__spin",
  "table": "MarketTable-module__CHRjXG__table",
  "tableContainer": "MarketTable-module__CHRjXG__tableContainer",
  "titleCell": "MarketTable-module__CHRjXG__titleCell",
});
}),
"[project]/web/components/MarketTable.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MarketTable
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__ = __turbopack_context__.i("[project]/web/node_modules/lucide-react/dist/esm/icons/arrow-right.js [app-ssr] (ecmascript) <export default as ArrowRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__ = __turbopack_context__.i("[project]/web/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-ssr] (ecmascript) <export default as Loader2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$data$3a$9a5879__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/web/lib/data:9a5879 [app-ssr] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$data$3a$4341c7__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/web/lib/data:4341c7 [app-ssr] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$data$3a$94497f__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/web/lib/data:94497f [app-ssr] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/web/components/MarketTable.module.css [app-ssr] (css module)");
"use client";
;
;
;
;
;
;
;
function MarketTable({ markets: initialMarkets, tagsByCategories }) {
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePathname"])();
    const { replace } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const initialCategory = searchParams.get("category") || "All";
    const initialTag = searchParams.get("tag");
    const [activeCategory, setActiveCategory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(initialCategory);
    const [activeSubTag, setActiveSubTag] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(initialTag);
    // Initialize displayed markets based on synchronous category filtering
    // Only use initialMarkets fallback if we are on "All" or if we want to show *something* while fetching
    // But since we are moving to async fetching for categories too, we might want to start with empty or initial if matches.
    const [displayedMarkets, setDisplayedMarkets] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(()=>{
        if (initialCategory === "All") {
            return initialMarkets;
        }
        // If category is set but no tag, we initially show fallback filtering 
        // until the async fetch completes (handled in useEffect).
        // This provides better UX than empty table.
        return initialMarkets.filter((m)=>m.category === initialCategory || !m.category && initialCategory === "Other");
    });
    // We are loading if there is a tag OR a category (that is not All) because now we fetch for categories too
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(!!initialTag || initialCategory !== "All");
    const categories = [
        "All",
        ...Object.keys(tagsByCategories).sort()
    ];
    const fetchMarkets = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async (category, tag)=>{
        setIsLoading(true);
        try {
            let seriesList;
            if (tag) {
                // 1. Get series for the tag
                seriesList = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$data$3a$9a5879__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["getSeriesByTags"])(tag);
            } else if (category !== "All") {
                // 1. Get series for the category
                seriesList = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$data$3a$94497f__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["getSeriesByCategory"])(category);
            } else {
                // "All" category - we use initialMarkets, no need to fetch series
                setDisplayedMarkets(initialMarkets);
                setIsLoading(false);
                return;
            }
            // 2. Get markets for each series
            // Limit to first 10 series to avoid too many requests if series list is huge
            const targetSeries = seriesList.slice(0, 10);
            const marketsPromises = targetSeries.map((series)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$data$3a$4341c7__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["getMarketsBySeries"])(series.ticker));
            const marketsArrays = await Promise.all(marketsPromises);
            const newMarkets = marketsArrays.flat();
            // Remove duplicates
            const uniqueMarkets = Array.from(new Map(newMarkets.map((m)=>[
                    m.ticker,
                    m
                ])).values());
            // Sort by volume descending
            uniqueMarkets.sort((a, b)=>b.volume - a.volume);
            setDisplayedMarkets(uniqueMarkets);
        } catch (error) {
            console.error("Error loading markets:", error);
            // Fallback to local filtering if fetch fails
            if (!tag && category !== "All") {
                const filtered = initialMarkets.filter((m)=>m.category === category || !m.category && category === "Other");
                setDisplayedMarkets(filtered);
            }
        } finally{
            setIsLoading(false);
        }
    }, [
        initialMarkets
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const cat = searchParams.get("category") || "All";
        const tag = searchParams.get("tag");
        setActiveCategory(cat);
        setActiveSubTag(tag);
        if (tag || cat !== "All") {
            fetchMarkets(cat, tag);
        } else {
            setDisplayedMarkets(initialMarkets);
        }
    }, [
        searchParams,
        initialMarkets,
        fetchMarkets
    ]);
    const updateUrl = (newCategory, newTag)=>{
        const params = new URLSearchParams(searchParams);
        if (newCategory && newCategory !== "All") {
            params.set("category", newCategory);
        } else {
            params.delete("category");
        }
        if (newTag) {
            params.set("tag", newTag);
        } else {
            params.delete("tag");
        }
        replace(`${pathname}?${params.toString()}`, {
            scroll: false
        });
    };
    const handleCategoryClick = (cat)=>{
        // When category changes, clear the tag
        updateUrl(cat, null);
    };
    const handleSubTagClick = (tag)=>{
        updateUrl(activeCategory, tag);
    };
    const subTags = activeCategory !== "All" && tagsByCategories[activeCategory] ? tagsByCategories[activeCategory] : [];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].section,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].filterContainer,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].controls,
                            children: categories.map((cat)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].segmentBtn} ${activeCategory === cat ? __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].active : ""}`,
                                    onClick: ()=>handleCategoryClick(cat),
                                    children: cat
                                }, cat, false, {
                                    fileName: "[project]/web/components/MarketTable.tsx",
                                    lineNumber: 141,
                                    columnNumber: 25
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/web/components/MarketTable.tsx",
                            lineNumber: 139,
                            columnNumber: 17
                        }, this),
                        subTags.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].controls,
                            children: subTags.map((tag)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].segmentBtn} ${activeSubTag === tag ? __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].active : ""}`,
                                    onClick: ()=>handleSubTagClick(tag),
                                    children: tag
                                }, tag, false, {
                                    fileName: "[project]/web/components/MarketTable.tsx",
                                    lineNumber: 154,
                                    columnNumber: 33
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/web/components/MarketTable.tsx",
                            lineNumber: 152,
                            columnNumber: 25
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/web/components/MarketTable.tsx",
                    lineNumber: 138,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].tableContainer,
                    children: isLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].loadingState,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].spin,
                            size: 32
                        }, void 0, false, {
                            fileName: "[project]/web/components/MarketTable.tsx",
                            lineNumber: 169,
                            columnNumber: 29
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/web/components/MarketTable.tsx",
                        lineNumber: 168,
                        columnNumber: 25
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].table,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            children: "Market"
                                        }, void 0, false, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 175,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            children: "Volume"
                                        }, void 0, false, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 176,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            children: "Yes Price"
                                        }, void 0, false, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 177,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            children: "Action"
                                        }, void 0, false, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 178,
                                            columnNumber: 33
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/web/components/MarketTable.tsx",
                                    lineNumber: 174,
                                    columnNumber: 29
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/web/components/MarketTable.tsx",
                                lineNumber: 173,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                children: [
                                    displayedMarkets.slice(0, 20).map((market)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].titleCell,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].marketTitle,
                                                            children: market.title
                                                        }, void 0, false, {
                                                            fileName: "[project]/web/components/MarketTable.tsx",
                                                            lineNumber: 185,
                                                            columnNumber: 41
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].marketSubtitle,
                                                            children: market.event_ticker
                                                        }, void 0, false, {
                                                            fileName: "[project]/web/components/MarketTable.tsx",
                                                            lineNumber: 186,
                                                            columnNumber: 41
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/web/components/MarketTable.tsx",
                                                    lineNumber: 184,
                                                    columnNumber: 37
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    children: market.volume.toLocaleString()
                                                }, void 0, false, {
                                                    fileName: "[project]/web/components/MarketTable.tsx",
                                                    lineNumber: 188,
                                                    columnNumber: 37
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].price,
                                                        children: [
                                                            market.yes_price,
                                                            "¢"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/web/components/MarketTable.tsx",
                                                        lineNumber: 190,
                                                        columnNumber: 41
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/web/components/MarketTable.tsx",
                                                    lineNumber: 189,
                                                    columnNumber: 37
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                        href: `/trade/${market.ticker}`,
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].detailsBtn,
                                                        children: [
                                                            "Details ",
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                                                size: 14
                                                            }, void 0, false, {
                                                                fileName: "[project]/web/components/MarketTable.tsx",
                                                                lineNumber: 194,
                                                                columnNumber: 53
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/web/components/MarketTable.tsx",
                                                        lineNumber: 193,
                                                        columnNumber: 41
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/web/components/MarketTable.tsx",
                                                    lineNumber: 192,
                                                    columnNumber: 37
                                                }, this)
                                            ]
                                        }, market.ticker, true, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 183,
                                            columnNumber: 33
                                        }, this)),
                                    displayedMarkets.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                            colSpan: 4,
                                            style: {
                                                textAlign: "center",
                                                padding: "2rem"
                                            },
                                            children: "No markets found"
                                        }, void 0, false, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 201,
                                            columnNumber: 41
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/web/components/MarketTable.tsx",
                                        lineNumber: 200,
                                        columnNumber: 37
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/web/components/MarketTable.tsx",
                                lineNumber: 181,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/web/components/MarketTable.tsx",
                        lineNumber: 172,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/web/components/MarketTable.tsx",
                    lineNumber: 166,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/web/components/MarketTable.tsx",
            lineNumber: 137,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/web/components/MarketTable.tsx",
        lineNumber: 136,
        columnNumber: 9
    }, this);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__4c61781e._.js.map