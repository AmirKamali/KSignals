module.exports = [
"[project]/web/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=web__next-internal_server_app_page_actions_ec26bf28.js.map