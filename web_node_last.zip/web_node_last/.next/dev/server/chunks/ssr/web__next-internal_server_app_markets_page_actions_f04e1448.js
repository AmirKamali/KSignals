module.exports = [
"[project]/web/.next-internal/server/app/markets/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=web__next-internal_server_app_markets_page_actions_f04e1448.js.map