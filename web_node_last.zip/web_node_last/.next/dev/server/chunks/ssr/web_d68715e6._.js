module.exports = [
"[project]/web/components/HeroSection.module.css [app-ssr] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "actions": "HeroSection-module__suLlPW__actions",
  "backgroundEffects": "HeroSection-module__suLlPW__backgroundEffects",
  "badge": "HeroSection-module__suLlPW__badge",
  "badgeDot": "HeroSection-module__suLlPW__badgeDot",
  "badgeText": "HeroSection-module__suLlPW__badgeText",
  "benefitsList": "HeroSection-module__suLlPW__benefitsList",
  "benefitsTitle": "HeroSection-module__suLlPW__benefitsTitle",
  "bulletList": "HeroSection-module__suLlPW__bulletList",
  "content": "HeroSection-module__suLlPW__content",
  "fadeInDown": "HeroSection-module__suLlPW__fadeInDown",
  "fadeInUp": "HeroSection-module__suLlPW__fadeInUp",
  "featureCard": "HeroSection-module__suLlPW__featureCard",
  "featureGrid": "HeroSection-module__suLlPW__featureGrid",
  "featurePanel": "HeroSection-module__suLlPW__featurePanel",
  "float": "HeroSection-module__suLlPW__float",
  "glowPrimary": "HeroSection-module__suLlPW__glowPrimary",
  "glowSecondary": "HeroSection-module__suLlPW__glowSecondary",
  "gridPattern": "HeroSection-module__suLlPW__gridPattern",
  "hero": "HeroSection-module__suLlPW__hero",
  "iconWrapper": "HeroSection-module__suLlPW__iconWrapper",
  "layout": "HeroSection-module__suLlPW__layout",
  "panelHeader": "HeroSection-module__suLlPW__panelHeader",
  "panelLabel": "HeroSection-module__suLlPW__panelLabel",
  "panelStatus": "HeroSection-module__suLlPW__panelStatus",
  "panelSubtext": "HeroSection-module__suLlPW__panelSubtext",
  "pulse": "HeroSection-module__suLlPW__pulse",
  "statusDot": "HeroSection-module__suLlPW__statusDot",
  "subtitle": "HeroSection-module__suLlPW__subtitle",
  "title": "HeroSection-module__suLlPW__title",
});
}),
"[project]/web/components/HeroSection.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HeroSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__ = __turbopack_context__.i("[project]/web/node_modules/lucide-react/dist/esm/icons/arrow-right.js [app-ssr] (ecmascript) <export default as ArrowRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/web/components/HeroSection.module.css [app-ssr] (css module)");
"use client";
;
;
;
function HeroSection() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].hero,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].backgroundEffects,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].gridPattern
                    }, void 0, false, {
                        fileName: "[project]/web/components/HeroSection.tsx",
                        lineNumber: 10,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].glowPrimary
                    }, void 0, false, {
                        fileName: "[project]/web/components/HeroSection.tsx",
                        lineNumber: 11,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].glowSecondary
                    }, void 0, false, {
                        fileName: "[project]/web/components/HeroSection.tsx",
                        lineNumber: 12,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/web/components/HeroSection.tsx",
                lineNumber: 9,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].layout,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].content,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].badge,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].badgeDot
                                    }, void 0, false, {
                                        fileName: "[project]/web/components/HeroSection.tsx",
                                        lineNumber: 19,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].badgeText,
                                        children: "Live Market Signals Active"
                                    }, void 0, false, {
                                        fileName: "[project]/web/components/HeroSection.tsx",
                                        lineNumber: 20,
                                        columnNumber: 29
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/web/components/HeroSection.tsx",
                                lineNumber: 18,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].title,
                                children: [
                                    "Trade on ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-gradient",
                                        children: "Real World"
                                    }, void 0, false, {
                                        fileName: "[project]/web/components/HeroSection.tsx",
                                        lineNumber: 24,
                                        columnNumber: 38
                                    }, this),
                                    " Events"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/web/components/HeroSection.tsx",
                                lineNumber: 23,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].subtitle,
                                children: "Access AI-powered insights and probability analysis for the first regulated exchange dedicated to trading event outcomes."
                            }, void 0, false, {
                                fileName: "[project]/web/components/HeroSection.tsx",
                                lineNumber: 27,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].actions,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: "btn btn-primary",
                                        children: [
                                            "Start Trading ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                                size: 18,
                                                style: {
                                                    marginLeft: "0.5rem"
                                                }
                                            }, void 0, false, {
                                                fileName: "[project]/web/components/HeroSection.tsx",
                                                lineNumber: 34,
                                                columnNumber: 47
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/web/components/HeroSection.tsx",
                                        lineNumber: 33,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: "btn btn-outline",
                                        children: "View All Markets"
                                    }, void 0, false, {
                                        fileName: "[project]/web/components/HeroSection.tsx",
                                        lineNumber: 36,
                                        columnNumber: 29
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/web/components/HeroSection.tsx",
                                lineNumber: 32,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/web/components/HeroSection.tsx",
                        lineNumber: 17,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/web/components/HeroSection.tsx",
                    lineNumber: 16,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/web/components/HeroSection.tsx",
                lineNumber: 15,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/web/components/HeroSection.tsx",
        lineNumber: 8,
        columnNumber: 9
    }, this);
}
}),
"[project]/web/lib/data:1f7c2c [app-ssr] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"409071e25c2a92798fac6387e9301fdc81bce11cd4":"getSeriesByTags"},"web/lib/kalshi.ts",""] */ __turbopack_context__.s([
    "getSeriesByTags",
    ()=>getSeriesByTags
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
var getSeriesByTags = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("409071e25c2a92798fac6387e9301fdc81bce11cd4", __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "getSeriesByTags"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4va2Fsc2hpLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIHNlcnZlclwiO1xuXG5jb25zdCBCQVNFX1VSTCA9IFwiaHR0cHM6Ly9hcGkuZWxlY3Rpb25zLmthbHNoaS5jb20vdHJhZGUtYXBpL3YyXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgTWFya2V0IHtcbiAgICB0aWNrZXI6IHN0cmluZztcbiAgICBldmVudF90aWNrZXI6IHN0cmluZztcbiAgICB0aXRsZTogc3RyaW5nO1xuICAgIHN1YnRpdGxlPzogc3RyaW5nO1xuICAgIHllc19wcmljZTogbnVtYmVyO1xuICAgIHZvbHVtZTogbnVtYmVyO1xuICAgIG9wZW5faW50ZXJlc3Q6IG51bWJlcjtcbiAgICBsaXF1aWRpdHk6IG51bWJlcjtcbiAgICBzdGF0dXM6IHN0cmluZztcbiAgICBjYXRlZ29yeT86IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBNYXJrZXREZXRhaWwgZXh0ZW5kcyBNYXJrZXQge1xuICAgIGNhdGVnb3J5OiBzdHJpbmc7IC8vIE92ZXJyaWRlIGFzIHJlcXVpcmVkIGZvciBkZXRhaWxzXG4gICAgZXhwaXJhdGlvbl90aW1lOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgT3JkZXJCb29rIHtcbiAgICB5ZXM6IFtudW1iZXIsIG51bWJlcl1bXTtcbiAgICBubzogW251bWJlciwgbnVtYmVyXVtdO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFNlcmllcyB7XG4gICAgdGlja2VyOiBzdHJpbmc7XG4gICAgZnJlcXVlbmN5OiBzdHJpbmc7XG4gICAgdGl0bGU6IHN0cmluZztcbiAgICBjYXRlZ29yeTogc3RyaW5nO1xuICAgIHRhZ3M6IHN0cmluZ1tdO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0SGlnaFZvbHVtZU1hcmtldHMobGltaXQgPSAxMDApOiBQcm9taXNlPE1hcmtldFtdPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vbWFya2V0cz9saW1pdD0ke2xpbWl0fSZzdGF0dXM9b3BlbmAsIHtcbiAgICAgICAgICAgIG5leHQ6IHsgcmV2YWxpZGF0ZTogNjAgfSxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIGZldGNoIG1hcmtldHNcIik7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICBsZXQgbWFya2V0czogTWFya2V0W10gPSBkYXRhLm1hcmtldHMgfHwgW107XG5cbiAgICAgICAgLy8gQXNzaWduIGNhdGVnb3JpZXMgaGV1cmlzdGljYWxseSBzaW5jZSBBUEkgcmV0dXJucyBlbXB0eSBzdHJpbmdcbiAgICAgICAgbWFya2V0cyA9IG1hcmtldHMubWFwKG0gPT4gKHtcbiAgICAgICAgICAgIC4uLm0sXG4gICAgICAgICAgICBjYXRlZ29yeTogYXNzaWduQ2F0ZWdvcnkobSlcbiAgICAgICAgfSkpO1xuXG4gICAgICAgIHJldHVybiBtYXJrZXRzXG4gICAgICAgICAgICAuc29ydCgoYSwgYikgPT4gYi52b2x1bWUgLSBhLnZvbHVtZSlcbiAgICAgICAgICAgIC5zbGljZSgwLCBsaW1pdCk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGhpZ2ggdm9sdW1lIG1hcmtldHM6XCIsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbn1cblxuZnVuY3Rpb24gYXNzaWduQ2F0ZWdvcnkobWFya2V0OiBNYXJrZXQpOiBzdHJpbmcge1xuICAgIGNvbnN0IHRleHQgPSBgJHttYXJrZXQudGl0bGV9ICR7bWFya2V0LnRpY2tlcn0gJHttYXJrZXQuZXZlbnRfdGlja2VyfWAudG9Mb3dlckNhc2UoKTtcblxuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiZmVkXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJpbmZsYXRpb25cIikgfHwgdGV4dC5pbmNsdWRlcyhcInJhdGVcIikgfHwgdGV4dC5pbmNsdWRlcyhcImdkcFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZWNvbm9teVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwic3B4XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJuYXNkYXFcIikgfHwgdGV4dC5pbmNsdWRlcyhcInRyZWFzdXJcIikpIHJldHVybiBcIkVjb25vbWljc1wiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwidHJ1bXBcIikgfHwgdGV4dC5pbmNsdWRlcyhcImJpZGVuXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJoYXJyaXNcIikgfHwgdGV4dC5pbmNsdWRlcyhcImVsZWN0aW9uXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzZW5hdGVcIikgfHwgdGV4dC5pbmNsdWRlcyhcImhvdXNlXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJwcmVzaWRlbnRcIikgfHwgdGV4dC5pbmNsdWRlcyhcImdvdlwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiY2FiaW5ldFwiKSkgcmV0dXJuIFwiUG9saXRpY3NcIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcImFwcGxlXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJ0ZXNsYVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiYWlcIikgfHwgdGV4dC5pbmNsdWRlcyhcImdwdFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwidGVjaFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibXVza1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibnZpZGlhXCIpKSByZXR1cm4gXCJTY2llbmNlIGFuZCBUZWNobm9sb2d5XCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJ0ZW1wXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJyYWluXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzbm93XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJodXJyaWNhbmVcIikgfHwgdGV4dC5pbmNsdWRlcyhcImNsaW1hdGVcIikgfHwgdGV4dC5pbmNsdWRlcyhcIndlYXRoZXJcIikgfHwgdGV4dC5pbmNsdWRlcyhcImRlZ3JlZVwiKSkgcmV0dXJuIFwiQ2xpbWF0ZSBhbmQgV2VhdGhlclwiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiYml0Y29pblwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiYnRjXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJldGhcIikgfHwgdGV4dC5pbmNsdWRlcyhcImNyeXB0b1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwic29sYW5hXCIpKSByZXR1cm4gXCJDcnlwdG9cIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcIm1vdmllXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJtdXNpY1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwib3NjYXJcIikgfHwgdGV4dC5pbmNsdWRlcyhcImdyYW1teVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiYm94IG9mZmljZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwic3BvdGlmeVwiKSkgcmV0dXJuIFwiRW50ZXJ0YWlubWVudFwiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiZm9vdGJhbGxcIikgfHwgdGV4dC5pbmNsdWRlcyhcIm5mbFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibmJhXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzcG9ydFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ2FtZVwiKSkgcmV0dXJuIFwiU3BvcnRzXCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJkaXNlYXNlXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJoZWFsdGhcIikgfHwgdGV4dC5pbmNsdWRlcyhcImNvdmlkXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJ2YWNjaW5lXCIpKSByZXR1cm4gXCJIZWFsdGhcIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcImZpbmFuY2lhbFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwic3RvY2tcIikgfHwgdGV4dC5pbmNsdWRlcyhcIm1hcmtldFwiKSkgcmV0dXJuIFwiRmluYW5jaWFsc1wiO1xuXG4gICAgcmV0dXJuIFwiT3RoZXJcIjtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE1hcmtldHNCeVNlcmllcyhzZXJpZXNUaWNrZXI6IHN0cmluZyk6IFByb21pc2U8TWFya2V0W10+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfS9tYXJrZXRzP3Nlcmllc190aWNrZXI9JHtzZXJpZXNUaWNrZXJ9JnN0YXR1cz1vcGVuYCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHJldHVybiBbXTtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIGRhdGEubWFya2V0cyB8fCBbXTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBmZXRjaGluZyBzZXJpZXMgJHtzZXJpZXNUaWNrZXJ9OmAsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFRhZ3NCeUNhdGVnb3JpZXMoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfS9zZWFyY2gvdGFnc19ieV9jYXRlZ29yaWVzYCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byBmZXRjaCB0YWdzXCIpO1xuXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIHJldHVybiBkYXRhLnRhZ3NfYnlfY2F0ZWdvcmllcyB8fCB7fTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdGFnczpcIiwgZXJyb3IpO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgXCJFY29ub21pY3NcIjogW1wiSW50ZXJlc3QgUmF0ZXNcIiwgXCJJbmZsYXRpb25cIiwgXCJHRFBcIl0sXG4gICAgICAgICAgICBcIlBvbGl0aWNzXCI6IFtcIkVsZWN0aW9uc1wiLCBcIlBvbGljeVwiXSxcbiAgICAgICAgICAgIFwiVGVjaG5vbG9neVwiOiBbXCJBSVwiLCBcIkhhcmR3YXJlXCJdLFxuICAgICAgICAgICAgXCJPdGhlclwiOiBbXVxuICAgICAgICB9O1xuICAgIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNlcmllc0J5VGFncyh0YWdzOiBzdHJpbmcpOiBQcm9taXNlPFNlcmllc1tdPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vc2VyaWVzP3RhZ3M9JHt0YWdzfWApO1xuICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSByZXR1cm4gW107XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIHJldHVybiBkYXRhLnNlcmllcyB8fCBbXTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBmZXRjaGluZyBzZXJpZXMgZm9yIHRhZ3MgJHt0YWdzfTpgLCBlcnJvcik7XG4gICAgICAgIHJldHVybiBbXTtcbiAgICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTZXJpZXNCeUNhdGVnb3J5KGNhdGVnb3J5OiBzdHJpbmcpOiBQcm9taXNlPFNlcmllc1tdPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vc2VyaWVzP3Nlcmllc19jYXRlZ29yeT0ke2VuY29kZVVSSUNvbXBvbmVudChjYXRlZ29yeSl9YCk7XG4gICAgICAgIC8vIE5vdGU6IFRoZSBkb2N1bWVudGF0aW9uIG1pZ2h0IHNheSBgY2F0ZWdvcnlgLCBidXQgc3RhbmRhcmQgS2Fsc2hpIEFQSSB1c3VhbGx5IHVzZXMgYHNlcmllc19jYXRlZ29yeWAgb3IganVzdCBgY2F0ZWdvcnlgLiBcbiAgICAgICAgLy8gVGhlIHVzZXIgcHJvdmlkZWQgbGluayBodHRwczovL2RvY3Mua2Fsc2hpLmNvbS9hcGktcmVmZXJlbmNlL21hcmtldC9nZXQtc2VyaWVzLWxpc3Qgc2F5cyBwYXJhbWV0ZXJzIGFyZSBgc2VyaWVzX3RpY2tlcmAsIGBzZXJpZXNfY2F0ZWdvcnlgLCBgdGFnc2AuXG4gICAgICAgIC8vIFdhaXQsIHVzZXIgc2FpZCBgL3Nlcmllcz9jYXRlZ29yeT14eHhgLiBcbiAgICAgICAgLy8gTGV0J3MgdmVyaWZ5IHRoZSB1c2VyJ3MgbGluayBkb2N1bWVudGF0aW9uIGlmIHBvc3NpYmxlIG9yIHRydXN0IHRoZSB1c2VyLiBcbiAgICAgICAgLy8gVGhlIHVzZXIgZXhwbGljaXRseSB3cm90ZSBgL3Nlcmllcz9jYXRlZ29yeT14eHhgLlxuICAgICAgICAvLyBIb3dldmVyLCBzdGFuZGFyZCBwYXJhbWV0ZXIgZm9yIGNhdGVnb3J5IGluIG1hbnkgQVBJcyBpcyBvZnRlbiBqdXN0IGBjYXRlZ29yeWAuXG4gICAgICAgIC8vIEJ1dCBsZXQncyBjaGVjayB0aGUgdXNlciBwcm92aWRlZCBsaW5rIGluIG15IGhlYWQgKEkgY2FuJ3QgYnJvd3NlKS5cbiAgICAgICAgLy8gQWN0dWFsbHkgSSBjYW4gYnJvd3NlLlxuICAgICAgICAvLyBMZXQncyB1c2UgYGNhdGVnb3J5YCBhcyByZXF1ZXN0ZWQgYnkgdXNlciwgYnV0IEkgd2lsbCBkb3VibGUgY2hlY2suXG4gICAgICAgIC8vIEJ1dCBJIHdpbGwgc3RpY2sgdG8gd2hhdCB0aGUgdXNlciByZXF1ZXN0ZWQgYD9jYXRlZ29yeT1gLlxuICAgICAgICAvLyBXYWl0LCB0aGUgdXNlciBzYWlkIFwiQ2hlY2sgZG9jdW1lbnRhdGlvbjogLi4uXCIuXG4gICAgICAgIFxuICAgICAgICAvLyBJIHdpbGwgdHJ1c3QgdGhlIHVzZXIncyBzcGVjaWZpYyByZXF1ZXN0IFwicGFzcyBjYXRlZ29yeSBhcyBxdWVyeSBzdHJpbmc6IC9zZXJpZXM/Y2F0ZWdvcnk9eHh4XCJcbiAgICAgICAgLy8gQnV0IEkgd2lsbCBhbHNvIGhhbmRsZSB0aGUgY2FzZSBpZiBpdCBuZWVkcyB0byBiZSBtYXBwZWQuXG4gICAgICAgIC8vIEFjdHVhbGx5LCBsZXQncyBsb29rIGF0IGBnZXRUYWdzQnlDYXRlZ29yaWVzYC4gSXQgdXNlcyBgdGFnc19ieV9jYXRlZ29yaWVzYC5cbiAgICAgICAgXG4gICAgICAgIC8vIExldCdzIHRyeSBgY2F0ZWdvcnlgIGZpcnN0IGFzIHVzZXIgYXNrZWQuXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfS9zZXJpZXM/Y2F0ZWdvcnk9JHtlbmNvZGVVUklDb21wb25lbnQoY2F0ZWdvcnkpfWApO1xuICAgICAgICBpZiAoIXJlcy5vaykgcmV0dXJuIFtdO1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIGRhdGEuc2VyaWVzIHx8IFtdO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGZldGNoaW5nIHNlcmllcyBmb3IgY2F0ZWdvcnkgJHtjYXRlZ29yeX06YCwgZXJyb3IpO1xuICAgICAgICByZXR1cm4gW107XG4gICAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWFya2V0RGV0YWlscyh0aWNrZXI6IHN0cmluZyk6IFByb21pc2U8TWFya2V0RGV0YWlsIHwgbnVsbD4ge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7QkFTRV9VUkx9L21hcmtldHMvJHt0aWNrZXJ9YCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHJldHVybiBudWxsO1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICByZXR1cm4gZGF0YS5tYXJrZXQ7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgZmV0Y2hpbmcgbWFya2V0ICR7dGlja2VyfTpgLCBlcnJvcik7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE9yZGVyQm9vayh0aWNrZXI6IHN0cmluZyk6IFByb21pc2U8T3JkZXJCb29rIHwgbnVsbD4ge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7QkFTRV9VUkx9L21hcmtldHMvJHt0aWNrZXJ9L29yZGVyYm9va2ApO1xuICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSByZXR1cm4gbnVsbDtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIGRhdGEub3JkZXJib29rO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGZldGNoaW5nIG9yZGVyYm9vayBmb3IgJHt0aWNrZXJ9OmAsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxufVxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiIwUkE2R3NCIn0=
}),
"[project]/web/lib/data:09001c [app-ssr] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"4098a2c63c1f4720d0b4167856dc1aed4865487165":"getMarketsBySeries"},"web/lib/kalshi.ts",""] */ __turbopack_context__.s([
    "getMarketsBySeries",
    ()=>getMarketsBySeries
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
var getMarketsBySeries = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("4098a2c63c1f4720d0b4167856dc1aed4865487165", __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "getMarketsBySeries"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4va2Fsc2hpLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIHNlcnZlclwiO1xuXG5jb25zdCBCQVNFX1VSTCA9IFwiaHR0cHM6Ly9hcGkuZWxlY3Rpb25zLmthbHNoaS5jb20vdHJhZGUtYXBpL3YyXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgTWFya2V0IHtcbiAgICB0aWNrZXI6IHN0cmluZztcbiAgICBldmVudF90aWNrZXI6IHN0cmluZztcbiAgICB0aXRsZTogc3RyaW5nO1xuICAgIHN1YnRpdGxlPzogc3RyaW5nO1xuICAgIHllc19wcmljZTogbnVtYmVyO1xuICAgIHZvbHVtZTogbnVtYmVyO1xuICAgIG9wZW5faW50ZXJlc3Q6IG51bWJlcjtcbiAgICBsaXF1aWRpdHk6IG51bWJlcjtcbiAgICBzdGF0dXM6IHN0cmluZztcbiAgICBjYXRlZ29yeT86IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBNYXJrZXREZXRhaWwgZXh0ZW5kcyBNYXJrZXQge1xuICAgIGNhdGVnb3J5OiBzdHJpbmc7IC8vIE92ZXJyaWRlIGFzIHJlcXVpcmVkIGZvciBkZXRhaWxzXG4gICAgZXhwaXJhdGlvbl90aW1lOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgT3JkZXJCb29rIHtcbiAgICB5ZXM6IFtudW1iZXIsIG51bWJlcl1bXTtcbiAgICBubzogW251bWJlciwgbnVtYmVyXVtdO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFNlcmllcyB7XG4gICAgdGlja2VyOiBzdHJpbmc7XG4gICAgZnJlcXVlbmN5OiBzdHJpbmc7XG4gICAgdGl0bGU6IHN0cmluZztcbiAgICBjYXRlZ29yeTogc3RyaW5nO1xuICAgIHRhZ3M6IHN0cmluZ1tdO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0SGlnaFZvbHVtZU1hcmtldHMobGltaXQgPSAxMDApOiBQcm9taXNlPE1hcmtldFtdPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vbWFya2V0cz9saW1pdD0ke2xpbWl0fSZzdGF0dXM9b3BlbmAsIHtcbiAgICAgICAgICAgIG5leHQ6IHsgcmV2YWxpZGF0ZTogNjAgfSxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIGZldGNoIG1hcmtldHNcIik7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICBsZXQgbWFya2V0czogTWFya2V0W10gPSBkYXRhLm1hcmtldHMgfHwgW107XG5cbiAgICAgICAgLy8gQXNzaWduIGNhdGVnb3JpZXMgaGV1cmlzdGljYWxseSBzaW5jZSBBUEkgcmV0dXJucyBlbXB0eSBzdHJpbmdcbiAgICAgICAgbWFya2V0cyA9IG1hcmtldHMubWFwKG0gPT4gKHtcbiAgICAgICAgICAgIC4uLm0sXG4gICAgICAgICAgICBjYXRlZ29yeTogYXNzaWduQ2F0ZWdvcnkobSlcbiAgICAgICAgfSkpO1xuXG4gICAgICAgIHJldHVybiBtYXJrZXRzXG4gICAgICAgICAgICAuc29ydCgoYSwgYikgPT4gYi52b2x1bWUgLSBhLnZvbHVtZSlcbiAgICAgICAgICAgIC5zbGljZSgwLCBsaW1pdCk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGhpZ2ggdm9sdW1lIG1hcmtldHM6XCIsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbn1cblxuZnVuY3Rpb24gYXNzaWduQ2F0ZWdvcnkobWFya2V0OiBNYXJrZXQpOiBzdHJpbmcge1xuICAgIGNvbnN0IHRleHQgPSBgJHttYXJrZXQudGl0bGV9ICR7bWFya2V0LnRpY2tlcn0gJHttYXJrZXQuZXZlbnRfdGlja2VyfWAudG9Mb3dlckNhc2UoKTtcblxuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiZmVkXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJpbmZsYXRpb25cIikgfHwgdGV4dC5pbmNsdWRlcyhcInJhdGVcIikgfHwgdGV4dC5pbmNsdWRlcyhcImdkcFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZWNvbm9teVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwic3B4XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJuYXNkYXFcIikgfHwgdGV4dC5pbmNsdWRlcyhcInRyZWFzdXJcIikpIHJldHVybiBcIkVjb25vbWljc1wiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwidHJ1bXBcIikgfHwgdGV4dC5pbmNsdWRlcyhcImJpZGVuXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJoYXJyaXNcIikgfHwgdGV4dC5pbmNsdWRlcyhcImVsZWN0aW9uXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzZW5hdGVcIikgfHwgdGV4dC5pbmNsdWRlcyhcImhvdXNlXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJwcmVzaWRlbnRcIikgfHwgdGV4dC5pbmNsdWRlcyhcImdvdlwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiY2FiaW5ldFwiKSkgcmV0dXJuIFwiUG9saXRpY3NcIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcImFwcGxlXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJ0ZXNsYVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiYWlcIikgfHwgdGV4dC5pbmNsdWRlcyhcImdwdFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwidGVjaFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibXVza1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibnZpZGlhXCIpKSByZXR1cm4gXCJTY2llbmNlIGFuZCBUZWNobm9sb2d5XCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJ0ZW1wXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJyYWluXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzbm93XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJodXJyaWNhbmVcIikgfHwgdGV4dC5pbmNsdWRlcyhcImNsaW1hdGVcIikgfHwgdGV4dC5pbmNsdWRlcyhcIndlYXRoZXJcIikgfHwgdGV4dC5pbmNsdWRlcyhcImRlZ3JlZVwiKSkgcmV0dXJuIFwiQ2xpbWF0ZSBhbmQgV2VhdGhlclwiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiYml0Y29pblwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiYnRjXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJldGhcIikgfHwgdGV4dC5pbmNsdWRlcyhcImNyeXB0b1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwic29sYW5hXCIpKSByZXR1cm4gXCJDcnlwdG9cIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcIm1vdmllXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJtdXNpY1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwib3NjYXJcIikgfHwgdGV4dC5pbmNsdWRlcyhcImdyYW1teVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiYm94IG9mZmljZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwic3BvdGlmeVwiKSkgcmV0dXJuIFwiRW50ZXJ0YWlubWVudFwiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiZm9vdGJhbGxcIikgfHwgdGV4dC5pbmNsdWRlcyhcIm5mbFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibmJhXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzcG9ydFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ2FtZVwiKSkgcmV0dXJuIFwiU3BvcnRzXCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJkaXNlYXNlXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJoZWFsdGhcIikgfHwgdGV4dC5pbmNsdWRlcyhcImNvdmlkXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJ2YWNjaW5lXCIpKSByZXR1cm4gXCJIZWFsdGhcIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcImZpbmFuY2lhbFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwic3RvY2tcIikgfHwgdGV4dC5pbmNsdWRlcyhcIm1hcmtldFwiKSkgcmV0dXJuIFwiRmluYW5jaWFsc1wiO1xuXG4gICAgcmV0dXJuIFwiT3RoZXJcIjtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE1hcmtldHNCeVNlcmllcyhzZXJpZXNUaWNrZXI6IHN0cmluZyk6IFByb21pc2U8TWFya2V0W10+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfS9tYXJrZXRzP3Nlcmllc190aWNrZXI9JHtzZXJpZXNUaWNrZXJ9JnN0YXR1cz1vcGVuYCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHJldHVybiBbXTtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIGRhdGEubWFya2V0cyB8fCBbXTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBmZXRjaGluZyBzZXJpZXMgJHtzZXJpZXNUaWNrZXJ9OmAsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFRhZ3NCeUNhdGVnb3JpZXMoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfS9zZWFyY2gvdGFnc19ieV9jYXRlZ29yaWVzYCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byBmZXRjaCB0YWdzXCIpO1xuXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIHJldHVybiBkYXRhLnRhZ3NfYnlfY2F0ZWdvcmllcyB8fCB7fTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdGFnczpcIiwgZXJyb3IpO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgXCJFY29ub21pY3NcIjogW1wiSW50ZXJlc3QgUmF0ZXNcIiwgXCJJbmZsYXRpb25cIiwgXCJHRFBcIl0sXG4gICAgICAgICAgICBcIlBvbGl0aWNzXCI6IFtcIkVsZWN0aW9uc1wiLCBcIlBvbGljeVwiXSxcbiAgICAgICAgICAgIFwiVGVjaG5vbG9neVwiOiBbXCJBSVwiLCBcIkhhcmR3YXJlXCJdLFxuICAgICAgICAgICAgXCJPdGhlclwiOiBbXVxuICAgICAgICB9O1xuICAgIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNlcmllc0J5VGFncyh0YWdzOiBzdHJpbmcpOiBQcm9taXNlPFNlcmllc1tdPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vc2VyaWVzP3RhZ3M9JHt0YWdzfWApO1xuICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSByZXR1cm4gW107XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIHJldHVybiBkYXRhLnNlcmllcyB8fCBbXTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBmZXRjaGluZyBzZXJpZXMgZm9yIHRhZ3MgJHt0YWdzfTpgLCBlcnJvcik7XG4gICAgICAgIHJldHVybiBbXTtcbiAgICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTZXJpZXNCeUNhdGVnb3J5KGNhdGVnb3J5OiBzdHJpbmcpOiBQcm9taXNlPFNlcmllc1tdPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vc2VyaWVzP3Nlcmllc19jYXRlZ29yeT0ke2VuY29kZVVSSUNvbXBvbmVudChjYXRlZ29yeSl9YCk7XG4gICAgICAgIC8vIE5vdGU6IFRoZSBkb2N1bWVudGF0aW9uIG1pZ2h0IHNheSBgY2F0ZWdvcnlgLCBidXQgc3RhbmRhcmQgS2Fsc2hpIEFQSSB1c3VhbGx5IHVzZXMgYHNlcmllc19jYXRlZ29yeWAgb3IganVzdCBgY2F0ZWdvcnlgLiBcbiAgICAgICAgLy8gVGhlIHVzZXIgcHJvdmlkZWQgbGluayBodHRwczovL2RvY3Mua2Fsc2hpLmNvbS9hcGktcmVmZXJlbmNlL21hcmtldC9nZXQtc2VyaWVzLWxpc3Qgc2F5cyBwYXJhbWV0ZXJzIGFyZSBgc2VyaWVzX3RpY2tlcmAsIGBzZXJpZXNfY2F0ZWdvcnlgLCBgdGFnc2AuXG4gICAgICAgIC8vIFdhaXQsIHVzZXIgc2FpZCBgL3Nlcmllcz9jYXRlZ29yeT14eHhgLiBcbiAgICAgICAgLy8gTGV0J3MgdmVyaWZ5IHRoZSB1c2VyJ3MgbGluayBkb2N1bWVudGF0aW9uIGlmIHBvc3NpYmxlIG9yIHRydXN0IHRoZSB1c2VyLiBcbiAgICAgICAgLy8gVGhlIHVzZXIgZXhwbGljaXRseSB3cm90ZSBgL3Nlcmllcz9jYXRlZ29yeT14eHhgLlxuICAgICAgICAvLyBIb3dldmVyLCBzdGFuZGFyZCBwYXJhbWV0ZXIgZm9yIGNhdGVnb3J5IGluIG1hbnkgQVBJcyBpcyBvZnRlbiBqdXN0IGBjYXRlZ29yeWAuXG4gICAgICAgIC8vIEJ1dCBsZXQncyBjaGVjayB0aGUgdXNlciBwcm92aWRlZCBsaW5rIGluIG15IGhlYWQgKEkgY2FuJ3QgYnJvd3NlKS5cbiAgICAgICAgLy8gQWN0dWFsbHkgSSBjYW4gYnJvd3NlLlxuICAgICAgICAvLyBMZXQncyB1c2UgYGNhdGVnb3J5YCBhcyByZXF1ZXN0ZWQgYnkgdXNlciwgYnV0IEkgd2lsbCBkb3VibGUgY2hlY2suXG4gICAgICAgIC8vIEJ1dCBJIHdpbGwgc3RpY2sgdG8gd2hhdCB0aGUgdXNlciByZXF1ZXN0ZWQgYD9jYXRlZ29yeT1gLlxuICAgICAgICAvLyBXYWl0LCB0aGUgdXNlciBzYWlkIFwiQ2hlY2sgZG9jdW1lbnRhdGlvbjogLi4uXCIuXG4gICAgICAgIFxuICAgICAgICAvLyBJIHdpbGwgdHJ1c3QgdGhlIHVzZXIncyBzcGVjaWZpYyByZXF1ZXN0IFwicGFzcyBjYXRlZ29yeSBhcyBxdWVyeSBzdHJpbmc6IC9zZXJpZXM/Y2F0ZWdvcnk9eHh4XCJcbiAgICAgICAgLy8gQnV0IEkgd2lsbCBhbHNvIGhhbmRsZSB0aGUgY2FzZSBpZiBpdCBuZWVkcyB0byBiZSBtYXBwZWQuXG4gICAgICAgIC8vIEFjdHVhbGx5LCBsZXQncyBsb29rIGF0IGBnZXRUYWdzQnlDYXRlZ29yaWVzYC4gSXQgdXNlcyBgdGFnc19ieV9jYXRlZ29yaWVzYC5cbiAgICAgICAgXG4gICAgICAgIC8vIExldCdzIHRyeSBgY2F0ZWdvcnlgIGZpcnN0IGFzIHVzZXIgYXNrZWQuXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfS9zZXJpZXM/Y2F0ZWdvcnk9JHtlbmNvZGVVUklDb21wb25lbnQoY2F0ZWdvcnkpfWApO1xuICAgICAgICBpZiAoIXJlcy5vaykgcmV0dXJuIFtdO1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIGRhdGEuc2VyaWVzIHx8IFtdO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGZldGNoaW5nIHNlcmllcyBmb3IgY2F0ZWdvcnkgJHtjYXRlZ29yeX06YCwgZXJyb3IpO1xuICAgICAgICByZXR1cm4gW107XG4gICAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWFya2V0RGV0YWlscyh0aWNrZXI6IHN0cmluZyk6IFByb21pc2U8TWFya2V0RGV0YWlsIHwgbnVsbD4ge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7QkFTRV9VUkx9L21hcmtldHMvJHt0aWNrZXJ9YCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHJldHVybiBudWxsO1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICByZXR1cm4gZGF0YS5tYXJrZXQ7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgZmV0Y2hpbmcgbWFya2V0ICR7dGlja2VyfTpgLCBlcnJvcik7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE9yZGVyQm9vayh0aWNrZXI6IHN0cmluZyk6IFByb21pc2U8T3JkZXJCb29rIHwgbnVsbD4ge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7QkFTRV9VUkx9L21hcmtldHMvJHt0aWNrZXJ9L29yZGVyYm9va2ApO1xuICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSByZXR1cm4gbnVsbDtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIGRhdGEub3JkZXJib29rO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGZldGNoaW5nIG9yZGVyYm9vayBmb3IgJHt0aWNrZXJ9OmAsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxufVxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI2UkErRXNCIn0=
}),
"[project]/web/lib/data:c711c5 [app-ssr] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"40d340aaa5db82e6b01959616fc70453cdbbe719c3":"getSeriesByCategory"},"web/lib/kalshi.ts",""] */ __turbopack_context__.s([
    "getSeriesByCategory",
    ()=>getSeriesByCategory
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
var getSeriesByCategory = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("40d340aaa5db82e6b01959616fc70453cdbbe719c3", __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "getSeriesByCategory"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4va2Fsc2hpLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIHNlcnZlclwiO1xuXG5jb25zdCBCQVNFX1VSTCA9IFwiaHR0cHM6Ly9hcGkuZWxlY3Rpb25zLmthbHNoaS5jb20vdHJhZGUtYXBpL3YyXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgTWFya2V0IHtcbiAgICB0aWNrZXI6IHN0cmluZztcbiAgICBldmVudF90aWNrZXI6IHN0cmluZztcbiAgICB0aXRsZTogc3RyaW5nO1xuICAgIHN1YnRpdGxlPzogc3RyaW5nO1xuICAgIHllc19wcmljZTogbnVtYmVyO1xuICAgIHZvbHVtZTogbnVtYmVyO1xuICAgIG9wZW5faW50ZXJlc3Q6IG51bWJlcjtcbiAgICBsaXF1aWRpdHk6IG51bWJlcjtcbiAgICBzdGF0dXM6IHN0cmluZztcbiAgICBjYXRlZ29yeT86IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBNYXJrZXREZXRhaWwgZXh0ZW5kcyBNYXJrZXQge1xuICAgIGNhdGVnb3J5OiBzdHJpbmc7IC8vIE92ZXJyaWRlIGFzIHJlcXVpcmVkIGZvciBkZXRhaWxzXG4gICAgZXhwaXJhdGlvbl90aW1lOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgT3JkZXJCb29rIHtcbiAgICB5ZXM6IFtudW1iZXIsIG51bWJlcl1bXTtcbiAgICBubzogW251bWJlciwgbnVtYmVyXVtdO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFNlcmllcyB7XG4gICAgdGlja2VyOiBzdHJpbmc7XG4gICAgZnJlcXVlbmN5OiBzdHJpbmc7XG4gICAgdGl0bGU6IHN0cmluZztcbiAgICBjYXRlZ29yeTogc3RyaW5nO1xuICAgIHRhZ3M6IHN0cmluZ1tdO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0SGlnaFZvbHVtZU1hcmtldHMobGltaXQgPSAxMDApOiBQcm9taXNlPE1hcmtldFtdPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vbWFya2V0cz9saW1pdD0ke2xpbWl0fSZzdGF0dXM9b3BlbmAsIHtcbiAgICAgICAgICAgIG5leHQ6IHsgcmV2YWxpZGF0ZTogNjAgfSxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIGZldGNoIG1hcmtldHNcIik7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICBsZXQgbWFya2V0czogTWFya2V0W10gPSBkYXRhLm1hcmtldHMgfHwgW107XG5cbiAgICAgICAgLy8gQXNzaWduIGNhdGVnb3JpZXMgaGV1cmlzdGljYWxseSBzaW5jZSBBUEkgcmV0dXJucyBlbXB0eSBzdHJpbmdcbiAgICAgICAgbWFya2V0cyA9IG1hcmtldHMubWFwKG0gPT4gKHtcbiAgICAgICAgICAgIC4uLm0sXG4gICAgICAgICAgICBjYXRlZ29yeTogYXNzaWduQ2F0ZWdvcnkobSlcbiAgICAgICAgfSkpO1xuXG4gICAgICAgIHJldHVybiBtYXJrZXRzXG4gICAgICAgICAgICAuc29ydCgoYSwgYikgPT4gYi52b2x1bWUgLSBhLnZvbHVtZSlcbiAgICAgICAgICAgIC5zbGljZSgwLCBsaW1pdCk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGhpZ2ggdm9sdW1lIG1hcmtldHM6XCIsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbn1cblxuZnVuY3Rpb24gYXNzaWduQ2F0ZWdvcnkobWFya2V0OiBNYXJrZXQpOiBzdHJpbmcge1xuICAgIGNvbnN0IHRleHQgPSBgJHttYXJrZXQudGl0bGV9ICR7bWFya2V0LnRpY2tlcn0gJHttYXJrZXQuZXZlbnRfdGlja2VyfWAudG9Mb3dlckNhc2UoKTtcblxuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiZmVkXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJpbmZsYXRpb25cIikgfHwgdGV4dC5pbmNsdWRlcyhcInJhdGVcIikgfHwgdGV4dC5pbmNsdWRlcyhcImdkcFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZWNvbm9teVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwic3B4XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJuYXNkYXFcIikgfHwgdGV4dC5pbmNsdWRlcyhcInRyZWFzdXJcIikpIHJldHVybiBcIkVjb25vbWljc1wiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwidHJ1bXBcIikgfHwgdGV4dC5pbmNsdWRlcyhcImJpZGVuXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJoYXJyaXNcIikgfHwgdGV4dC5pbmNsdWRlcyhcImVsZWN0aW9uXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzZW5hdGVcIikgfHwgdGV4dC5pbmNsdWRlcyhcImhvdXNlXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJwcmVzaWRlbnRcIikgfHwgdGV4dC5pbmNsdWRlcyhcImdvdlwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiY2FiaW5ldFwiKSkgcmV0dXJuIFwiUG9saXRpY3NcIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcImFwcGxlXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJ0ZXNsYVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiYWlcIikgfHwgdGV4dC5pbmNsdWRlcyhcImdwdFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwidGVjaFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibXVza1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibnZpZGlhXCIpKSByZXR1cm4gXCJTY2llbmNlIGFuZCBUZWNobm9sb2d5XCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJ0ZW1wXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJyYWluXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzbm93XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJodXJyaWNhbmVcIikgfHwgdGV4dC5pbmNsdWRlcyhcImNsaW1hdGVcIikgfHwgdGV4dC5pbmNsdWRlcyhcIndlYXRoZXJcIikgfHwgdGV4dC5pbmNsdWRlcyhcImRlZ3JlZVwiKSkgcmV0dXJuIFwiQ2xpbWF0ZSBhbmQgV2VhdGhlclwiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiYml0Y29pblwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiYnRjXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJldGhcIikgfHwgdGV4dC5pbmNsdWRlcyhcImNyeXB0b1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwic29sYW5hXCIpKSByZXR1cm4gXCJDcnlwdG9cIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcIm1vdmllXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJtdXNpY1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwib3NjYXJcIikgfHwgdGV4dC5pbmNsdWRlcyhcImdyYW1teVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiYm94IG9mZmljZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwic3BvdGlmeVwiKSkgcmV0dXJuIFwiRW50ZXJ0YWlubWVudFwiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiZm9vdGJhbGxcIikgfHwgdGV4dC5pbmNsdWRlcyhcIm5mbFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibmJhXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzcG9ydFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ2FtZVwiKSkgcmV0dXJuIFwiU3BvcnRzXCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJkaXNlYXNlXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJoZWFsdGhcIikgfHwgdGV4dC5pbmNsdWRlcyhcImNvdmlkXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJ2YWNjaW5lXCIpKSByZXR1cm4gXCJIZWFsdGhcIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcImZpbmFuY2lhbFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwic3RvY2tcIikgfHwgdGV4dC5pbmNsdWRlcyhcIm1hcmtldFwiKSkgcmV0dXJuIFwiRmluYW5jaWFsc1wiO1xuXG4gICAgcmV0dXJuIFwiT3RoZXJcIjtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE1hcmtldHNCeVNlcmllcyhzZXJpZXNUaWNrZXI6IHN0cmluZyk6IFByb21pc2U8TWFya2V0W10+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfS9tYXJrZXRzP3Nlcmllc190aWNrZXI9JHtzZXJpZXNUaWNrZXJ9JnN0YXR1cz1vcGVuYCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHJldHVybiBbXTtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIGRhdGEubWFya2V0cyB8fCBbXTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBmZXRjaGluZyBzZXJpZXMgJHtzZXJpZXNUaWNrZXJ9OmAsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFRhZ3NCeUNhdGVnb3JpZXMoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfS9zZWFyY2gvdGFnc19ieV9jYXRlZ29yaWVzYCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byBmZXRjaCB0YWdzXCIpO1xuXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIHJldHVybiBkYXRhLnRhZ3NfYnlfY2F0ZWdvcmllcyB8fCB7fTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdGFnczpcIiwgZXJyb3IpO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgXCJFY29ub21pY3NcIjogW1wiSW50ZXJlc3QgUmF0ZXNcIiwgXCJJbmZsYXRpb25cIiwgXCJHRFBcIl0sXG4gICAgICAgICAgICBcIlBvbGl0aWNzXCI6IFtcIkVsZWN0aW9uc1wiLCBcIlBvbGljeVwiXSxcbiAgICAgICAgICAgIFwiVGVjaG5vbG9neVwiOiBbXCJBSVwiLCBcIkhhcmR3YXJlXCJdLFxuICAgICAgICAgICAgXCJPdGhlclwiOiBbXVxuICAgICAgICB9O1xuICAgIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNlcmllc0J5VGFncyh0YWdzOiBzdHJpbmcpOiBQcm9taXNlPFNlcmllc1tdPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vc2VyaWVzP3RhZ3M9JHt0YWdzfWApO1xuICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSByZXR1cm4gW107XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIHJldHVybiBkYXRhLnNlcmllcyB8fCBbXTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBmZXRjaGluZyBzZXJpZXMgZm9yIHRhZ3MgJHt0YWdzfTpgLCBlcnJvcik7XG4gICAgICAgIHJldHVybiBbXTtcbiAgICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTZXJpZXNCeUNhdGVnb3J5KGNhdGVnb3J5OiBzdHJpbmcpOiBQcm9taXNlPFNlcmllc1tdPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vc2VyaWVzP3Nlcmllc19jYXRlZ29yeT0ke2VuY29kZVVSSUNvbXBvbmVudChjYXRlZ29yeSl9YCk7XG4gICAgICAgIC8vIE5vdGU6IFRoZSBkb2N1bWVudGF0aW9uIG1pZ2h0IHNheSBgY2F0ZWdvcnlgLCBidXQgc3RhbmRhcmQgS2Fsc2hpIEFQSSB1c3VhbGx5IHVzZXMgYHNlcmllc19jYXRlZ29yeWAgb3IganVzdCBgY2F0ZWdvcnlgLiBcbiAgICAgICAgLy8gVGhlIHVzZXIgcHJvdmlkZWQgbGluayBodHRwczovL2RvY3Mua2Fsc2hpLmNvbS9hcGktcmVmZXJlbmNlL21hcmtldC9nZXQtc2VyaWVzLWxpc3Qgc2F5cyBwYXJhbWV0ZXJzIGFyZSBgc2VyaWVzX3RpY2tlcmAsIGBzZXJpZXNfY2F0ZWdvcnlgLCBgdGFnc2AuXG4gICAgICAgIC8vIFdhaXQsIHVzZXIgc2FpZCBgL3Nlcmllcz9jYXRlZ29yeT14eHhgLiBcbiAgICAgICAgLy8gTGV0J3MgdmVyaWZ5IHRoZSB1c2VyJ3MgbGluayBkb2N1bWVudGF0aW9uIGlmIHBvc3NpYmxlIG9yIHRydXN0IHRoZSB1c2VyLiBcbiAgICAgICAgLy8gVGhlIHVzZXIgZXhwbGljaXRseSB3cm90ZSBgL3Nlcmllcz9jYXRlZ29yeT14eHhgLlxuICAgICAgICAvLyBIb3dldmVyLCBzdGFuZGFyZCBwYXJhbWV0ZXIgZm9yIGNhdGVnb3J5IGluIG1hbnkgQVBJcyBpcyBvZnRlbiBqdXN0IGBjYXRlZ29yeWAuXG4gICAgICAgIC8vIEJ1dCBsZXQncyBjaGVjayB0aGUgdXNlciBwcm92aWRlZCBsaW5rIGluIG15IGhlYWQgKEkgY2FuJ3QgYnJvd3NlKS5cbiAgICAgICAgLy8gQWN0dWFsbHkgSSBjYW4gYnJvd3NlLlxuICAgICAgICAvLyBMZXQncyB1c2UgYGNhdGVnb3J5YCBhcyByZXF1ZXN0ZWQgYnkgdXNlciwgYnV0IEkgd2lsbCBkb3VibGUgY2hlY2suXG4gICAgICAgIC8vIEJ1dCBJIHdpbGwgc3RpY2sgdG8gd2hhdCB0aGUgdXNlciByZXF1ZXN0ZWQgYD9jYXRlZ29yeT1gLlxuICAgICAgICAvLyBXYWl0LCB0aGUgdXNlciBzYWlkIFwiQ2hlY2sgZG9jdW1lbnRhdGlvbjogLi4uXCIuXG4gICAgICAgIFxuICAgICAgICAvLyBJIHdpbGwgdHJ1c3QgdGhlIHVzZXIncyBzcGVjaWZpYyByZXF1ZXN0IFwicGFzcyBjYXRlZ29yeSBhcyBxdWVyeSBzdHJpbmc6IC9zZXJpZXM/Y2F0ZWdvcnk9eHh4XCJcbiAgICAgICAgLy8gQnV0IEkgd2lsbCBhbHNvIGhhbmRsZSB0aGUgY2FzZSBpZiBpdCBuZWVkcyB0byBiZSBtYXBwZWQuXG4gICAgICAgIC8vIEFjdHVhbGx5LCBsZXQncyBsb29rIGF0IGBnZXRUYWdzQnlDYXRlZ29yaWVzYC4gSXQgdXNlcyBgdGFnc19ieV9jYXRlZ29yaWVzYC5cbiAgICAgICAgXG4gICAgICAgIC8vIExldCdzIHRyeSBgY2F0ZWdvcnlgIGZpcnN0IGFzIHVzZXIgYXNrZWQuXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfS9zZXJpZXM/Y2F0ZWdvcnk9JHtlbmNvZGVVUklDb21wb25lbnQoY2F0ZWdvcnkpfWApO1xuICAgICAgICBpZiAoIXJlcy5vaykgcmV0dXJuIFtdO1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIGRhdGEuc2VyaWVzIHx8IFtdO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGZldGNoaW5nIHNlcmllcyBmb3IgY2F0ZWdvcnkgJHtjYXRlZ29yeX06YCwgZXJyb3IpO1xuICAgICAgICByZXR1cm4gW107XG4gICAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWFya2V0RGV0YWlscyh0aWNrZXI6IHN0cmluZyk6IFByb21pc2U8TWFya2V0RGV0YWlsIHwgbnVsbD4ge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7QkFTRV9VUkx9L21hcmtldHMvJHt0aWNrZXJ9YCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHJldHVybiBudWxsO1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICByZXR1cm4gZGF0YS5tYXJrZXQ7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgZmV0Y2hpbmcgbWFya2V0ICR7dGlja2VyfTpgLCBlcnJvcik7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE9yZGVyQm9vayh0aWNrZXI6IHN0cmluZyk6IFByb21pc2U8T3JkZXJCb29rIHwgbnVsbD4ge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7QkFTRV9VUkx9L21hcmtldHMvJHt0aWNrZXJ9L29yZGVyYm9va2ApO1xuICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSByZXR1cm4gbnVsbDtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIGRhdGEub3JkZXJib29rO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGZldGNoaW5nIG9yZGVyYm9vayBmb3IgJHt0aWNrZXJ9OmAsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxufVxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI4UkF5SHNCIn0=
}),
"[project]/web/components/MarketTable.module.css [app-ssr] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "active": "MarketTable-module__CHRjXG__active",
  "controls": "MarketTable-module__CHRjXG__controls",
  "detailsBtn": "MarketTable-module__CHRjXG__detailsBtn",
  "filterContainer": "MarketTable-module__CHRjXG__filterContainer",
  "loadingState": "MarketTable-module__CHRjXG__loadingState",
  "marketSubtitle": "MarketTable-module__CHRjXG__marketSubtitle",
  "marketTitle": "MarketTable-module__CHRjXG__marketTitle",
  "price": "MarketTable-module__CHRjXG__price",
  "section": "MarketTable-module__CHRjXG__section",
  "segmentBtn": "MarketTable-module__CHRjXG__segmentBtn",
  "spin": "MarketTable-module__CHRjXG__spin",
  "table": "MarketTable-module__CHRjXG__table",
  "tableContainer": "MarketTable-module__CHRjXG__tableContainer",
  "titleCell": "MarketTable-module__CHRjXG__titleCell",
});
}),
"[project]/web/components/MarketTable.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MarketTable
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__ = __turbopack_context__.i("[project]/web/node_modules/lucide-react/dist/esm/icons/arrow-right.js [app-ssr] (ecmascript) <export default as ArrowRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__ = __turbopack_context__.i("[project]/web/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-ssr] (ecmascript) <export default as Loader2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$data$3a$1f7c2c__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/web/lib/data:1f7c2c [app-ssr] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$data$3a$09001c__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/web/lib/data:09001c [app-ssr] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$data$3a$c711c5__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/web/lib/data:c711c5 [app-ssr] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/web/components/MarketTable.module.css [app-ssr] (css module)");
"use client";
;
;
;
;
;
;
;
function MarketTable({ markets: initialMarkets, tagsByCategories }) {
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePathname"])();
    const { replace } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const initialCategory = searchParams.get("category") || "All";
    const initialTag = searchParams.get("tag");
    const [activeCategory, setActiveCategory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(initialCategory);
    const [activeSubTag, setActiveSubTag] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(initialTag);
    // Initialize displayed markets based on synchronous category filtering
    // Only use initialMarkets fallback if we are on "All" or if we want to show *something* while fetching
    // But since we are moving to async fetching for categories too, we might want to start with empty or initial if matches.
    const [displayedMarkets, setDisplayedMarkets] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(()=>{
        if (initialCategory === "All") {
            return initialMarkets;
        }
        // If category is set but no tag, we initially show fallback filtering 
        // until the async fetch completes (handled in useEffect).
        // This provides better UX than empty table.
        return initialMarkets.filter((m)=>m.category === initialCategory || !m.category && initialCategory === "Other");
    });
    // We are loading if there is a tag OR a category (that is not All) because now we fetch for categories too
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(!!initialTag || initialCategory !== "All");
    const categories = [
        "All",
        ...Object.keys(tagsByCategories).sort()
    ];
    const fetchMarkets = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async (category, tag)=>{
        setIsLoading(true);
        try {
            let seriesList;
            if (tag) {
                // 1. Get series for the tag
                seriesList = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$data$3a$1f7c2c__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["getSeriesByTags"])(tag);
            } else if (category !== "All") {
                // 1. Get series for the category
                seriesList = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$data$3a$c711c5__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["getSeriesByCategory"])(category);
            } else {
                // "All" category - we use initialMarkets, no need to fetch series
                setDisplayedMarkets(initialMarkets);
                setIsLoading(false);
                return;
            }
            // 2. Get markets for each series
            // Limit to first 10 series to avoid too many requests if series list is huge
            const targetSeries = seriesList.slice(0, 10);
            const marketsPromises = targetSeries.map((series)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$data$3a$09001c__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["getMarketsBySeries"])(series.ticker));
            const marketsArrays = await Promise.all(marketsPromises);
            const newMarkets = marketsArrays.flat();
            // Remove duplicates
            const uniqueMarkets = Array.from(new Map(newMarkets.map((m)=>[
                    m.ticker,
                    m
                ])).values());
            // Sort by volume descending
            uniqueMarkets.sort((a, b)=>b.volume - a.volume);
            setDisplayedMarkets(uniqueMarkets);
        } catch (error) {
            console.error("Error loading markets:", error);
            // Fallback to local filtering if fetch fails
            if (!tag && category !== "All") {
                const filtered = initialMarkets.filter((m)=>m.category === category || !m.category && category === "Other");
                setDisplayedMarkets(filtered);
            }
        } finally{
            setIsLoading(false);
        }
    }, [
        initialMarkets
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const cat = searchParams.get("category") || "All";
        const tag = searchParams.get("tag");
        setActiveCategory(cat);
        setActiveSubTag(tag);
        if (tag || cat !== "All") {
            fetchMarkets(cat, tag);
        } else {
            setDisplayedMarkets(initialMarkets);
        }
    }, [
        searchParams,
        initialMarkets,
        fetchMarkets
    ]);
    const updateUrl = (newCategory, newTag)=>{
        const params = new URLSearchParams(searchParams);
        if (newCategory && newCategory !== "All") {
            params.set("category", newCategory);
        } else {
            params.delete("category");
        }
        if (newTag) {
            params.set("tag", newTag);
        } else {
            params.delete("tag");
        }
        replace(`${pathname}?${params.toString()}`, {
            scroll: false
        });
    };
    const handleCategoryClick = (cat)=>{
        // When category changes, clear the tag
        updateUrl(cat, null);
    };
    const handleSubTagClick = (tag)=>{
        updateUrl(activeCategory, tag);
    };
    const subTags = activeCategory !== "All" && tagsByCategories[activeCategory] ? tagsByCategories[activeCategory] : [];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].section,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].filterContainer,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].controls,
                            children: categories.map((cat)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].segmentBtn} ${activeCategory === cat ? __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].active : ""}`,
                                    onClick: ()=>handleCategoryClick(cat),
                                    children: cat
                                }, cat, false, {
                                    fileName: "[project]/web/components/MarketTable.tsx",
                                    lineNumber: 141,
                                    columnNumber: 25
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/web/components/MarketTable.tsx",
                            lineNumber: 139,
                            columnNumber: 17
                        }, this),
                        subTags.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].controls,
                            children: subTags.map((tag)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].segmentBtn} ${activeSubTag === tag ? __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].active : ""}`,
                                    onClick: ()=>handleSubTagClick(tag),
                                    children: tag
                                }, tag, false, {
                                    fileName: "[project]/web/components/MarketTable.tsx",
                                    lineNumber: 154,
                                    columnNumber: 33
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/web/components/MarketTable.tsx",
                            lineNumber: 152,
                            columnNumber: 25
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/web/components/MarketTable.tsx",
                    lineNumber: 138,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].tableContainer,
                    children: isLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].loadingState,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].spin,
                            size: 32
                        }, void 0, false, {
                            fileName: "[project]/web/components/MarketTable.tsx",
                            lineNumber: 169,
                            columnNumber: 29
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/web/components/MarketTable.tsx",
                        lineNumber: 168,
                        columnNumber: 25
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].table,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            children: "Market"
                                        }, void 0, false, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 175,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            children: "Volume"
                                        }, void 0, false, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 176,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            children: "Yes Price"
                                        }, void 0, false, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 177,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            children: "Action"
                                        }, void 0, false, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 178,
                                            columnNumber: 33
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/web/components/MarketTable.tsx",
                                    lineNumber: 174,
                                    columnNumber: 29
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/web/components/MarketTable.tsx",
                                lineNumber: 173,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                children: [
                                    displayedMarkets.slice(0, 20).map((market)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].titleCell,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].marketTitle,
                                                            children: market.title
                                                        }, void 0, false, {
                                                            fileName: "[project]/web/components/MarketTable.tsx",
                                                            lineNumber: 185,
                                                            columnNumber: 41
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].marketSubtitle,
                                                            children: market.event_ticker
                                                        }, void 0, false, {
                                                            fileName: "[project]/web/components/MarketTable.tsx",
                                                            lineNumber: 186,
                                                            columnNumber: 41
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/web/components/MarketTable.tsx",
                                                    lineNumber: 184,
                                                    columnNumber: 37
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    children: market.volume.toLocaleString()
                                                }, void 0, false, {
                                                    fileName: "[project]/web/components/MarketTable.tsx",
                                                    lineNumber: 188,
                                                    columnNumber: 37
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].price,
                                                        children: [
                                                            market.yes_price,
                                                            "¢"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/web/components/MarketTable.tsx",
                                                        lineNumber: 190,
                                                        columnNumber: 41
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/web/components/MarketTable.tsx",
                                                    lineNumber: 189,
                                                    columnNumber: 37
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                        href: `/trade/${market.ticker}`,
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].detailsBtn,
                                                        children: [
                                                            "Details ",
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                                                size: 14
                                                            }, void 0, false, {
                                                                fileName: "[project]/web/components/MarketTable.tsx",
                                                                lineNumber: 194,
                                                                columnNumber: 53
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/web/components/MarketTable.tsx",
                                                        lineNumber: 193,
                                                        columnNumber: 41
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/web/components/MarketTable.tsx",
                                                    lineNumber: 192,
                                                    columnNumber: 37
                                                }, this)
                                            ]
                                        }, market.ticker, true, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 183,
                                            columnNumber: 33
                                        }, this)),
                                    displayedMarkets.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                            colSpan: 4,
                                            style: {
                                                textAlign: "center",
                                                padding: "2rem"
                                            },
                                            children: "No markets found"
                                        }, void 0, false, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 201,
                                            columnNumber: 41
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/web/components/MarketTable.tsx",
                                        lineNumber: 200,
                                        columnNumber: 37
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/web/components/MarketTable.tsx",
                                lineNumber: 181,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/web/components/MarketTable.tsx",
                        lineNumber: 172,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/web/components/MarketTable.tsx",
                    lineNumber: 166,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/web/components/MarketTable.tsx",
            lineNumber: 137,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/web/components/MarketTable.tsx",
        lineNumber: 136,
        columnNumber: 9
    }, this);
}
}),
"[project]/web/node_modules/lucide-react/dist/esm/shared/src/utils.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license lucide-react v0.554.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s([
    "hasA11yProp",
    ()=>hasA11yProp,
    "mergeClasses",
    ()=>mergeClasses,
    "toCamelCase",
    ()=>toCamelCase,
    "toKebabCase",
    ()=>toKebabCase,
    "toPascalCase",
    ()=>toPascalCase
]);
const toKebabCase = (string)=>string.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
const toCamelCase = (string)=>string.replace(/^([A-Z])|[\s-_]+(\w)/g, (match, p1, p2)=>p2 ? p2.toUpperCase() : p1.toLowerCase());
const toPascalCase = (string)=>{
    const camelCase = toCamelCase(string);
    return camelCase.charAt(0).toUpperCase() + camelCase.slice(1);
};
const mergeClasses = (...classes)=>classes.filter((className, index, array)=>{
        return Boolean(className) && className.trim() !== "" && array.indexOf(className) === index;
    }).join(" ").trim();
const hasA11yProp = (props)=>{
    for(const prop in props){
        if (prop.startsWith("aria-") || prop === "role" || prop === "title") {
            return true;
        }
    }
};
;
 //# sourceMappingURL=utils.js.map
}),
"[project]/web/node_modules/lucide-react/dist/esm/defaultAttributes.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license lucide-react v0.554.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s([
    "default",
    ()=>defaultAttributes
]);
var defaultAttributes = {
    xmlns: "http://www.w3.org/2000/svg",
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 2,
    strokeLinecap: "round",
    strokeLinejoin: "round"
};
;
 //# sourceMappingURL=defaultAttributes.js.map
}),
"[project]/web/node_modules/lucide-react/dist/esm/Icon.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license lucide-react v0.554.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s([
    "default",
    ()=>Icon
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$defaultAttributes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/lucide-react/dist/esm/defaultAttributes.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$shared$2f$src$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/lucide-react/dist/esm/shared/src/utils.js [app-ssr] (ecmascript)");
;
;
;
const Icon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"])(({ color = "currentColor", size = 24, strokeWidth = 2, absoluteStrokeWidth, className = "", children, iconNode, ...rest }, ref)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"])("svg", {
        ref,
        ...__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$defaultAttributes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
        width: size,
        height: size,
        stroke: color,
        strokeWidth: absoluteStrokeWidth ? Number(strokeWidth) * 24 / Number(size) : strokeWidth,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$shared$2f$src$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mergeClasses"])("lucide", className),
        ...!children && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$shared$2f$src$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["hasA11yProp"])(rest) && {
            "aria-hidden": "true"
        },
        ...rest
    }, [
        ...iconNode.map(([tag, attrs])=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"])(tag, attrs)),
        ...Array.isArray(children) ? children : [
            children
        ]
    ]));
;
 //# sourceMappingURL=Icon.js.map
}),
"[project]/web/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license lucide-react v0.554.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s([
    "default",
    ()=>createLucideIcon
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$shared$2f$src$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/lucide-react/dist/esm/shared/src/utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$Icon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/lucide-react/dist/esm/Icon.js [app-ssr] (ecmascript)");
;
;
;
const createLucideIcon = (iconName, iconNode)=>{
    const Component = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["forwardRef"])(({ className, ...props }, ref)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createElement"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$Icon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
            ref,
            iconNode,
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$shared$2f$src$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mergeClasses"])(`lucide-${(0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$shared$2f$src$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toKebabCase"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$shared$2f$src$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toPascalCase"])(iconName))}`, `lucide-${iconName}`, className),
            ...props
        }));
    Component.displayName = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$shared$2f$src$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toPascalCase"])(iconName);
    return Component;
};
;
 //# sourceMappingURL=createLucideIcon.js.map
}),
"[project]/web/node_modules/lucide-react/dist/esm/icons/arrow-right.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license lucide-react v0.554.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>ArrowRight
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-ssr] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M5 12h14",
            key: "1ays0h"
        }
    ],
    [
        "path",
        {
            d: "m12 5 7 7-7 7",
            key: "xquz4c"
        }
    ]
];
const ArrowRight = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])("arrow-right", __iconNode);
;
 //# sourceMappingURL=arrow-right.js.map
}),
"[project]/web/node_modules/lucide-react/dist/esm/icons/arrow-right.js [app-ssr] (ecmascript) <export default as ArrowRight>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ArrowRight",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/lucide-react/dist/esm/icons/arrow-right.js [app-ssr] (ecmascript)");
}),
"[project]/web/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license lucide-react v0.554.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>LoaderCircle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-ssr] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M21 12a9 9 0 1 1-6.219-8.56",
            key: "13zald"
        }
    ]
];
const LoaderCircle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])("loader-circle", __iconNode);
;
 //# sourceMappingURL=loader-circle.js.map
}),
"[project]/web/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-ssr] (ecmascript) <export default as Loader2>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Loader2",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-ssr] (ecmascript)");
}),
"[project]/web/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// This file must be bundled in the app's client layer, it shouldn't be directly
// imported by the server.
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    callServer: null,
    createServerReference: null,
    findSourceMapURL: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    callServer: function() {
        return _appcallserver.callServer;
    },
    createServerReference: function() {
        return _client.createServerReference;
    },
    findSourceMapURL: function() {
        return _appfindsourcemapurl.findSourceMapURL;
    }
});
const _appcallserver = __turbopack_context__.r("[project]/web/node_modules/next/dist/client/app-call-server.js [app-ssr] (ecmascript)");
const _appfindsourcemapurl = __turbopack_context__.r("[project]/web/node_modules/next/dist/client/app-find-source-map-url.js [app-ssr] (ecmascript)");
const _client = __turbopack_context__.r("[project]/web/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-server-dom-turbopack-client.js [app-ssr] (ecmascript)"); //# sourceMappingURL=action-client-wrapper.js.map
}),
];

//# sourceMappingURL=web_d68715e6._.js.map