module.exports = [
"[project]/web/lib/kalshi.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"0080a0c14b1fc0948713b48296d412c543012fe137":"getTagsByCategories","407e4f66b279acc536a69b80ffb28e1e41e4ef2c4c":"getMarketDetails","409071e25c2a92798fac6387e9301fdc81bce11cd4":"getSeriesByTags","4098a2c63c1f4720d0b4167856dc1aed4865487165":"getMarketsBySeries","40d340aaa5db82e6b01959616fc70453cdbbe719c3":"getSeriesByCategory","40ef9b940eb0268acbb2520b8deedf1b073fcea482":"getHighVolumeMarkets","40fc189a2f119b7e2eae225f04dc1e5d1345aa812d":"getOrderBook"},"",""] */ __turbopack_context__.s([
    "getHighVolumeMarkets",
    ()=>getHighVolumeMarkets,
    "getMarketDetails",
    ()=>getMarketDetails,
    "getMarketsBySeries",
    ()=>getMarketsBySeries,
    "getOrderBook",
    ()=>getOrderBook,
    "getSeriesByCategory",
    ()=>getSeriesByCategory,
    "getSeriesByTags",
    ()=>getSeriesByTags,
    "getTagsByCategories",
    ()=>getTagsByCategories
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/build/webpack/loaders/next-flight-loader/server-reference.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-validate.js [app-rsc] (ecmascript)");
;
const BASE_URL = "https://api.elections.kalshi.com/trade-api/v2";
async function getHighVolumeMarkets(limit = 100) {
    try {
        const response = await fetch(`${BASE_URL}/markets?limit=${limit}&status=open`, {
            next: {
                revalidate: 60
            }
        });
        if (!response.ok) {
            throw new Error("Failed to fetch markets");
        }
        const data = await response.json();
        let markets = data.markets || [];
        // Assign categories heuristically since API returns empty string
        markets = markets.map((m)=>({
                ...m,
                category: assignCategory(m)
            }));
        return markets.sort((a, b)=>b.volume - a.volume).slice(0, limit);
    } catch (error) {
        console.error("Error fetching high volume markets:", error);
        return [];
    }
}
function assignCategory(market) {
    const text = `${market.title} ${market.ticker} ${market.event_ticker}`.toLowerCase();
    if (text.includes("fed") || text.includes("inflation") || text.includes("rate") || text.includes("gdp") || text.includes("economy") || text.includes("spx") || text.includes("nasdaq") || text.includes("treasur")) return "Economics";
    if (text.includes("trump") || text.includes("biden") || text.includes("harris") || text.includes("election") || text.includes("senate") || text.includes("house") || text.includes("president") || text.includes("gov") || text.includes("cabinet")) return "Politics";
    if (text.includes("apple") || text.includes("tesla") || text.includes("ai") || text.includes("gpt") || text.includes("tech") || text.includes("musk") || text.includes("nvidia")) return "Science and Technology";
    if (text.includes("temp") || text.includes("rain") || text.includes("snow") || text.includes("hurricane") || text.includes("climate") || text.includes("weather") || text.includes("degree")) return "Climate and Weather";
    if (text.includes("bitcoin") || text.includes("btc") || text.includes("eth") || text.includes("crypto") || text.includes("solana")) return "Crypto";
    if (text.includes("movie") || text.includes("music") || text.includes("oscar") || text.includes("grammy") || text.includes("box office") || text.includes("spotify")) return "Entertainment";
    if (text.includes("football") || text.includes("nfl") || text.includes("nba") || text.includes("sport") || text.includes("game")) return "Sports";
    if (text.includes("disease") || text.includes("health") || text.includes("covid") || text.includes("vaccine")) return "Health";
    if (text.includes("financial") || text.includes("stock") || text.includes("market")) return "Financials";
    return "Other";
}
async function getMarketsBySeries(seriesTicker) {
    try {
        const response = await fetch(`${BASE_URL}/markets?series_ticker=${seriesTicker}&status=open`);
        if (!response.ok) return [];
        const data = await response.json();
        return data.markets || [];
    } catch (error) {
        console.error(`Error fetching series ${seriesTicker}:`, error);
        return [];
    }
}
async function getTagsByCategories() {
    try {
        const response = await fetch(`${BASE_URL}/search/tags_by_categories`);
        if (!response.ok) throw new Error("Failed to fetch tags");
        const data = await response.json();
        return data.tags_by_categories || {};
    } catch (error) {
        console.error("Error fetching tags:", error);
        return {
            "Economics": [
                "Interest Rates",
                "Inflation",
                "GDP"
            ],
            "Politics": [
                "Elections",
                "Policy"
            ],
            "Technology": [
                "AI",
                "Hardware"
            ],
            "Other": []
        };
    }
}
async function getSeriesByTags(tags) {
    try {
        const response = await fetch(`${BASE_URL}/series?tags=${tags}`);
        if (!response.ok) return [];
        const data = await response.json();
        return data.series || [];
    } catch (error) {
        console.error(`Error fetching series for tags ${tags}:`, error);
        return [];
    }
}
async function getSeriesByCategory(category) {
    try {
        const response = await fetch(`${BASE_URL}/series?series_category=${encodeURIComponent(category)}`);
        // Note: The documentation might say `category`, but standard Kalshi API usually uses `series_category` or just `category`. 
        // The user provided link https://docs.kalshi.com/api-reference/market/get-series-list says parameters are `series_ticker`, `series_category`, `tags`.
        // Wait, user said `/series?category=xxx`. 
        // Let's verify the user's link documentation if possible or trust the user. 
        // The user explicitly wrote `/series?category=xxx`.
        // However, standard parameter for category in many APIs is often just `category`.
        // But let's check the user provided link in my head (I can't browse).
        // Actually I can browse.
        // Let's use `category` as requested by user, but I will double check.
        // But I will stick to what the user requested `?category=`.
        // Wait, the user said "Check documentation: ...".
        // I will trust the user's specific request "pass category as query string: /series?category=xxx"
        // But I will also handle the case if it needs to be mapped.
        // Actually, let's look at `getTagsByCategories`. It uses `tags_by_categories`.
        // Let's try `category` first as user asked.
        const res = await fetch(`${BASE_URL}/series?category=${encodeURIComponent(category)}`);
        if (!res.ok) return [];
        const data = await res.json();
        return data.series || [];
    } catch (error) {
        console.error(`Error fetching series for category ${category}:`, error);
        return [];
    }
}
async function getMarketDetails(ticker) {
    try {
        const response = await fetch(`${BASE_URL}/markets/${ticker}`);
        if (!response.ok) return null;
        const data = await response.json();
        return data.market;
    } catch (error) {
        console.error(`Error fetching market ${ticker}:`, error);
        return null;
    }
}
async function getOrderBook(ticker) {
    try {
        const response = await fetch(`${BASE_URL}/markets/${ticker}/orderbook`);
        if (!response.ok) return null;
        const data = await response.json();
        return data.orderbook;
    } catch (error) {
        console.error(`Error fetching orderbook for ${ticker}:`, error);
        return null;
    }
}
;
(0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ensureServerEntryExports"])([
    getHighVolumeMarkets,
    getMarketsBySeries,
    getTagsByCategories,
    getSeriesByTags,
    getSeriesByCategory,
    getMarketDetails,
    getOrderBook
]);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getHighVolumeMarkets, "40ef9b940eb0268acbb2520b8deedf1b073fcea482", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getMarketsBySeries, "4098a2c63c1f4720d0b4167856dc1aed4865487165", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getTagsByCategories, "0080a0c14b1fc0948713b48296d412c543012fe137", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getSeriesByTags, "409071e25c2a92798fac6387e9301fdc81bce11cd4", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getSeriesByCategory, "40d340aaa5db82e6b01959616fc70453cdbbe719c3", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getMarketDetails, "407e4f66b279acc536a69b80ffb28e1e41e4ef2c4c", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getOrderBook, "40fc189a2f119b7e2eae225f04dc1e5d1345aa812d", null);
}),
"[project]/web/.next-internal/server/app/markets/page/actions.js { ACTIONS_MODULE0 => \"[project]/web/lib/kalshi.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$kalshi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/lib/kalshi.ts [app-rsc] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
}),
"[project]/web/.next-internal/server/app/markets/page/actions.js { ACTIONS_MODULE0 => \"[project]/web/lib/kalshi.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "0080a0c14b1fc0948713b48296d412c543012fe137",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$kalshi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getTagsByCategories"],
    "407e4f66b279acc536a69b80ffb28e1e41e4ef2c4c",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$kalshi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getMarketDetails"],
    "409071e25c2a92798fac6387e9301fdc81bce11cd4",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$kalshi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getSeriesByTags"],
    "4098a2c63c1f4720d0b4167856dc1aed4865487165",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$kalshi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getMarketsBySeries"],
    "40d340aaa5db82e6b01959616fc70453cdbbe719c3",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$kalshi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getSeriesByCategory"],
    "40ef9b940eb0268acbb2520b8deedf1b073fcea482",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$kalshi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getHighVolumeMarkets"],
    "40fc189a2f119b7e2eae225f04dc1e5d1345aa812d",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$kalshi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getOrderBook"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f2e$next$2d$internal$2f$server$2f$app$2f$markets$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$web$2f$lib$2f$kalshi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i('[project]/web/.next-internal/server/app/markets/page/actions.js { ACTIONS_MODULE0 => "[project]/web/lib/kalshi.ts [app-rsc] (ecmascript)" } [app-rsc] (server actions loader, ecmascript) <locals>');
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$kalshi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/lib/kalshi.ts [app-rsc] (ecmascript)");
}),
"[project]/web/node_modules/next/dist/build/webpack/loaders/next-flight-loader/server-reference.js [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/* eslint-disable import/no-extraneous-dependencies */ Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "registerServerReference", {
    enumerable: true,
    get: function() {
        return _server.registerServerReference;
    }
});
const _server = __turbopack_context__.r("[project]/web/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)"); //# sourceMappingURL=server-reference.js.map
}),
"[project]/web/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-validate.js [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// This function ensures that all the exported values are valid server actions,
// during the runtime. By definition all actions are required to be async
// functions, but here we can only check that they are functions.
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "ensureServerEntryExports", {
    enumerable: true,
    get: function() {
        return ensureServerEntryExports;
    }
});
function ensureServerEntryExports(actions) {
    for(let i = 0; i < actions.length; i++){
        const action = actions[i];
        if (typeof action !== 'function') {
            throw Object.defineProperty(new Error(`A "use server" file can only export async functions, found ${typeof action}.\nRead more: https://nextjs.org/docs/messages/invalid-use-server-value`), "__NEXT_ERROR_CODE", {
                value: "E352",
                enumerable: false,
                configurable: true
            });
        }
    }
} //# sourceMappingURL=action-validate.js.map
}),
];

//# sourceMappingURL=web_56985c09._.js.map