module.exports = [
"[project]/kalshi-signals-web/.next-internal/server/app/trade/[ticker]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=6498f__next-internal_server_app_trade_%5Bticker%5D_page_actions_1850a393.js.map