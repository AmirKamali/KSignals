module.exports = [
"[project]/kalshi-signals-web/lib/kalshi.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"001314b8fdc73e67a1867a7b5dacf9a9ebfd97e924":"getTagsByCategories","400e9e9d0b036b34276838395dfc77d4a0d27b7d20":"getOrderBook","4091deecffc8ac7da64e02e0b5fb96b5f8a77a5992":"getMarketDetails","40bade4a66d91bece7637799db0b4d63acd2f965f9":"getSeriesByTags","40bfac25541646720c858bcc329fd2c9437ae8900d":"getMarketsBySeries","40e67d54836c2066402bfebb98f0c73766126b4147":"getHighVolumeMarkets"},"",""] */ __turbopack_context__.s([
    "getHighVolumeMarkets",
    ()=>getHighVolumeMarkets,
    "getMarketDetails",
    ()=>getMarketDetails,
    "getMarketsBySeries",
    ()=>getMarketsBySeries,
    "getOrderBook",
    ()=>getOrderBook,
    "getSeriesByTags",
    ()=>getSeriesByTags,
    "getTagsByCategories",
    ()=>getTagsByCategories
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$kalshi$2d$signals$2d$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kalshi-signals-web/node_modules/next/dist/build/webpack/loaders/next-flight-loader/server-reference.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$kalshi$2d$signals$2d$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kalshi-signals-web/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-validate.js [app-rsc] (ecmascript)");
;
const BASE_URL = "https://api.elections.kalshi.com/trade-api/v2";
async function getHighVolumeMarkets(limit = 100) {
    try {
        const response = await fetch(`${BASE_URL}/markets?limit=${limit}&status=open`, {
            next: {
                revalidate: 60
            }
        });
        if (!response.ok) {
            throw new Error("Failed to fetch markets");
        }
        const data = await response.json();
        let markets = data.markets || [];
        // Assign categories heuristically since API returns empty string
        markets = markets.map((m)=>({
                ...m,
                category: assignCategory(m)
            }));
        return markets.sort((a, b)=>b.volume - a.volume).slice(0, limit);
    } catch (error) {
        console.error("Error fetching high volume markets:", error);
        return [];
    }
}
function assignCategory(market) {
    const text = `${market.title} ${market.ticker} ${market.event_ticker}`.toLowerCase();
    if (text.includes("fed") || text.includes("inflation") || text.includes("rate") || text.includes("gdp") || text.includes("economy") || text.includes("spx") || text.includes("nasdaq") || text.includes("treasur")) return "Economics";
    if (text.includes("trump") || text.includes("biden") || text.includes("harris") || text.includes("election") || text.includes("senate") || text.includes("house") || text.includes("president") || text.includes("gov") || text.includes("cabinet")) return "Politics";
    if (text.includes("apple") || text.includes("tesla") || text.includes("ai") || text.includes("gpt") || text.includes("tech") || text.includes("musk") || text.includes("nvidia")) return "Science and Technology";
    if (text.includes("temp") || text.includes("rain") || text.includes("snow") || text.includes("hurricane") || text.includes("climate") || text.includes("weather") || text.includes("degree")) return "Climate and Weather";
    if (text.includes("bitcoin") || text.includes("btc") || text.includes("eth") || text.includes("crypto") || text.includes("solana")) return "Crypto";
    if (text.includes("movie") || text.includes("music") || text.includes("oscar") || text.includes("grammy") || text.includes("box office") || text.includes("spotify")) return "Entertainment";
    if (text.includes("football") || text.includes("nfl") || text.includes("nba") || text.includes("sport") || text.includes("game")) return "Sports";
    if (text.includes("disease") || text.includes("health") || text.includes("covid") || text.includes("vaccine")) return "Health";
    if (text.includes("financial") || text.includes("stock") || text.includes("market")) return "Financials";
    return "Other";
}
async function getMarketsBySeries(seriesTicker) {
    try {
        const response = await fetch(`${BASE_URL}/markets?series_ticker=${seriesTicker}&status=open`);
        if (!response.ok) return [];
        const data = await response.json();
        return data.markets || [];
    } catch (error) {
        console.error(`Error fetching series ${seriesTicker}:`, error);
        return [];
    }
}
async function getTagsByCategories() {
    try {
        const response = await fetch(`${BASE_URL}/search/tags_by_categories`);
        if (!response.ok) throw new Error("Failed to fetch tags");
        const data = await response.json();
        return data.tags_by_categories || {};
    } catch (error) {
        console.error("Error fetching tags:", error);
        return {
            "Economics": [
                "Interest Rates",
                "Inflation",
                "GDP"
            ],
            "Politics": [
                "Elections",
                "Policy"
            ],
            "Technology": [
                "AI",
                "Hardware"
            ],
            "Other": []
        };
    }
}
async function getSeriesByTags(tags) {
    try {
        const response = await fetch(`${BASE_URL}/series?tags=${tags}`);
        if (!response.ok) return [];
        const data = await response.json();
        return data.series || [];
    } catch (error) {
        console.error(`Error fetching series for tags ${tags}:`, error);
        return [];
    }
}
async function getMarketDetails(ticker) {
    try {
        const response = await fetch(`${BASE_URL}/markets/${ticker}`);
        if (!response.ok) return null;
        const data = await response.json();
        return data.market;
    } catch (error) {
        console.error(`Error fetching market ${ticker}:`, error);
        return null;
    }
}
async function getOrderBook(ticker) {
    try {
        const response = await fetch(`${BASE_URL}/markets/${ticker}/orderbook`);
        if (!response.ok) return null;
        const data = await response.json();
        return data.orderbook;
    } catch (error) {
        console.error(`Error fetching orderbook for ${ticker}:`, error);
        return null;
    }
}
;
(0, __TURBOPACK__imported__module__$5b$project$5d2f$kalshi$2d$signals$2d$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ensureServerEntryExports"])([
    getHighVolumeMarkets,
    getMarketsBySeries,
    getTagsByCategories,
    getSeriesByTags,
    getMarketDetails,
    getOrderBook
]);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$kalshi$2d$signals$2d$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getHighVolumeMarkets, "40e67d54836c2066402bfebb98f0c73766126b4147", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$kalshi$2d$signals$2d$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getMarketsBySeries, "40bfac25541646720c858bcc329fd2c9437ae8900d", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$kalshi$2d$signals$2d$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getTagsByCategories, "001314b8fdc73e67a1867a7b5dacf9a9ebfd97e924", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$kalshi$2d$signals$2d$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getSeriesByTags, "40bade4a66d91bece7637799db0b4d63acd2f965f9", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$kalshi$2d$signals$2d$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getMarketDetails, "4091deecffc8ac7da64e02e0b5fb96b5f8a77a5992", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$kalshi$2d$signals$2d$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getOrderBook, "400e9e9d0b036b34276838395dfc77d4a0d27b7d20", null);
}),
"[project]/kalshi-signals-web/.next-internal/server/app/page/actions.js { ACTIONS_MODULE0 => \"[project]/kalshi-signals-web/lib/kalshi.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$kalshi$2d$signals$2d$web$2f$lib$2f$kalshi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kalshi-signals-web/lib/kalshi.ts [app-rsc] (ecmascript)");
;
;
;
;
;
;
;
;
}),
"[project]/kalshi-signals-web/.next-internal/server/app/page/actions.js { ACTIONS_MODULE0 => \"[project]/kalshi-signals-web/lib/kalshi.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "001314b8fdc73e67a1867a7b5dacf9a9ebfd97e924",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$kalshi$2d$signals$2d$web$2f$lib$2f$kalshi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getTagsByCategories"],
    "400e9e9d0b036b34276838395dfc77d4a0d27b7d20",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$kalshi$2d$signals$2d$web$2f$lib$2f$kalshi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getOrderBook"],
    "4091deecffc8ac7da64e02e0b5fb96b5f8a77a5992",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$kalshi$2d$signals$2d$web$2f$lib$2f$kalshi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getMarketDetails"],
    "40bade4a66d91bece7637799db0b4d63acd2f965f9",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$kalshi$2d$signals$2d$web$2f$lib$2f$kalshi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getSeriesByTags"],
    "40bfac25541646720c858bcc329fd2c9437ae8900d",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$kalshi$2d$signals$2d$web$2f$lib$2f$kalshi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getMarketsBySeries"],
    "40e67d54836c2066402bfebb98f0c73766126b4147",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$kalshi$2d$signals$2d$web$2f$lib$2f$kalshi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getHighVolumeMarkets"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$kalshi$2d$signals$2d$web$2f2e$next$2d$internal$2f$server$2f$app$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$kalshi$2d$signals$2d$web$2f$lib$2f$kalshi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i('[project]/kalshi-signals-web/.next-internal/server/app/page/actions.js { ACTIONS_MODULE0 => "[project]/kalshi-signals-web/lib/kalshi.ts [app-rsc] (ecmascript)" } [app-rsc] (server actions loader, ecmascript) <locals>');
var __TURBOPACK__imported__module__$5b$project$5d2f$kalshi$2d$signals$2d$web$2f$lib$2f$kalshi$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/kalshi-signals-web/lib/kalshi.ts [app-rsc] (ecmascript)");
}),
"[project]/kalshi-signals-web/node_modules/next/dist/build/webpack/loaders/next-flight-loader/server-reference.js [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/* eslint-disable import/no-extraneous-dependencies */ Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "registerServerReference", {
    enumerable: true,
    get: function() {
        return _server.registerServerReference;
    }
});
const _server = __turbopack_context__.r("[project]/kalshi-signals-web/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)"); //# sourceMappingURL=server-reference.js.map
}),
"[project]/kalshi-signals-web/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-validate.js [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// This function ensures that all the exported values are valid server actions,
// during the runtime. By definition all actions are required to be async
// functions, but here we can only check that they are functions.
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "ensureServerEntryExports", {
    enumerable: true,
    get: function() {
        return ensureServerEntryExports;
    }
});
function ensureServerEntryExports(actions) {
    for(let i = 0; i < actions.length; i++){
        const action = actions[i];
        if (typeof action !== 'function') {
            throw Object.defineProperty(new Error(`A "use server" file can only export async functions, found ${typeof action}.\nRead more: https://nextjs.org/docs/messages/invalid-use-server-value`), "__NEXT_ERROR_CODE", {
                value: "E352",
                enumerable: false,
                configurable: true
            });
        }
    }
} //# sourceMappingURL=action-validate.js.map
}),
];

//# sourceMappingURL=kalshi-signals-web_10fb4bb8._.js.map