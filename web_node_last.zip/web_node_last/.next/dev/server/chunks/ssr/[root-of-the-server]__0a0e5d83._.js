module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[project]/web/components/HeroSection.module.css [app-ssr] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "actions": "HeroSection-module__suLlPW__actions",
  "badge": "HeroSection-module__suLlPW__badge",
  "badgeDot": "HeroSection-module__suLlPW__badgeDot",
  "content": "HeroSection-module__suLlPW__content",
  "controls": "HeroSection-module__suLlPW__controls",
  "dot": "HeroSection-module__suLlPW__dot",
  "dotActive": "HeroSection-module__suLlPW__dotActive",
  "glow": "HeroSection-module__suLlPW__glow",
  "hero": "HeroSection-module__suLlPW__hero",
  "pulse": "HeroSection-module__suLlPW__pulse",
  "slide": "HeroSection-module__suLlPW__slide",
  "sliderContainer": "HeroSection-module__suLlPW__sliderContainer",
  "subtitle": "HeroSection-module__suLlPW__subtitle",
  "title": "HeroSection-module__suLlPW__title",
});
}),
"[project]/web/components/HeroSection.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HeroSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__ = __turbopack_context__.i("[project]/web/node_modules/lucide-react/dist/esm/icons/arrow-right.js [app-ssr] (ecmascript) <export default as ArrowRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trending$2d$up$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__TrendingUp$3e$__ = __turbopack_context__.i("[project]/web/node_modules/lucide-react/dist/esm/icons/trending-up.js [app-ssr] (ecmascript) <export default as TrendingUp>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2d$check$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ShieldCheck$3e$__ = __turbopack_context__.i("[project]/web/node_modules/lucide-react/dist/esm/icons/shield-check.js [app-ssr] (ecmascript) <export default as ShieldCheck>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$zap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Zap$3e$__ = __turbopack_context__.i("[project]/web/node_modules/lucide-react/dist/esm/icons/zap.js [app-ssr] (ecmascript) <export default as Zap>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/web/components/HeroSection.module.css [app-ssr] (css module)");
"use client";
;
;
;
;
const SLIDES = [
    {
        title: "Trade on Real World Events",
        subtitle: "The first regulated exchange for trading on event outcomes.",
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trending$2d$up$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__TrendingUp$3e$__["TrendingUp"], {
            size: 32
        }, void 0, false, {
            fileName: "[project]/web/components/HeroSection.tsx",
            lineNumber: 11,
            columnNumber: 15
        }, ("TURBOPACK compile-time value", void 0)),
        color: "var(--primary)"
    },
    {
        title: "Data-Driven Signals",
        subtitle: "Get AI-powered insights and probability analysis for every trade.",
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$zap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Zap$3e$__["Zap"], {
            size: 32
        }, void 0, false, {
            fileName: "[project]/web/components/HeroSection.tsx",
            lineNumber: 17,
            columnNumber: 15
        }, ("TURBOPACK compile-time value", void 0)),
        color: "var(--accent)"
    },
    {
        title: "Regulated & Secure",
        subtitle: "Trade with confidence on a CFTC-regulated exchange.",
        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2d$check$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ShieldCheck$3e$__["ShieldCheck"], {
            size: 32
        }, void 0, false, {
            fileName: "[project]/web/components/HeroSection.tsx",
            lineNumber: 23,
            columnNumber: 15
        }, ("TURBOPACK compile-time value", void 0)),
        color: "var(--success)"
    }
];
function HeroSection() {
    const [currentSlide, setCurrentSlide] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const timer = setInterval(()=>{
            setCurrentSlide((prev)=>(prev + 1) % SLIDES.length);
        }, 5000);
        return ()=>clearInterval(timer);
    }, []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].hero,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].glow
            }, void 0, false, {
                fileName: "[project]/web/components/HeroSection.tsx",
                lineNumber: 40,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].content,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].badge,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].badgeDot
                                }, void 0, false, {
                                    fileName: "[project]/web/components/HeroSection.tsx",
                                    lineNumber: 44,
                                    columnNumber: 25
                                }, this),
                                "Live Market Signals"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/web/components/HeroSection.tsx",
                            lineNumber: 43,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].sliderContainer,
                            children: SLIDES.map((slide, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].slide} ${index === currentSlide ? __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].active : ""}`,
                                    style: {
                                        opacity: index === currentSlide ? 1 : 0
                                    },
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].title,
                                            children: slide.title.split(" ").map((word, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: i === 1 ? "text-gradient" : "",
                                                    children: [
                                                        word,
                                                        " "
                                                    ]
                                                }, i, true, {
                                                    fileName: "[project]/web/components/HeroSection.tsx",
                                                    lineNumber: 57,
                                                    columnNumber: 41
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/web/components/HeroSection.tsx",
                                            lineNumber: 55,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].subtitle,
                                            children: slide.subtitle
                                        }, void 0, false, {
                                            fileName: "[project]/web/components/HeroSection.tsx",
                                            lineNumber: 62,
                                            columnNumber: 33
                                        }, this)
                                    ]
                                }, index, true, {
                                    fileName: "[project]/web/components/HeroSection.tsx",
                                    lineNumber: 50,
                                    columnNumber: 29
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/web/components/HeroSection.tsx",
                            lineNumber: 48,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].controls,
                            children: SLIDES.map((_, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].dot} ${index === currentSlide ? __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].dotActive : ""}`,
                                    onClick: ()=>setCurrentSlide(index),
                                    "aria-label": `Go to slide ${index + 1}`
                                }, index, false, {
                                    fileName: "[project]/web/components/HeroSection.tsx",
                                    lineNumber: 69,
                                    columnNumber: 29
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/web/components/HeroSection.tsx",
                            lineNumber: 67,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].actions,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: "btn btn-primary",
                                    children: [
                                        "Start Trading ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                            size: 18,
                                            style: {
                                                marginLeft: "0.5rem"
                                            }
                                        }, void 0, false, {
                                            fileName: "[project]/web/components/HeroSection.tsx",
                                            lineNumber: 80,
                                            columnNumber: 43
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/web/components/HeroSection.tsx",
                                    lineNumber: 79,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: "btn btn-outline",
                                    children: "View Markets"
                                }, void 0, false, {
                                    fileName: "[project]/web/components/HeroSection.tsx",
                                    lineNumber: 82,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/web/components/HeroSection.tsx",
                            lineNumber: 78,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/web/components/HeroSection.tsx",
                    lineNumber: 42,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/web/components/HeroSection.tsx",
                lineNumber: 41,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/web/components/HeroSection.tsx",
        lineNumber: 39,
        columnNumber: 9
    }, this);
}
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[project]/web/lib/data:d036f2 [app-ssr] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"409071e25c2a92798fac6387e9301fdc81bce11cd4":"getSeriesByTags"},"web/lib/kalshi.ts",""] */ __turbopack_context__.s([
    "getSeriesByTags",
    ()=>getSeriesByTags
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
var getSeriesByTags = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("409071e25c2a92798fac6387e9301fdc81bce11cd4", __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "getSeriesByTags"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4va2Fsc2hpLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIHNlcnZlclwiO1xuXG5jb25zdCBCQVNFX1VSTCA9IFwiaHR0cHM6Ly9hcGkuZWxlY3Rpb25zLmthbHNoaS5jb20vdHJhZGUtYXBpL3YyXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgTWFya2V0IHtcbiAgICB0aWNrZXI6IHN0cmluZztcbiAgICBldmVudF90aWNrZXI6IHN0cmluZztcbiAgICB0aXRsZTogc3RyaW5nO1xuICAgIHN1YnRpdGxlPzogc3RyaW5nO1xuICAgIHllc19wcmljZTogbnVtYmVyO1xuICAgIHZvbHVtZTogbnVtYmVyO1xuICAgIG9wZW5faW50ZXJlc3Q6IG51bWJlcjtcbiAgICBsaXF1aWRpdHk6IG51bWJlcjtcbiAgICBzdGF0dXM6IHN0cmluZztcbiAgICBjYXRlZ29yeT86IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBNYXJrZXREZXRhaWwgZXh0ZW5kcyBNYXJrZXQge1xuICAgIGNhdGVnb3J5OiBzdHJpbmc7IC8vIE92ZXJyaWRlIGFzIHJlcXVpcmVkIGZvciBkZXRhaWxzXG4gICAgZXhwaXJhdGlvbl90aW1lOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgT3JkZXJCb29rIHtcbiAgICB5ZXM6IFtudW1iZXIsIG51bWJlcl1bXTtcbiAgICBubzogW251bWJlciwgbnVtYmVyXVtdO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFNlcmllcyB7XG4gICAgdGlja2VyOiBzdHJpbmc7XG4gICAgZnJlcXVlbmN5OiBzdHJpbmc7XG4gICAgdGl0bGU6IHN0cmluZztcbiAgICBjYXRlZ29yeTogc3RyaW5nO1xuICAgIHRhZ3M6IHN0cmluZ1tdO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0SGlnaFZvbHVtZU1hcmtldHMobGltaXQgPSAxMDApOiBQcm9taXNlPE1hcmtldFtdPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vbWFya2V0cz9saW1pdD0ke2xpbWl0fSZzdGF0dXM9b3BlbmAsIHtcbiAgICAgICAgICAgIG5leHQ6IHsgcmV2YWxpZGF0ZTogNjAgfSxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIGZldGNoIG1hcmtldHNcIik7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICBsZXQgbWFya2V0czogTWFya2V0W10gPSBkYXRhLm1hcmtldHMgfHwgW107XG5cbiAgICAgICAgLy8gQXNzaWduIGNhdGVnb3JpZXMgaGV1cmlzdGljYWxseSBzaW5jZSBBUEkgcmV0dXJucyBlbXB0eSBzdHJpbmdcbiAgICAgICAgbWFya2V0cyA9IG1hcmtldHMubWFwKG0gPT4gKHtcbiAgICAgICAgICAgIC4uLm0sXG4gICAgICAgICAgICBjYXRlZ29yeTogYXNzaWduQ2F0ZWdvcnkobSlcbiAgICAgICAgfSkpO1xuXG4gICAgICAgIHJldHVybiBtYXJrZXRzXG4gICAgICAgICAgICAuc29ydCgoYSwgYikgPT4gYi52b2x1bWUgLSBhLnZvbHVtZSlcbiAgICAgICAgICAgIC5zbGljZSgwLCBsaW1pdCk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGhpZ2ggdm9sdW1lIG1hcmtldHM6XCIsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbn1cblxuZnVuY3Rpb24gYXNzaWduQ2F0ZWdvcnkobWFya2V0OiBNYXJrZXQpOiBzdHJpbmcge1xuICAgIGNvbnN0IHRleHQgPSBgJHttYXJrZXQudGl0bGV9ICR7bWFya2V0LnRpY2tlcn0gJHttYXJrZXQuZXZlbnRfdGlja2VyfWAudG9Mb3dlckNhc2UoKTtcblxuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiZmVkXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJpbmZsYXRpb25cIikgfHwgdGV4dC5pbmNsdWRlcyhcInJhdGVcIikgfHwgdGV4dC5pbmNsdWRlcyhcImdkcFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZWNvbm9teVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwic3B4XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJuYXNkYXFcIikgfHwgdGV4dC5pbmNsdWRlcyhcInRyZWFzdXJcIikpIHJldHVybiBcIkVjb25vbWljc1wiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwidHJ1bXBcIikgfHwgdGV4dC5pbmNsdWRlcyhcImJpZGVuXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJoYXJyaXNcIikgfHwgdGV4dC5pbmNsdWRlcyhcImVsZWN0aW9uXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzZW5hdGVcIikgfHwgdGV4dC5pbmNsdWRlcyhcImhvdXNlXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJwcmVzaWRlbnRcIikgfHwgdGV4dC5pbmNsdWRlcyhcImdvdlwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiY2FiaW5ldFwiKSkgcmV0dXJuIFwiUG9saXRpY3NcIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcImFwcGxlXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJ0ZXNsYVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiYWlcIikgfHwgdGV4dC5pbmNsdWRlcyhcImdwdFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwidGVjaFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibXVza1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibnZpZGlhXCIpKSByZXR1cm4gXCJTY2llbmNlIGFuZCBUZWNobm9sb2d5XCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJ0ZW1wXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJyYWluXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzbm93XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJodXJyaWNhbmVcIikgfHwgdGV4dC5pbmNsdWRlcyhcImNsaW1hdGVcIikgfHwgdGV4dC5pbmNsdWRlcyhcIndlYXRoZXJcIikgfHwgdGV4dC5pbmNsdWRlcyhcImRlZ3JlZVwiKSkgcmV0dXJuIFwiQ2xpbWF0ZSBhbmQgV2VhdGhlclwiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiYml0Y29pblwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiYnRjXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJldGhcIikgfHwgdGV4dC5pbmNsdWRlcyhcImNyeXB0b1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwic29sYW5hXCIpKSByZXR1cm4gXCJDcnlwdG9cIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcIm1vdmllXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJtdXNpY1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwib3NjYXJcIikgfHwgdGV4dC5pbmNsdWRlcyhcImdyYW1teVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiYm94IG9mZmljZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwic3BvdGlmeVwiKSkgcmV0dXJuIFwiRW50ZXJ0YWlubWVudFwiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiZm9vdGJhbGxcIikgfHwgdGV4dC5pbmNsdWRlcyhcIm5mbFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibmJhXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzcG9ydFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ2FtZVwiKSkgcmV0dXJuIFwiU3BvcnRzXCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJkaXNlYXNlXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJoZWFsdGhcIikgfHwgdGV4dC5pbmNsdWRlcyhcImNvdmlkXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJ2YWNjaW5lXCIpKSByZXR1cm4gXCJIZWFsdGhcIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcImZpbmFuY2lhbFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwic3RvY2tcIikgfHwgdGV4dC5pbmNsdWRlcyhcIm1hcmtldFwiKSkgcmV0dXJuIFwiRmluYW5jaWFsc1wiO1xuXG4gICAgcmV0dXJuIFwiT3RoZXJcIjtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE1hcmtldHNCeVNlcmllcyhzZXJpZXNUaWNrZXI6IHN0cmluZyk6IFByb21pc2U8TWFya2V0W10+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfS9tYXJrZXRzP3Nlcmllc190aWNrZXI9JHtzZXJpZXNUaWNrZXJ9JnN0YXR1cz1vcGVuYCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHJldHVybiBbXTtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIGRhdGEubWFya2V0cyB8fCBbXTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBmZXRjaGluZyBzZXJpZXMgJHtzZXJpZXNUaWNrZXJ9OmAsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFRhZ3NCeUNhdGVnb3JpZXMoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfS9zZWFyY2gvdGFnc19ieV9jYXRlZ29yaWVzYCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byBmZXRjaCB0YWdzXCIpO1xuXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIHJldHVybiBkYXRhLnRhZ3NfYnlfY2F0ZWdvcmllcyB8fCB7fTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdGFnczpcIiwgZXJyb3IpO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgXCJFY29ub21pY3NcIjogW1wiSW50ZXJlc3QgUmF0ZXNcIiwgXCJJbmZsYXRpb25cIiwgXCJHRFBcIl0sXG4gICAgICAgICAgICBcIlBvbGl0aWNzXCI6IFtcIkVsZWN0aW9uc1wiLCBcIlBvbGljeVwiXSxcbiAgICAgICAgICAgIFwiVGVjaG5vbG9neVwiOiBbXCJBSVwiLCBcIkhhcmR3YXJlXCJdLFxuICAgICAgICAgICAgXCJPdGhlclwiOiBbXVxuICAgICAgICB9O1xuICAgIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNlcmllc0J5VGFncyh0YWdzOiBzdHJpbmcpOiBQcm9taXNlPFNlcmllc1tdPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vc2VyaWVzP3RhZ3M9JHt0YWdzfWApO1xuICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSByZXR1cm4gW107XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIHJldHVybiBkYXRhLnNlcmllcyB8fCBbXTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBmZXRjaGluZyBzZXJpZXMgZm9yIHRhZ3MgJHt0YWdzfTpgLCBlcnJvcik7XG4gICAgICAgIHJldHVybiBbXTtcbiAgICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRNYXJrZXREZXRhaWxzKHRpY2tlcjogc3RyaW5nKTogUHJvbWlzZTxNYXJrZXREZXRhaWwgfCBudWxsPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vbWFya2V0cy8ke3RpY2tlcn1gKTtcbiAgICAgICAgaWYgKCFyZXNwb25zZS5vaykgcmV0dXJuIG51bGw7XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIHJldHVybiBkYXRhLm1hcmtldDtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBmZXRjaGluZyBtYXJrZXQgJHt0aWNrZXJ9OmAsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0T3JkZXJCb29rKHRpY2tlcjogc3RyaW5nKTogUHJvbWlzZTxPcmRlckJvb2sgfCBudWxsPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vbWFya2V0cy8ke3RpY2tlcn0vb3JkZXJib29rYCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHJldHVybiBudWxsO1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICByZXR1cm4gZGF0YS5vcmRlcmJvb2s7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgZmV0Y2hpbmcgb3JkZXJib29rIGZvciAke3RpY2tlcn06YCwgZXJyb3IpO1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG59XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjBSQTZHc0IifQ==
}),
"[project]/web/lib/data:a67302 [app-ssr] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"4098a2c63c1f4720d0b4167856dc1aed4865487165":"getMarketsBySeries"},"web/lib/kalshi.ts",""] */ __turbopack_context__.s([
    "getMarketsBySeries",
    ()=>getMarketsBySeries
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
var getMarketsBySeries = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("4098a2c63c1f4720d0b4167856dc1aed4865487165", __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "getMarketsBySeries"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4va2Fsc2hpLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIHNlcnZlclwiO1xuXG5jb25zdCBCQVNFX1VSTCA9IFwiaHR0cHM6Ly9hcGkuZWxlY3Rpb25zLmthbHNoaS5jb20vdHJhZGUtYXBpL3YyXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgTWFya2V0IHtcbiAgICB0aWNrZXI6IHN0cmluZztcbiAgICBldmVudF90aWNrZXI6IHN0cmluZztcbiAgICB0aXRsZTogc3RyaW5nO1xuICAgIHN1YnRpdGxlPzogc3RyaW5nO1xuICAgIHllc19wcmljZTogbnVtYmVyO1xuICAgIHZvbHVtZTogbnVtYmVyO1xuICAgIG9wZW5faW50ZXJlc3Q6IG51bWJlcjtcbiAgICBsaXF1aWRpdHk6IG51bWJlcjtcbiAgICBzdGF0dXM6IHN0cmluZztcbiAgICBjYXRlZ29yeT86IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBNYXJrZXREZXRhaWwgZXh0ZW5kcyBNYXJrZXQge1xuICAgIGNhdGVnb3J5OiBzdHJpbmc7IC8vIE92ZXJyaWRlIGFzIHJlcXVpcmVkIGZvciBkZXRhaWxzXG4gICAgZXhwaXJhdGlvbl90aW1lOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgT3JkZXJCb29rIHtcbiAgICB5ZXM6IFtudW1iZXIsIG51bWJlcl1bXTtcbiAgICBubzogW251bWJlciwgbnVtYmVyXVtdO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFNlcmllcyB7XG4gICAgdGlja2VyOiBzdHJpbmc7XG4gICAgZnJlcXVlbmN5OiBzdHJpbmc7XG4gICAgdGl0bGU6IHN0cmluZztcbiAgICBjYXRlZ29yeTogc3RyaW5nO1xuICAgIHRhZ3M6IHN0cmluZ1tdO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0SGlnaFZvbHVtZU1hcmtldHMobGltaXQgPSAxMDApOiBQcm9taXNlPE1hcmtldFtdPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vbWFya2V0cz9saW1pdD0ke2xpbWl0fSZzdGF0dXM9b3BlbmAsIHtcbiAgICAgICAgICAgIG5leHQ6IHsgcmV2YWxpZGF0ZTogNjAgfSxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIGZldGNoIG1hcmtldHNcIik7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICBsZXQgbWFya2V0czogTWFya2V0W10gPSBkYXRhLm1hcmtldHMgfHwgW107XG5cbiAgICAgICAgLy8gQXNzaWduIGNhdGVnb3JpZXMgaGV1cmlzdGljYWxseSBzaW5jZSBBUEkgcmV0dXJucyBlbXB0eSBzdHJpbmdcbiAgICAgICAgbWFya2V0cyA9IG1hcmtldHMubWFwKG0gPT4gKHtcbiAgICAgICAgICAgIC4uLm0sXG4gICAgICAgICAgICBjYXRlZ29yeTogYXNzaWduQ2F0ZWdvcnkobSlcbiAgICAgICAgfSkpO1xuXG4gICAgICAgIHJldHVybiBtYXJrZXRzXG4gICAgICAgICAgICAuc29ydCgoYSwgYikgPT4gYi52b2x1bWUgLSBhLnZvbHVtZSlcbiAgICAgICAgICAgIC5zbGljZSgwLCBsaW1pdCk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGhpZ2ggdm9sdW1lIG1hcmtldHM6XCIsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbn1cblxuZnVuY3Rpb24gYXNzaWduQ2F0ZWdvcnkobWFya2V0OiBNYXJrZXQpOiBzdHJpbmcge1xuICAgIGNvbnN0IHRleHQgPSBgJHttYXJrZXQudGl0bGV9ICR7bWFya2V0LnRpY2tlcn0gJHttYXJrZXQuZXZlbnRfdGlja2VyfWAudG9Mb3dlckNhc2UoKTtcblxuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiZmVkXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJpbmZsYXRpb25cIikgfHwgdGV4dC5pbmNsdWRlcyhcInJhdGVcIikgfHwgdGV4dC5pbmNsdWRlcyhcImdkcFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZWNvbm9teVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwic3B4XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJuYXNkYXFcIikgfHwgdGV4dC5pbmNsdWRlcyhcInRyZWFzdXJcIikpIHJldHVybiBcIkVjb25vbWljc1wiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwidHJ1bXBcIikgfHwgdGV4dC5pbmNsdWRlcyhcImJpZGVuXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJoYXJyaXNcIikgfHwgdGV4dC5pbmNsdWRlcyhcImVsZWN0aW9uXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzZW5hdGVcIikgfHwgdGV4dC5pbmNsdWRlcyhcImhvdXNlXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJwcmVzaWRlbnRcIikgfHwgdGV4dC5pbmNsdWRlcyhcImdvdlwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiY2FiaW5ldFwiKSkgcmV0dXJuIFwiUG9saXRpY3NcIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcImFwcGxlXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJ0ZXNsYVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiYWlcIikgfHwgdGV4dC5pbmNsdWRlcyhcImdwdFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwidGVjaFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibXVza1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibnZpZGlhXCIpKSByZXR1cm4gXCJTY2llbmNlIGFuZCBUZWNobm9sb2d5XCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJ0ZW1wXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJyYWluXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzbm93XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJodXJyaWNhbmVcIikgfHwgdGV4dC5pbmNsdWRlcyhcImNsaW1hdGVcIikgfHwgdGV4dC5pbmNsdWRlcyhcIndlYXRoZXJcIikgfHwgdGV4dC5pbmNsdWRlcyhcImRlZ3JlZVwiKSkgcmV0dXJuIFwiQ2xpbWF0ZSBhbmQgV2VhdGhlclwiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiYml0Y29pblwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiYnRjXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJldGhcIikgfHwgdGV4dC5pbmNsdWRlcyhcImNyeXB0b1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwic29sYW5hXCIpKSByZXR1cm4gXCJDcnlwdG9cIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcIm1vdmllXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJtdXNpY1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwib3NjYXJcIikgfHwgdGV4dC5pbmNsdWRlcyhcImdyYW1teVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiYm94IG9mZmljZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwic3BvdGlmeVwiKSkgcmV0dXJuIFwiRW50ZXJ0YWlubWVudFwiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiZm9vdGJhbGxcIikgfHwgdGV4dC5pbmNsdWRlcyhcIm5mbFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibmJhXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzcG9ydFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ2FtZVwiKSkgcmV0dXJuIFwiU3BvcnRzXCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJkaXNlYXNlXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJoZWFsdGhcIikgfHwgdGV4dC5pbmNsdWRlcyhcImNvdmlkXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJ2YWNjaW5lXCIpKSByZXR1cm4gXCJIZWFsdGhcIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcImZpbmFuY2lhbFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwic3RvY2tcIikgfHwgdGV4dC5pbmNsdWRlcyhcIm1hcmtldFwiKSkgcmV0dXJuIFwiRmluYW5jaWFsc1wiO1xuXG4gICAgcmV0dXJuIFwiT3RoZXJcIjtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE1hcmtldHNCeVNlcmllcyhzZXJpZXNUaWNrZXI6IHN0cmluZyk6IFByb21pc2U8TWFya2V0W10+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfS9tYXJrZXRzP3Nlcmllc190aWNrZXI9JHtzZXJpZXNUaWNrZXJ9JnN0YXR1cz1vcGVuYCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHJldHVybiBbXTtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIGRhdGEubWFya2V0cyB8fCBbXTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBmZXRjaGluZyBzZXJpZXMgJHtzZXJpZXNUaWNrZXJ9OmAsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFRhZ3NCeUNhdGVnb3JpZXMoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfS9zZWFyY2gvdGFnc19ieV9jYXRlZ29yaWVzYCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byBmZXRjaCB0YWdzXCIpO1xuXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIHJldHVybiBkYXRhLnRhZ3NfYnlfY2F0ZWdvcmllcyB8fCB7fTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdGFnczpcIiwgZXJyb3IpO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgXCJFY29ub21pY3NcIjogW1wiSW50ZXJlc3QgUmF0ZXNcIiwgXCJJbmZsYXRpb25cIiwgXCJHRFBcIl0sXG4gICAgICAgICAgICBcIlBvbGl0aWNzXCI6IFtcIkVsZWN0aW9uc1wiLCBcIlBvbGljeVwiXSxcbiAgICAgICAgICAgIFwiVGVjaG5vbG9neVwiOiBbXCJBSVwiLCBcIkhhcmR3YXJlXCJdLFxuICAgICAgICAgICAgXCJPdGhlclwiOiBbXVxuICAgICAgICB9O1xuICAgIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNlcmllc0J5VGFncyh0YWdzOiBzdHJpbmcpOiBQcm9taXNlPFNlcmllc1tdPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vc2VyaWVzP3RhZ3M9JHt0YWdzfWApO1xuICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSByZXR1cm4gW107XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIHJldHVybiBkYXRhLnNlcmllcyB8fCBbXTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBmZXRjaGluZyBzZXJpZXMgZm9yIHRhZ3MgJHt0YWdzfTpgLCBlcnJvcik7XG4gICAgICAgIHJldHVybiBbXTtcbiAgICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRNYXJrZXREZXRhaWxzKHRpY2tlcjogc3RyaW5nKTogUHJvbWlzZTxNYXJrZXREZXRhaWwgfCBudWxsPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vbWFya2V0cy8ke3RpY2tlcn1gKTtcbiAgICAgICAgaWYgKCFyZXNwb25zZS5vaykgcmV0dXJuIG51bGw7XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIHJldHVybiBkYXRhLm1hcmtldDtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBmZXRjaGluZyBtYXJrZXQgJHt0aWNrZXJ9OmAsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0T3JkZXJCb29rKHRpY2tlcjogc3RyaW5nKTogUHJvbWlzZTxPcmRlckJvb2sgfCBudWxsPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vbWFya2V0cy8ke3RpY2tlcn0vb3JkZXJib29rYCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHJldHVybiBudWxsO1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICByZXR1cm4gZGF0YS5vcmRlcmJvb2s7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgZmV0Y2hpbmcgb3JkZXJib29rIGZvciAke3RpY2tlcn06YCwgZXJyb3IpO1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG59XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjZSQStFc0IifQ==
}),
"[project]/web/components/MarketTable.module.css [app-ssr] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "active": "MarketTable-module__CHRjXG__active",
  "controls": "MarketTable-module__CHRjXG__controls",
  "detailsBtn": "MarketTable-module__CHRjXG__detailsBtn",
  "filterContainer": "MarketTable-module__CHRjXG__filterContainer",
  "loadingState": "MarketTable-module__CHRjXG__loadingState",
  "marketSubtitle": "MarketTable-module__CHRjXG__marketSubtitle",
  "marketTitle": "MarketTable-module__CHRjXG__marketTitle",
  "price": "MarketTable-module__CHRjXG__price",
  "section": "MarketTable-module__CHRjXG__section",
  "segmentBtn": "MarketTable-module__CHRjXG__segmentBtn",
  "spin": "MarketTable-module__CHRjXG__spin",
  "table": "MarketTable-module__CHRjXG__table",
  "tableContainer": "MarketTable-module__CHRjXG__tableContainer",
  "titleCell": "MarketTable-module__CHRjXG__titleCell",
});
}),
"[project]/web/components/MarketTable.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MarketTable
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__ = __turbopack_context__.i("[project]/web/node_modules/lucide-react/dist/esm/icons/arrow-right.js [app-ssr] (ecmascript) <export default as ArrowRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__ = __turbopack_context__.i("[project]/web/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-ssr] (ecmascript) <export default as Loader2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$data$3a$d036f2__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/web/lib/data:d036f2 [app-ssr] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$data$3a$a67302__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/web/lib/data:a67302 [app-ssr] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/web/components/MarketTable.module.css [app-ssr] (css module)");
"use client";
;
;
;
;
;
;
;
function MarketTable({ markets: initialMarkets, tagsByCategories }) {
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePathname"])();
    const { replace } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const initialCategory = searchParams.get("category") || "All";
    const initialTag = searchParams.get("tag");
    const [activeCategory, setActiveCategory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(initialCategory);
    const [activeSubTag, setActiveSubTag] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(initialTag);
    // Initialize displayed markets based on synchronous category filtering
    const [displayedMarkets, setDisplayedMarkets] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(()=>{
        if (initialCategory !== "All" && !initialTag) {
            return initialMarkets.filter((m)=>m.category === initialCategory || !m.category && initialCategory === "Other");
        }
        return initialMarkets;
    });
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(!!initialTag);
    const categories = [
        "All",
        ...Object.keys(tagsByCategories).sort()
    ];
    const fetchMarketsForTag = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async (tag)=>{
        setIsLoading(true);
        try {
            // 1. Get series for the tag
            const seriesList = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$data$3a$d036f2__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["getSeriesByTags"])(tag);
            // 2. Get markets for each series
            // Limit to first 10 series to avoid too many requests if series list is huge
            // Prioritize series with more recent activity if possible, but we don't have that info yet.
            const targetSeries = seriesList.slice(0, 10);
            const marketsPromises = targetSeries.map((series)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$data$3a$a67302__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["getMarketsBySeries"])(series.ticker));
            const marketsArrays = await Promise.all(marketsPromises);
            const newMarkets = marketsArrays.flat();
            // Remove duplicates
            const uniqueMarkets = Array.from(new Map(newMarkets.map((m)=>[
                    m.ticker,
                    m
                ])).values());
            // Sort by volume descending
            uniqueMarkets.sort((a, b)=>b.volume - a.volume);
            setDisplayedMarkets(uniqueMarkets);
        } catch (error) {
            console.error("Error loading markets by tag:", error);
        } finally{
            setIsLoading(false);
        }
    }, []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const cat = searchParams.get("category") || "All";
        const tag = searchParams.get("tag");
        setActiveCategory(cat);
        setActiveSubTag(tag);
        if (tag) {
            fetchMarketsForTag(tag);
        } else {
            if (cat === "All") {
                setDisplayedMarkets(initialMarkets);
            } else {
                // Filter initial markets by category as a fallback/initial view
                const filtered = initialMarkets.filter((m)=>m.category === cat || !m.category && cat === "Other");
                setDisplayedMarkets(filtered);
            }
        }
    }, [
        searchParams,
        initialMarkets,
        fetchMarketsForTag
    ]);
    const updateUrl = (newCategory, newTag)=>{
        const params = new URLSearchParams(searchParams);
        if (newCategory && newCategory !== "All") {
            params.set("category", newCategory);
        } else {
            params.delete("category");
        }
        if (newTag) {
            params.set("tag", newTag);
        } else {
            params.delete("tag");
        }
        replace(`${pathname}?${params.toString()}`, {
            scroll: false
        });
    };
    const handleCategoryClick = (cat)=>{
        // When category changes, clear the tag
        updateUrl(cat, null);
    };
    const handleSubTagClick = (tag)=>{
        updateUrl(activeCategory, tag);
    };
    const subTags = activeCategory !== "All" && tagsByCategories[activeCategory] ? tagsByCategories[activeCategory] : [];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].section,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].filterContainer,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].controls,
                            children: categories.map((cat)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].segmentBtn} ${activeCategory === cat ? __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].active : ""}`,
                                    onClick: ()=>handleCategoryClick(cat),
                                    children: cat
                                }, cat, false, {
                                    fileName: "[project]/web/components/MarketTable.tsx",
                                    lineNumber: 125,
                                    columnNumber: 25
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/web/components/MarketTable.tsx",
                            lineNumber: 123,
                            columnNumber: 17
                        }, this),
                        subTags.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].controls,
                            children: subTags.map((tag)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].segmentBtn} ${activeSubTag === tag ? __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].active : ""}`,
                                    onClick: ()=>handleSubTagClick(tag),
                                    children: tag
                                }, tag, false, {
                                    fileName: "[project]/web/components/MarketTable.tsx",
                                    lineNumber: 138,
                                    columnNumber: 33
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/web/components/MarketTable.tsx",
                            lineNumber: 136,
                            columnNumber: 25
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/web/components/MarketTable.tsx",
                    lineNumber: 122,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].tableContainer,
                    children: isLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].loadingState,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].spin,
                            size: 32
                        }, void 0, false, {
                            fileName: "[project]/web/components/MarketTable.tsx",
                            lineNumber: 153,
                            columnNumber: 29
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/web/components/MarketTable.tsx",
                        lineNumber: 152,
                        columnNumber: 25
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].table,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            children: "Market"
                                        }, void 0, false, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 159,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            children: "Volume"
                                        }, void 0, false, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 160,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            children: "Yes Price"
                                        }, void 0, false, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 161,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            children: "Action"
                                        }, void 0, false, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 162,
                                            columnNumber: 33
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/web/components/MarketTable.tsx",
                                    lineNumber: 158,
                                    columnNumber: 29
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/web/components/MarketTable.tsx",
                                lineNumber: 157,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                children: [
                                    displayedMarkets.slice(0, 20).map((market)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].titleCell,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].marketTitle,
                                                            children: market.title
                                                        }, void 0, false, {
                                                            fileName: "[project]/web/components/MarketTable.tsx",
                                                            lineNumber: 169,
                                                            columnNumber: 41
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].marketSubtitle,
                                                            children: market.event_ticker
                                                        }, void 0, false, {
                                                            fileName: "[project]/web/components/MarketTable.tsx",
                                                            lineNumber: 170,
                                                            columnNumber: 41
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/web/components/MarketTable.tsx",
                                                    lineNumber: 168,
                                                    columnNumber: 37
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    children: market.volume.toLocaleString()
                                                }, void 0, false, {
                                                    fileName: "[project]/web/components/MarketTable.tsx",
                                                    lineNumber: 172,
                                                    columnNumber: 37
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].price,
                                                        children: [
                                                            market.yes_price,
                                                            "¢"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/web/components/MarketTable.tsx",
                                                        lineNumber: 174,
                                                        columnNumber: 41
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/web/components/MarketTable.tsx",
                                                    lineNumber: 173,
                                                    columnNumber: 37
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                        href: `/trade/${market.ticker}`,
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].detailsBtn,
                                                        children: [
                                                            "Details ",
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                                                size: 14
                                                            }, void 0, false, {
                                                                fileName: "[project]/web/components/MarketTable.tsx",
                                                                lineNumber: 178,
                                                                columnNumber: 53
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/web/components/MarketTable.tsx",
                                                        lineNumber: 177,
                                                        columnNumber: 41
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/web/components/MarketTable.tsx",
                                                    lineNumber: 176,
                                                    columnNumber: 37
                                                }, this)
                                            ]
                                        }, market.ticker, true, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 167,
                                            columnNumber: 33
                                        }, this)),
                                    displayedMarkets.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                            colSpan: 4,
                                            style: {
                                                textAlign: "center",
                                                padding: "2rem"
                                            },
                                            children: "No markets found"
                                        }, void 0, false, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 185,
                                            columnNumber: 41
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/web/components/MarketTable.tsx",
                                        lineNumber: 184,
                                        columnNumber: 37
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/web/components/MarketTable.tsx",
                                lineNumber: 165,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/web/components/MarketTable.tsx",
                        lineNumber: 156,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/web/components/MarketTable.tsx",
                    lineNumber: 150,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/web/components/MarketTable.tsx",
            lineNumber: 121,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/web/components/MarketTable.tsx",
        lineNumber: 120,
        columnNumber: 9
    }, this);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__0a0e5d83._.js.map