module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[project]/web/components/HeroSection.module.css [app-ssr] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "actions": "HeroSection-module__suLlPW__actions",
  "backgroundEffects": "HeroSection-module__suLlPW__backgroundEffects",
  "badge": "HeroSection-module__suLlPW__badge",
  "badgeDot": "HeroSection-module__suLlPW__badgeDot",
  "badgeText": "HeroSection-module__suLlPW__badgeText",
  "benefitsList": "HeroSection-module__suLlPW__benefitsList",
  "benefitsTitle": "HeroSection-module__suLlPW__benefitsTitle",
  "bulletList": "HeroSection-module__suLlPW__bulletList",
  "content": "HeroSection-module__suLlPW__content",
  "fadeInDown": "HeroSection-module__suLlPW__fadeInDown",
  "fadeInUp": "HeroSection-module__suLlPW__fadeInUp",
  "featureCard": "HeroSection-module__suLlPW__featureCard",
  "featureGrid": "HeroSection-module__suLlPW__featureGrid",
  "featurePanel": "HeroSection-module__suLlPW__featurePanel",
  "float": "HeroSection-module__suLlPW__float",
  "glowPrimary": "HeroSection-module__suLlPW__glowPrimary",
  "glowSecondary": "HeroSection-module__suLlPW__glowSecondary",
  "gridPattern": "HeroSection-module__suLlPW__gridPattern",
  "hero": "HeroSection-module__suLlPW__hero",
  "iconWrapper": "HeroSection-module__suLlPW__iconWrapper",
  "layout": "HeroSection-module__suLlPW__layout",
  "panelHeader": "HeroSection-module__suLlPW__panelHeader",
  "panelLabel": "HeroSection-module__suLlPW__panelLabel",
  "panelStatus": "HeroSection-module__suLlPW__panelStatus",
  "panelSubtext": "HeroSection-module__suLlPW__panelSubtext",
  "pulse": "HeroSection-module__suLlPW__pulse",
  "statusDot": "HeroSection-module__suLlPW__statusDot",
  "subtitle": "HeroSection-module__suLlPW__subtitle",
  "title": "HeroSection-module__suLlPW__title",
});
}),
"[project]/web/components/HeroSection.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HeroSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__ = __turbopack_context__.i("[project]/web/node_modules/lucide-react/dist/esm/icons/arrow-right.js [app-ssr] (ecmascript) <export default as ArrowRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/web/components/HeroSection.module.css [app-ssr] (css module)");
"use client";
;
;
;
function HeroSection() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].hero,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].backgroundEffects,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].gridPattern
                    }, void 0, false, {
                        fileName: "[project]/web/components/HeroSection.tsx",
                        lineNumber: 10,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].glowPrimary
                    }, void 0, false, {
                        fileName: "[project]/web/components/HeroSection.tsx",
                        lineNumber: 11,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].glowSecondary
                    }, void 0, false, {
                        fileName: "[project]/web/components/HeroSection.tsx",
                        lineNumber: 12,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/web/components/HeroSection.tsx",
                lineNumber: 9,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].layout,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].content,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].badge,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].badgeDot
                                    }, void 0, false, {
                                        fileName: "[project]/web/components/HeroSection.tsx",
                                        lineNumber: 19,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].badgeText,
                                        children: "Live Market Signals Active"
                                    }, void 0, false, {
                                        fileName: "[project]/web/components/HeroSection.tsx",
                                        lineNumber: 20,
                                        columnNumber: 29
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/web/components/HeroSection.tsx",
                                lineNumber: 18,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].title,
                                children: [
                                    "Trade on ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-gradient",
                                        children: "Real World"
                                    }, void 0, false, {
                                        fileName: "[project]/web/components/HeroSection.tsx",
                                        lineNumber: 24,
                                        columnNumber: 38
                                    }, this),
                                    " Events"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/web/components/HeroSection.tsx",
                                lineNumber: 23,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].subtitle,
                                children: "Access AI-powered insights and probability analysis for the first regulated exchange dedicated to trading event outcomes."
                            }, void 0, false, {
                                fileName: "[project]/web/components/HeroSection.tsx",
                                lineNumber: 27,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].actions,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: "btn btn-primary",
                                        children: [
                                            "Start Trading ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                                size: 18,
                                                style: {
                                                    marginLeft: "0.5rem"
                                                }
                                            }, void 0, false, {
                                                fileName: "[project]/web/components/HeroSection.tsx",
                                                lineNumber: 34,
                                                columnNumber: 47
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/web/components/HeroSection.tsx",
                                        lineNumber: 33,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: "btn btn-outline",
                                        children: "View All Markets"
                                    }, void 0, false, {
                                        fileName: "[project]/web/components/HeroSection.tsx",
                                        lineNumber: 36,
                                        columnNumber: 29
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/web/components/HeroSection.tsx",
                                lineNumber: 32,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/web/components/HeroSection.tsx",
                        lineNumber: 17,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/web/components/HeroSection.tsx",
                    lineNumber: 16,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/web/components/HeroSection.tsx",
                lineNumber: 15,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/web/components/HeroSection.tsx",
        lineNumber: 8,
        columnNumber: 9
    }, this);
}
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[project]/web/lib/data:b00ed9 [app-ssr] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"409071e25c2a92798fac6387e9301fdc81bce11cd4":"getSeriesByTags"},"web/lib/kalshi.ts",""] */ __turbopack_context__.s([
    "getSeriesByTags",
    ()=>getSeriesByTags
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
var getSeriesByTags = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("409071e25c2a92798fac6387e9301fdc81bce11cd4", __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "getSeriesByTags"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4va2Fsc2hpLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIHNlcnZlclwiO1xuXG5jb25zdCBCQVNFX1VSTCA9IFwiaHR0cHM6Ly9hcGkuZWxlY3Rpb25zLmthbHNoaS5jb20vdHJhZGUtYXBpL3YyXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgTWFya2V0IHtcbiAgICB0aWNrZXI6IHN0cmluZztcbiAgICBldmVudF90aWNrZXI6IHN0cmluZztcbiAgICB0aXRsZTogc3RyaW5nO1xuICAgIHN1YnRpdGxlPzogc3RyaW5nO1xuICAgIHllc19wcmljZTogbnVtYmVyO1xuICAgIHZvbHVtZTogbnVtYmVyO1xuICAgIG9wZW5faW50ZXJlc3Q6IG51bWJlcjtcbiAgICBsaXF1aWRpdHk6IG51bWJlcjtcbiAgICBzdGF0dXM6IHN0cmluZztcbiAgICBjYXRlZ29yeT86IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBNYXJrZXREZXRhaWwgZXh0ZW5kcyBNYXJrZXQge1xuICAgIGNhdGVnb3J5OiBzdHJpbmc7IC8vIE92ZXJyaWRlIGFzIHJlcXVpcmVkIGZvciBkZXRhaWxzXG4gICAgZXhwaXJhdGlvbl90aW1lOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgT3JkZXJCb29rIHtcbiAgICB5ZXM6IFtudW1iZXIsIG51bWJlcl1bXTtcbiAgICBubzogW251bWJlciwgbnVtYmVyXVtdO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFNlcmllcyB7XG4gICAgdGlja2VyOiBzdHJpbmc7XG4gICAgZnJlcXVlbmN5OiBzdHJpbmc7XG4gICAgdGl0bGU6IHN0cmluZztcbiAgICBjYXRlZ29yeTogc3RyaW5nO1xuICAgIHRhZ3M6IHN0cmluZ1tdO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0SGlnaFZvbHVtZU1hcmtldHMobGltaXQgPSAxMDApOiBQcm9taXNlPE1hcmtldFtdPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vbWFya2V0cz9saW1pdD0ke2xpbWl0fSZzdGF0dXM9b3BlbmAsIHtcbiAgICAgICAgICAgIG5leHQ6IHsgcmV2YWxpZGF0ZTogNjAgfSxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIGZldGNoIG1hcmtldHNcIik7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICBsZXQgbWFya2V0czogTWFya2V0W10gPSBkYXRhLm1hcmtldHMgfHwgW107XG5cbiAgICAgICAgLy8gQXNzaWduIGNhdGVnb3JpZXMgaGV1cmlzdGljYWxseSBzaW5jZSBBUEkgcmV0dXJucyBlbXB0eSBzdHJpbmdcbiAgICAgICAgbWFya2V0cyA9IG1hcmtldHMubWFwKG0gPT4gKHtcbiAgICAgICAgICAgIC4uLm0sXG4gICAgICAgICAgICBjYXRlZ29yeTogYXNzaWduQ2F0ZWdvcnkobSlcbiAgICAgICAgfSkpO1xuXG4gICAgICAgIHJldHVybiBtYXJrZXRzXG4gICAgICAgICAgICAuc29ydCgoYSwgYikgPT4gYi52b2x1bWUgLSBhLnZvbHVtZSlcbiAgICAgICAgICAgIC5zbGljZSgwLCBsaW1pdCk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGhpZ2ggdm9sdW1lIG1hcmtldHM6XCIsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbn1cblxuZnVuY3Rpb24gYXNzaWduQ2F0ZWdvcnkobWFya2V0OiBNYXJrZXQpOiBzdHJpbmcge1xuICAgIGNvbnN0IHRleHQgPSBgJHttYXJrZXQudGl0bGV9ICR7bWFya2V0LnRpY2tlcn0gJHttYXJrZXQuZXZlbnRfdGlja2VyfWAudG9Mb3dlckNhc2UoKTtcblxuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiZmVkXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJpbmZsYXRpb25cIikgfHwgdGV4dC5pbmNsdWRlcyhcInJhdGVcIikgfHwgdGV4dC5pbmNsdWRlcyhcImdkcFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZWNvbm9teVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwic3B4XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJuYXNkYXFcIikgfHwgdGV4dC5pbmNsdWRlcyhcInRyZWFzdXJcIikpIHJldHVybiBcIkVjb25vbWljc1wiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwidHJ1bXBcIikgfHwgdGV4dC5pbmNsdWRlcyhcImJpZGVuXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJoYXJyaXNcIikgfHwgdGV4dC5pbmNsdWRlcyhcImVsZWN0aW9uXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzZW5hdGVcIikgfHwgdGV4dC5pbmNsdWRlcyhcImhvdXNlXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJwcmVzaWRlbnRcIikgfHwgdGV4dC5pbmNsdWRlcyhcImdvdlwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiY2FiaW5ldFwiKSkgcmV0dXJuIFwiUG9saXRpY3NcIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcImFwcGxlXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJ0ZXNsYVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiYWlcIikgfHwgdGV4dC5pbmNsdWRlcyhcImdwdFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwidGVjaFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibXVza1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibnZpZGlhXCIpKSByZXR1cm4gXCJTY2llbmNlIGFuZCBUZWNobm9sb2d5XCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJ0ZW1wXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJyYWluXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzbm93XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJodXJyaWNhbmVcIikgfHwgdGV4dC5pbmNsdWRlcyhcImNsaW1hdGVcIikgfHwgdGV4dC5pbmNsdWRlcyhcIndlYXRoZXJcIikgfHwgdGV4dC5pbmNsdWRlcyhcImRlZ3JlZVwiKSkgcmV0dXJuIFwiQ2xpbWF0ZSBhbmQgV2VhdGhlclwiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiYml0Y29pblwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiYnRjXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJldGhcIikgfHwgdGV4dC5pbmNsdWRlcyhcImNyeXB0b1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwic29sYW5hXCIpKSByZXR1cm4gXCJDcnlwdG9cIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcIm1vdmllXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJtdXNpY1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwib3NjYXJcIikgfHwgdGV4dC5pbmNsdWRlcyhcImdyYW1teVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiYm94IG9mZmljZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwic3BvdGlmeVwiKSkgcmV0dXJuIFwiRW50ZXJ0YWlubWVudFwiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiZm9vdGJhbGxcIikgfHwgdGV4dC5pbmNsdWRlcyhcIm5mbFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibmJhXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzcG9ydFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ2FtZVwiKSkgcmV0dXJuIFwiU3BvcnRzXCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJkaXNlYXNlXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJoZWFsdGhcIikgfHwgdGV4dC5pbmNsdWRlcyhcImNvdmlkXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJ2YWNjaW5lXCIpKSByZXR1cm4gXCJIZWFsdGhcIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcImZpbmFuY2lhbFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwic3RvY2tcIikgfHwgdGV4dC5pbmNsdWRlcyhcIm1hcmtldFwiKSkgcmV0dXJuIFwiRmluYW5jaWFsc1wiO1xuXG4gICAgcmV0dXJuIFwiT3RoZXJcIjtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE1hcmtldHNCeVNlcmllcyhzZXJpZXNUaWNrZXI6IHN0cmluZywgbWF4Q3JlYXRlZFRzOiBzdHJpbmcgfCBudWxsID0gbnVsbCk6IFByb21pc2U8TWFya2V0W10+IHtcbiAgICB0cnkge1xuICAgICAgICBsZXQgdXJsID0gYCR7QkFTRV9VUkx9L21hcmtldHM/c2VyaWVzX3RpY2tlcj0ke3Nlcmllc1RpY2tlcn0mc3RhdHVzPW9wZW5gO1xuXG4gICAgICAgIGlmIChtYXhDcmVhdGVkVHMpIHtcbiAgICAgICAgICAgIHVybCArPSBgJm1heF9jcmVhdGVkX3RzPSR7ZW5jb2RlVVJJQ29tcG9uZW50KG1heENyZWF0ZWRUcyl9YDtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGNvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG4gICAgICAgIGNvbnN0IHRpbWVvdXRJZCA9IHNldFRpbWVvdXQoKCkgPT4gY29udHJvbGxlci5hYm9ydCgpLCAxMDAwMCk7IC8vIDEwIHNlY29uZCB0aW1lb3V0XG5cbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaCh1cmwsIHtcbiAgICAgICAgICAgIHNpZ25hbDogY29udHJvbGxlci5zaWduYWwsXG4gICAgICAgICAgICBuZXh0OiB7IHJldmFsaWRhdGU6IDYwIH1cbiAgICAgICAgfSk7XG5cbiAgICAgICAgY2xlYXJUaW1lb3V0KHRpbWVvdXRJZCk7XG5cbiAgICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgICAgICAgICAgY29uc29sZS53YXJuKGBBUEkgcmV0dXJuZWQgJHtyZXNwb25zZS5zdGF0dXN9IGZvciBzZXJpZXMgJHtzZXJpZXNUaWNrZXJ9YCk7XG4gICAgICAgICAgICByZXR1cm4gW107XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICByZXR1cm4gZGF0YS5tYXJrZXRzIHx8IFtdO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIEVycm9yICYmIGVycm9yLm5hbWUgPT09ICdBYm9ydEVycm9yJykge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihgUmVxdWVzdCB0aW1lb3V0IGZvciBzZXJpZXMgJHtzZXJpZXNUaWNrZXJ9YCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBmZXRjaGluZyBzZXJpZXMgJHtzZXJpZXNUaWNrZXJ9OmAsIGVycm9yKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gW107XG4gICAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0VGFnc0J5Q2F0ZWdvcmllcygpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPj4ge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7QkFTRV9VUkx9L3NlYXJjaC90YWdzX2J5X2NhdGVnb3JpZXNgKTtcbiAgICAgICAgaWYgKCFyZXNwb25zZS5vaykgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIGZldGNoIHRhZ3NcIik7XG5cbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIGRhdGEudGFnc19ieV9jYXRlZ29yaWVzIHx8IHt9O1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB0YWdzOlwiLCBlcnJvcik7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBcIkVjb25vbWljc1wiOiBbXCJJbnRlcmVzdCBSYXRlc1wiLCBcIkluZmxhdGlvblwiLCBcIkdEUFwiXSxcbiAgICAgICAgICAgIFwiUG9saXRpY3NcIjogW1wiRWxlY3Rpb25zXCIsIFwiUG9saWN5XCJdLFxuICAgICAgICAgICAgXCJUZWNobm9sb2d5XCI6IFtcIkFJXCIsIFwiSGFyZHdhcmVcIl0sXG4gICAgICAgICAgICBcIk90aGVyXCI6IFtdXG4gICAgICAgIH07XG4gICAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2VyaWVzQnlUYWdzKHRhZ3M6IHN0cmluZyk6IFByb21pc2U8U2VyaWVzW10+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfS9zZXJpZXM/dGFncz0ke3RhZ3N9YCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHJldHVybiBbXTtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIGRhdGEuc2VyaWVzIHx8IFtdO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGZldGNoaW5nIHNlcmllcyBmb3IgdGFncyAke3RhZ3N9OmAsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNlcmllc0J5Q2F0ZWdvcnkoY2F0ZWdvcnk6IHN0cmluZyk6IFByb21pc2U8U2VyaWVzW10+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfS9zZXJpZXM/c2VyaWVzX2NhdGVnb3J5PSR7ZW5jb2RlVVJJQ29tcG9uZW50KGNhdGVnb3J5KX1gKTtcbiAgICAgICAgLy8gTm90ZTogVGhlIGRvY3VtZW50YXRpb24gbWlnaHQgc2F5IGBjYXRlZ29yeWAsIGJ1dCBzdGFuZGFyZCBLYWxzaGkgQVBJIHVzdWFsbHkgdXNlcyBgc2VyaWVzX2NhdGVnb3J5YCBvciBqdXN0IGBjYXRlZ29yeWAuIFxuICAgICAgICAvLyBUaGUgdXNlciBwcm92aWRlZCBsaW5rIGh0dHBzOi8vZG9jcy5rYWxzaGkuY29tL2FwaS1yZWZlcmVuY2UvbWFya2V0L2dldC1zZXJpZXMtbGlzdCBzYXlzIHBhcmFtZXRlcnMgYXJlIGBzZXJpZXNfdGlja2VyYCwgYHNlcmllc19jYXRlZ29yeWAsIGB0YWdzYC5cbiAgICAgICAgLy8gV2FpdCwgdXNlciBzYWlkIGAvc2VyaWVzP2NhdGVnb3J5PXh4eGAuIFxuICAgICAgICAvLyBMZXQncyB2ZXJpZnkgdGhlIHVzZXIncyBsaW5rIGRvY3VtZW50YXRpb24gaWYgcG9zc2libGUgb3IgdHJ1c3QgdGhlIHVzZXIuIFxuICAgICAgICAvLyBUaGUgdXNlciBleHBsaWNpdGx5IHdyb3RlIGAvc2VyaWVzP2NhdGVnb3J5PXh4eGAuXG4gICAgICAgIC8vIEhvd2V2ZXIsIHN0YW5kYXJkIHBhcmFtZXRlciBmb3IgY2F0ZWdvcnkgaW4gbWFueSBBUElzIGlzIG9mdGVuIGp1c3QgYGNhdGVnb3J5YC5cbiAgICAgICAgLy8gQnV0IGxldCdzIGNoZWNrIHRoZSB1c2VyIHByb3ZpZGVkIGxpbmsgaW4gbXkgaGVhZCAoSSBjYW4ndCBicm93c2UpLlxuICAgICAgICAvLyBBY3R1YWxseSBJIGNhbiBicm93c2UuXG4gICAgICAgIC8vIExldCdzIHVzZSBgY2F0ZWdvcnlgIGFzIHJlcXVlc3RlZCBieSB1c2VyLCBidXQgSSB3aWxsIGRvdWJsZSBjaGVjay5cbiAgICAgICAgLy8gQnV0IEkgd2lsbCBzdGljayB0byB3aGF0IHRoZSB1c2VyIHJlcXVlc3RlZCBgP2NhdGVnb3J5PWAuXG4gICAgICAgIC8vIFdhaXQsIHRoZSB1c2VyIHNhaWQgXCJDaGVjayBkb2N1bWVudGF0aW9uOiAuLi5cIi5cbiAgICAgICAgXG4gICAgICAgIC8vIEkgd2lsbCB0cnVzdCB0aGUgdXNlcidzIHNwZWNpZmljIHJlcXVlc3QgXCJwYXNzIGNhdGVnb3J5IGFzIHF1ZXJ5IHN0cmluZzogL3Nlcmllcz9jYXRlZ29yeT14eHhcIlxuICAgICAgICAvLyBCdXQgSSB3aWxsIGFsc28gaGFuZGxlIHRoZSBjYXNlIGlmIGl0IG5lZWRzIHRvIGJlIG1hcHBlZC5cbiAgICAgICAgLy8gQWN0dWFsbHksIGxldCdzIGxvb2sgYXQgYGdldFRhZ3NCeUNhdGVnb3JpZXNgLiBJdCB1c2VzIGB0YWdzX2J5X2NhdGVnb3JpZXNgLlxuICAgICAgICBcbiAgICAgICAgLy8gTGV0J3MgdHJ5IGBjYXRlZ29yeWAgZmlyc3QgYXMgdXNlciBhc2tlZC5cbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYCR7QkFTRV9VUkx9L3Nlcmllcz9jYXRlZ29yeT0ke2VuY29kZVVSSUNvbXBvbmVudChjYXRlZ29yeSl9YCk7XG4gICAgICAgIGlmICghcmVzLm9rKSByZXR1cm4gW107XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXMuanNvbigpO1xuICAgICAgICByZXR1cm4gZGF0YS5zZXJpZXMgfHwgW107XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgZmV0Y2hpbmcgc2VyaWVzIGZvciBjYXRlZ29yeSAke2NhdGVnb3J5fTpgLCBlcnJvcik7XG4gICAgICAgIHJldHVybiBbXTtcbiAgICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRNYXJrZXREZXRhaWxzKHRpY2tlcjogc3RyaW5nKTogUHJvbWlzZTxNYXJrZXREZXRhaWwgfCBudWxsPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vbWFya2V0cy8ke3RpY2tlcn1gKTtcbiAgICAgICAgaWYgKCFyZXNwb25zZS5vaykgcmV0dXJuIG51bGw7XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIHJldHVybiBkYXRhLm1hcmtldDtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBmZXRjaGluZyBtYXJrZXQgJHt0aWNrZXJ9OmAsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0T3JkZXJCb29rKHRpY2tlcjogc3RyaW5nKTogUHJvbWlzZTxPcmRlckJvb2sgfCBudWxsPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vbWFya2V0cy8ke3RpY2tlcn0vb3JkZXJib29rYCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHJldHVybiBudWxsO1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICByZXR1cm4gZGF0YS5vcmRlcmJvb2s7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgZmV0Y2hpbmcgb3JkZXJib29rIGZvciAke3RpY2tlcn06YCwgZXJyb3IpO1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG59XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjBSQW9Jc0IifQ==
}),
"[project]/web/lib/data:239617 [app-ssr] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"6098a2c63c1f4720d0b4167856dc1aed4865487165":"getMarketsBySeries"},"web/lib/kalshi.ts",""] */ __turbopack_context__.s([
    "getMarketsBySeries",
    ()=>getMarketsBySeries
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
var getMarketsBySeries = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("6098a2c63c1f4720d0b4167856dc1aed4865487165", __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "getMarketsBySeries"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4va2Fsc2hpLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIHNlcnZlclwiO1xuXG5jb25zdCBCQVNFX1VSTCA9IFwiaHR0cHM6Ly9hcGkuZWxlY3Rpb25zLmthbHNoaS5jb20vdHJhZGUtYXBpL3YyXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgTWFya2V0IHtcbiAgICB0aWNrZXI6IHN0cmluZztcbiAgICBldmVudF90aWNrZXI6IHN0cmluZztcbiAgICB0aXRsZTogc3RyaW5nO1xuICAgIHN1YnRpdGxlPzogc3RyaW5nO1xuICAgIHllc19wcmljZTogbnVtYmVyO1xuICAgIHZvbHVtZTogbnVtYmVyO1xuICAgIG9wZW5faW50ZXJlc3Q6IG51bWJlcjtcbiAgICBsaXF1aWRpdHk6IG51bWJlcjtcbiAgICBzdGF0dXM6IHN0cmluZztcbiAgICBjYXRlZ29yeT86IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBNYXJrZXREZXRhaWwgZXh0ZW5kcyBNYXJrZXQge1xuICAgIGNhdGVnb3J5OiBzdHJpbmc7IC8vIE92ZXJyaWRlIGFzIHJlcXVpcmVkIGZvciBkZXRhaWxzXG4gICAgZXhwaXJhdGlvbl90aW1lOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgT3JkZXJCb29rIHtcbiAgICB5ZXM6IFtudW1iZXIsIG51bWJlcl1bXTtcbiAgICBubzogW251bWJlciwgbnVtYmVyXVtdO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFNlcmllcyB7XG4gICAgdGlja2VyOiBzdHJpbmc7XG4gICAgZnJlcXVlbmN5OiBzdHJpbmc7XG4gICAgdGl0bGU6IHN0cmluZztcbiAgICBjYXRlZ29yeTogc3RyaW5nO1xuICAgIHRhZ3M6IHN0cmluZ1tdO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0SGlnaFZvbHVtZU1hcmtldHMobGltaXQgPSAxMDApOiBQcm9taXNlPE1hcmtldFtdPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vbWFya2V0cz9saW1pdD0ke2xpbWl0fSZzdGF0dXM9b3BlbmAsIHtcbiAgICAgICAgICAgIG5leHQ6IHsgcmV2YWxpZGF0ZTogNjAgfSxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIGZldGNoIG1hcmtldHNcIik7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICBsZXQgbWFya2V0czogTWFya2V0W10gPSBkYXRhLm1hcmtldHMgfHwgW107XG5cbiAgICAgICAgLy8gQXNzaWduIGNhdGVnb3JpZXMgaGV1cmlzdGljYWxseSBzaW5jZSBBUEkgcmV0dXJucyBlbXB0eSBzdHJpbmdcbiAgICAgICAgbWFya2V0cyA9IG1hcmtldHMubWFwKG0gPT4gKHtcbiAgICAgICAgICAgIC4uLm0sXG4gICAgICAgICAgICBjYXRlZ29yeTogYXNzaWduQ2F0ZWdvcnkobSlcbiAgICAgICAgfSkpO1xuXG4gICAgICAgIHJldHVybiBtYXJrZXRzXG4gICAgICAgICAgICAuc29ydCgoYSwgYikgPT4gYi52b2x1bWUgLSBhLnZvbHVtZSlcbiAgICAgICAgICAgIC5zbGljZSgwLCBsaW1pdCk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGhpZ2ggdm9sdW1lIG1hcmtldHM6XCIsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbn1cblxuZnVuY3Rpb24gYXNzaWduQ2F0ZWdvcnkobWFya2V0OiBNYXJrZXQpOiBzdHJpbmcge1xuICAgIGNvbnN0IHRleHQgPSBgJHttYXJrZXQudGl0bGV9ICR7bWFya2V0LnRpY2tlcn0gJHttYXJrZXQuZXZlbnRfdGlja2VyfWAudG9Mb3dlckNhc2UoKTtcblxuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiZmVkXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJpbmZsYXRpb25cIikgfHwgdGV4dC5pbmNsdWRlcyhcInJhdGVcIikgfHwgdGV4dC5pbmNsdWRlcyhcImdkcFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZWNvbm9teVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwic3B4XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJuYXNkYXFcIikgfHwgdGV4dC5pbmNsdWRlcyhcInRyZWFzdXJcIikpIHJldHVybiBcIkVjb25vbWljc1wiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwidHJ1bXBcIikgfHwgdGV4dC5pbmNsdWRlcyhcImJpZGVuXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJoYXJyaXNcIikgfHwgdGV4dC5pbmNsdWRlcyhcImVsZWN0aW9uXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzZW5hdGVcIikgfHwgdGV4dC5pbmNsdWRlcyhcImhvdXNlXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJwcmVzaWRlbnRcIikgfHwgdGV4dC5pbmNsdWRlcyhcImdvdlwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiY2FiaW5ldFwiKSkgcmV0dXJuIFwiUG9saXRpY3NcIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcImFwcGxlXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJ0ZXNsYVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiYWlcIikgfHwgdGV4dC5pbmNsdWRlcyhcImdwdFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwidGVjaFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibXVza1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibnZpZGlhXCIpKSByZXR1cm4gXCJTY2llbmNlIGFuZCBUZWNobm9sb2d5XCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJ0ZW1wXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJyYWluXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzbm93XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJodXJyaWNhbmVcIikgfHwgdGV4dC5pbmNsdWRlcyhcImNsaW1hdGVcIikgfHwgdGV4dC5pbmNsdWRlcyhcIndlYXRoZXJcIikgfHwgdGV4dC5pbmNsdWRlcyhcImRlZ3JlZVwiKSkgcmV0dXJuIFwiQ2xpbWF0ZSBhbmQgV2VhdGhlclwiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiYml0Y29pblwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiYnRjXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJldGhcIikgfHwgdGV4dC5pbmNsdWRlcyhcImNyeXB0b1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwic29sYW5hXCIpKSByZXR1cm4gXCJDcnlwdG9cIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcIm1vdmllXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJtdXNpY1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwib3NjYXJcIikgfHwgdGV4dC5pbmNsdWRlcyhcImdyYW1teVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiYm94IG9mZmljZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwic3BvdGlmeVwiKSkgcmV0dXJuIFwiRW50ZXJ0YWlubWVudFwiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiZm9vdGJhbGxcIikgfHwgdGV4dC5pbmNsdWRlcyhcIm5mbFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibmJhXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzcG9ydFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ2FtZVwiKSkgcmV0dXJuIFwiU3BvcnRzXCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJkaXNlYXNlXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJoZWFsdGhcIikgfHwgdGV4dC5pbmNsdWRlcyhcImNvdmlkXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJ2YWNjaW5lXCIpKSByZXR1cm4gXCJIZWFsdGhcIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcImZpbmFuY2lhbFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwic3RvY2tcIikgfHwgdGV4dC5pbmNsdWRlcyhcIm1hcmtldFwiKSkgcmV0dXJuIFwiRmluYW5jaWFsc1wiO1xuXG4gICAgcmV0dXJuIFwiT3RoZXJcIjtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE1hcmtldHNCeVNlcmllcyhzZXJpZXNUaWNrZXI6IHN0cmluZywgbWF4Q3JlYXRlZFRzOiBzdHJpbmcgfCBudWxsID0gbnVsbCk6IFByb21pc2U8TWFya2V0W10+IHtcbiAgICB0cnkge1xuICAgICAgICBsZXQgdXJsID0gYCR7QkFTRV9VUkx9L21hcmtldHM/c2VyaWVzX3RpY2tlcj0ke3Nlcmllc1RpY2tlcn0mc3RhdHVzPW9wZW5gO1xuXG4gICAgICAgIGlmIChtYXhDcmVhdGVkVHMpIHtcbiAgICAgICAgICAgIHVybCArPSBgJm1heF9jcmVhdGVkX3RzPSR7ZW5jb2RlVVJJQ29tcG9uZW50KG1heENyZWF0ZWRUcyl9YDtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGNvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG4gICAgICAgIGNvbnN0IHRpbWVvdXRJZCA9IHNldFRpbWVvdXQoKCkgPT4gY29udHJvbGxlci5hYm9ydCgpLCAxMDAwMCk7IC8vIDEwIHNlY29uZCB0aW1lb3V0XG5cbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaCh1cmwsIHtcbiAgICAgICAgICAgIHNpZ25hbDogY29udHJvbGxlci5zaWduYWwsXG4gICAgICAgICAgICBuZXh0OiB7IHJldmFsaWRhdGU6IDYwIH1cbiAgICAgICAgfSk7XG5cbiAgICAgICAgY2xlYXJUaW1lb3V0KHRpbWVvdXRJZCk7XG5cbiAgICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgICAgICAgICAgY29uc29sZS53YXJuKGBBUEkgcmV0dXJuZWQgJHtyZXNwb25zZS5zdGF0dXN9IGZvciBzZXJpZXMgJHtzZXJpZXNUaWNrZXJ9YCk7XG4gICAgICAgICAgICByZXR1cm4gW107XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICByZXR1cm4gZGF0YS5tYXJrZXRzIHx8IFtdO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIEVycm9yICYmIGVycm9yLm5hbWUgPT09ICdBYm9ydEVycm9yJykge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihgUmVxdWVzdCB0aW1lb3V0IGZvciBzZXJpZXMgJHtzZXJpZXNUaWNrZXJ9YCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBmZXRjaGluZyBzZXJpZXMgJHtzZXJpZXNUaWNrZXJ9OmAsIGVycm9yKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gW107XG4gICAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0VGFnc0J5Q2F0ZWdvcmllcygpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPj4ge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7QkFTRV9VUkx9L3NlYXJjaC90YWdzX2J5X2NhdGVnb3JpZXNgKTtcbiAgICAgICAgaWYgKCFyZXNwb25zZS5vaykgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIGZldGNoIHRhZ3NcIik7XG5cbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIGRhdGEudGFnc19ieV9jYXRlZ29yaWVzIHx8IHt9O1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB0YWdzOlwiLCBlcnJvcik7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBcIkVjb25vbWljc1wiOiBbXCJJbnRlcmVzdCBSYXRlc1wiLCBcIkluZmxhdGlvblwiLCBcIkdEUFwiXSxcbiAgICAgICAgICAgIFwiUG9saXRpY3NcIjogW1wiRWxlY3Rpb25zXCIsIFwiUG9saWN5XCJdLFxuICAgICAgICAgICAgXCJUZWNobm9sb2d5XCI6IFtcIkFJXCIsIFwiSGFyZHdhcmVcIl0sXG4gICAgICAgICAgICBcIk90aGVyXCI6IFtdXG4gICAgICAgIH07XG4gICAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2VyaWVzQnlUYWdzKHRhZ3M6IHN0cmluZyk6IFByb21pc2U8U2VyaWVzW10+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfS9zZXJpZXM/dGFncz0ke3RhZ3N9YCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHJldHVybiBbXTtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIGRhdGEuc2VyaWVzIHx8IFtdO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGZldGNoaW5nIHNlcmllcyBmb3IgdGFncyAke3RhZ3N9OmAsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNlcmllc0J5Q2F0ZWdvcnkoY2F0ZWdvcnk6IHN0cmluZyk6IFByb21pc2U8U2VyaWVzW10+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfS9zZXJpZXM/c2VyaWVzX2NhdGVnb3J5PSR7ZW5jb2RlVVJJQ29tcG9uZW50KGNhdGVnb3J5KX1gKTtcbiAgICAgICAgLy8gTm90ZTogVGhlIGRvY3VtZW50YXRpb24gbWlnaHQgc2F5IGBjYXRlZ29yeWAsIGJ1dCBzdGFuZGFyZCBLYWxzaGkgQVBJIHVzdWFsbHkgdXNlcyBgc2VyaWVzX2NhdGVnb3J5YCBvciBqdXN0IGBjYXRlZ29yeWAuIFxuICAgICAgICAvLyBUaGUgdXNlciBwcm92aWRlZCBsaW5rIGh0dHBzOi8vZG9jcy5rYWxzaGkuY29tL2FwaS1yZWZlcmVuY2UvbWFya2V0L2dldC1zZXJpZXMtbGlzdCBzYXlzIHBhcmFtZXRlcnMgYXJlIGBzZXJpZXNfdGlja2VyYCwgYHNlcmllc19jYXRlZ29yeWAsIGB0YWdzYC5cbiAgICAgICAgLy8gV2FpdCwgdXNlciBzYWlkIGAvc2VyaWVzP2NhdGVnb3J5PXh4eGAuIFxuICAgICAgICAvLyBMZXQncyB2ZXJpZnkgdGhlIHVzZXIncyBsaW5rIGRvY3VtZW50YXRpb24gaWYgcG9zc2libGUgb3IgdHJ1c3QgdGhlIHVzZXIuIFxuICAgICAgICAvLyBUaGUgdXNlciBleHBsaWNpdGx5IHdyb3RlIGAvc2VyaWVzP2NhdGVnb3J5PXh4eGAuXG4gICAgICAgIC8vIEhvd2V2ZXIsIHN0YW5kYXJkIHBhcmFtZXRlciBmb3IgY2F0ZWdvcnkgaW4gbWFueSBBUElzIGlzIG9mdGVuIGp1c3QgYGNhdGVnb3J5YC5cbiAgICAgICAgLy8gQnV0IGxldCdzIGNoZWNrIHRoZSB1c2VyIHByb3ZpZGVkIGxpbmsgaW4gbXkgaGVhZCAoSSBjYW4ndCBicm93c2UpLlxuICAgICAgICAvLyBBY3R1YWxseSBJIGNhbiBicm93c2UuXG4gICAgICAgIC8vIExldCdzIHVzZSBgY2F0ZWdvcnlgIGFzIHJlcXVlc3RlZCBieSB1c2VyLCBidXQgSSB3aWxsIGRvdWJsZSBjaGVjay5cbiAgICAgICAgLy8gQnV0IEkgd2lsbCBzdGljayB0byB3aGF0IHRoZSB1c2VyIHJlcXVlc3RlZCBgP2NhdGVnb3J5PWAuXG4gICAgICAgIC8vIFdhaXQsIHRoZSB1c2VyIHNhaWQgXCJDaGVjayBkb2N1bWVudGF0aW9uOiAuLi5cIi5cbiAgICAgICAgXG4gICAgICAgIC8vIEkgd2lsbCB0cnVzdCB0aGUgdXNlcidzIHNwZWNpZmljIHJlcXVlc3QgXCJwYXNzIGNhdGVnb3J5IGFzIHF1ZXJ5IHN0cmluZzogL3Nlcmllcz9jYXRlZ29yeT14eHhcIlxuICAgICAgICAvLyBCdXQgSSB3aWxsIGFsc28gaGFuZGxlIHRoZSBjYXNlIGlmIGl0IG5lZWRzIHRvIGJlIG1hcHBlZC5cbiAgICAgICAgLy8gQWN0dWFsbHksIGxldCdzIGxvb2sgYXQgYGdldFRhZ3NCeUNhdGVnb3JpZXNgLiBJdCB1c2VzIGB0YWdzX2J5X2NhdGVnb3JpZXNgLlxuICAgICAgICBcbiAgICAgICAgLy8gTGV0J3MgdHJ5IGBjYXRlZ29yeWAgZmlyc3QgYXMgdXNlciBhc2tlZC5cbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYCR7QkFTRV9VUkx9L3Nlcmllcz9jYXRlZ29yeT0ke2VuY29kZVVSSUNvbXBvbmVudChjYXRlZ29yeSl9YCk7XG4gICAgICAgIGlmICghcmVzLm9rKSByZXR1cm4gW107XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXMuanNvbigpO1xuICAgICAgICByZXR1cm4gZGF0YS5zZXJpZXMgfHwgW107XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgZmV0Y2hpbmcgc2VyaWVzIGZvciBjYXRlZ29yeSAke2NhdGVnb3J5fTpgLCBlcnJvcik7XG4gICAgICAgIHJldHVybiBbXTtcbiAgICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRNYXJrZXREZXRhaWxzKHRpY2tlcjogc3RyaW5nKTogUHJvbWlzZTxNYXJrZXREZXRhaWwgfCBudWxsPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vbWFya2V0cy8ke3RpY2tlcn1gKTtcbiAgICAgICAgaWYgKCFyZXNwb25zZS5vaykgcmV0dXJuIG51bGw7XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIHJldHVybiBkYXRhLm1hcmtldDtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBmZXRjaGluZyBtYXJrZXQgJHt0aWNrZXJ9OmAsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0T3JkZXJCb29rKHRpY2tlcjogc3RyaW5nKTogUHJvbWlzZTxPcmRlckJvb2sgfCBudWxsPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vbWFya2V0cy8ke3RpY2tlcn0vb3JkZXJib29rYCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHJldHVybiBudWxsO1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICByZXR1cm4gZGF0YS5vcmRlcmJvb2s7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgZmV0Y2hpbmcgb3JkZXJib29rIGZvciAke3RpY2tlcn06YCwgZXJyb3IpO1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG59XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjZSQStFc0IifQ==
}),
"[project]/web/lib/data:4dc94e [app-ssr] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"40d340aaa5db82e6b01959616fc70453cdbbe719c3":"getSeriesByCategory"},"web/lib/kalshi.ts",""] */ __turbopack_context__.s([
    "getSeriesByCategory",
    ()=>getSeriesByCategory
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
var getSeriesByCategory = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("40d340aaa5db82e6b01959616fc70453cdbbe719c3", __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "getSeriesByCategory"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4va2Fsc2hpLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIHNlcnZlclwiO1xuXG5jb25zdCBCQVNFX1VSTCA9IFwiaHR0cHM6Ly9hcGkuZWxlY3Rpb25zLmthbHNoaS5jb20vdHJhZGUtYXBpL3YyXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgTWFya2V0IHtcbiAgICB0aWNrZXI6IHN0cmluZztcbiAgICBldmVudF90aWNrZXI6IHN0cmluZztcbiAgICB0aXRsZTogc3RyaW5nO1xuICAgIHN1YnRpdGxlPzogc3RyaW5nO1xuICAgIHllc19wcmljZTogbnVtYmVyO1xuICAgIHZvbHVtZTogbnVtYmVyO1xuICAgIG9wZW5faW50ZXJlc3Q6IG51bWJlcjtcbiAgICBsaXF1aWRpdHk6IG51bWJlcjtcbiAgICBzdGF0dXM6IHN0cmluZztcbiAgICBjYXRlZ29yeT86IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBNYXJrZXREZXRhaWwgZXh0ZW5kcyBNYXJrZXQge1xuICAgIGNhdGVnb3J5OiBzdHJpbmc7IC8vIE92ZXJyaWRlIGFzIHJlcXVpcmVkIGZvciBkZXRhaWxzXG4gICAgZXhwaXJhdGlvbl90aW1lOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgT3JkZXJCb29rIHtcbiAgICB5ZXM6IFtudW1iZXIsIG51bWJlcl1bXTtcbiAgICBubzogW251bWJlciwgbnVtYmVyXVtdO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFNlcmllcyB7XG4gICAgdGlja2VyOiBzdHJpbmc7XG4gICAgZnJlcXVlbmN5OiBzdHJpbmc7XG4gICAgdGl0bGU6IHN0cmluZztcbiAgICBjYXRlZ29yeTogc3RyaW5nO1xuICAgIHRhZ3M6IHN0cmluZ1tdO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0SGlnaFZvbHVtZU1hcmtldHMobGltaXQgPSAxMDApOiBQcm9taXNlPE1hcmtldFtdPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vbWFya2V0cz9saW1pdD0ke2xpbWl0fSZzdGF0dXM9b3BlbmAsIHtcbiAgICAgICAgICAgIG5leHQ6IHsgcmV2YWxpZGF0ZTogNjAgfSxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIGZldGNoIG1hcmtldHNcIik7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICBsZXQgbWFya2V0czogTWFya2V0W10gPSBkYXRhLm1hcmtldHMgfHwgW107XG5cbiAgICAgICAgLy8gQXNzaWduIGNhdGVnb3JpZXMgaGV1cmlzdGljYWxseSBzaW5jZSBBUEkgcmV0dXJucyBlbXB0eSBzdHJpbmdcbiAgICAgICAgbWFya2V0cyA9IG1hcmtldHMubWFwKG0gPT4gKHtcbiAgICAgICAgICAgIC4uLm0sXG4gICAgICAgICAgICBjYXRlZ29yeTogYXNzaWduQ2F0ZWdvcnkobSlcbiAgICAgICAgfSkpO1xuXG4gICAgICAgIHJldHVybiBtYXJrZXRzXG4gICAgICAgICAgICAuc29ydCgoYSwgYikgPT4gYi52b2x1bWUgLSBhLnZvbHVtZSlcbiAgICAgICAgICAgIC5zbGljZSgwLCBsaW1pdCk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGhpZ2ggdm9sdW1lIG1hcmtldHM6XCIsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbn1cblxuZnVuY3Rpb24gYXNzaWduQ2F0ZWdvcnkobWFya2V0OiBNYXJrZXQpOiBzdHJpbmcge1xuICAgIGNvbnN0IHRleHQgPSBgJHttYXJrZXQudGl0bGV9ICR7bWFya2V0LnRpY2tlcn0gJHttYXJrZXQuZXZlbnRfdGlja2VyfWAudG9Mb3dlckNhc2UoKTtcblxuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiZmVkXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJpbmZsYXRpb25cIikgfHwgdGV4dC5pbmNsdWRlcyhcInJhdGVcIikgfHwgdGV4dC5pbmNsdWRlcyhcImdkcFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZWNvbm9teVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwic3B4XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJuYXNkYXFcIikgfHwgdGV4dC5pbmNsdWRlcyhcInRyZWFzdXJcIikpIHJldHVybiBcIkVjb25vbWljc1wiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwidHJ1bXBcIikgfHwgdGV4dC5pbmNsdWRlcyhcImJpZGVuXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJoYXJyaXNcIikgfHwgdGV4dC5pbmNsdWRlcyhcImVsZWN0aW9uXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzZW5hdGVcIikgfHwgdGV4dC5pbmNsdWRlcyhcImhvdXNlXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJwcmVzaWRlbnRcIikgfHwgdGV4dC5pbmNsdWRlcyhcImdvdlwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiY2FiaW5ldFwiKSkgcmV0dXJuIFwiUG9saXRpY3NcIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcImFwcGxlXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJ0ZXNsYVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiYWlcIikgfHwgdGV4dC5pbmNsdWRlcyhcImdwdFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwidGVjaFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibXVza1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibnZpZGlhXCIpKSByZXR1cm4gXCJTY2llbmNlIGFuZCBUZWNobm9sb2d5XCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJ0ZW1wXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJyYWluXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzbm93XCIpIHx8IHRleHQuaW5jbHVkZXMoXCJodXJyaWNhbmVcIikgfHwgdGV4dC5pbmNsdWRlcyhcImNsaW1hdGVcIikgfHwgdGV4dC5pbmNsdWRlcyhcIndlYXRoZXJcIikgfHwgdGV4dC5pbmNsdWRlcyhcImRlZ3JlZVwiKSkgcmV0dXJuIFwiQ2xpbWF0ZSBhbmQgV2VhdGhlclwiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiYml0Y29pblwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiYnRjXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJldGhcIikgfHwgdGV4dC5pbmNsdWRlcyhcImNyeXB0b1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwic29sYW5hXCIpKSByZXR1cm4gXCJDcnlwdG9cIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcIm1vdmllXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJtdXNpY1wiKSB8fCB0ZXh0LmluY2x1ZGVzKFwib3NjYXJcIikgfHwgdGV4dC5pbmNsdWRlcyhcImdyYW1teVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiYm94IG9mZmljZVwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwic3BvdGlmeVwiKSkgcmV0dXJuIFwiRW50ZXJ0YWlubWVudFwiO1xuICAgIGlmICh0ZXh0LmluY2x1ZGVzKFwiZm9vdGJhbGxcIikgfHwgdGV4dC5pbmNsdWRlcyhcIm5mbFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwibmJhXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJzcG9ydFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwiZ2FtZVwiKSkgcmV0dXJuIFwiU3BvcnRzXCI7XG4gICAgaWYgKHRleHQuaW5jbHVkZXMoXCJkaXNlYXNlXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJoZWFsdGhcIikgfHwgdGV4dC5pbmNsdWRlcyhcImNvdmlkXCIpIHx8IHRleHQuaW5jbHVkZXMoXCJ2YWNjaW5lXCIpKSByZXR1cm4gXCJIZWFsdGhcIjtcbiAgICBpZiAodGV4dC5pbmNsdWRlcyhcImZpbmFuY2lhbFwiKSB8fCB0ZXh0LmluY2x1ZGVzKFwic3RvY2tcIikgfHwgdGV4dC5pbmNsdWRlcyhcIm1hcmtldFwiKSkgcmV0dXJuIFwiRmluYW5jaWFsc1wiO1xuXG4gICAgcmV0dXJuIFwiT3RoZXJcIjtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE1hcmtldHNCeVNlcmllcyhzZXJpZXNUaWNrZXI6IHN0cmluZywgbWF4Q3JlYXRlZFRzOiBzdHJpbmcgfCBudWxsID0gbnVsbCk6IFByb21pc2U8TWFya2V0W10+IHtcbiAgICB0cnkge1xuICAgICAgICBsZXQgdXJsID0gYCR7QkFTRV9VUkx9L21hcmtldHM/c2VyaWVzX3RpY2tlcj0ke3Nlcmllc1RpY2tlcn0mc3RhdHVzPW9wZW5gO1xuXG4gICAgICAgIGlmIChtYXhDcmVhdGVkVHMpIHtcbiAgICAgICAgICAgIHVybCArPSBgJm1heF9jcmVhdGVkX3RzPSR7ZW5jb2RlVVJJQ29tcG9uZW50KG1heENyZWF0ZWRUcyl9YDtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGNvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG4gICAgICAgIGNvbnN0IHRpbWVvdXRJZCA9IHNldFRpbWVvdXQoKCkgPT4gY29udHJvbGxlci5hYm9ydCgpLCAxMDAwMCk7IC8vIDEwIHNlY29uZCB0aW1lb3V0XG5cbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaCh1cmwsIHtcbiAgICAgICAgICAgIHNpZ25hbDogY29udHJvbGxlci5zaWduYWwsXG4gICAgICAgICAgICBuZXh0OiB7IHJldmFsaWRhdGU6IDYwIH1cbiAgICAgICAgfSk7XG5cbiAgICAgICAgY2xlYXJUaW1lb3V0KHRpbWVvdXRJZCk7XG5cbiAgICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgICAgICAgICAgY29uc29sZS53YXJuKGBBUEkgcmV0dXJuZWQgJHtyZXNwb25zZS5zdGF0dXN9IGZvciBzZXJpZXMgJHtzZXJpZXNUaWNrZXJ9YCk7XG4gICAgICAgICAgICByZXR1cm4gW107XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICByZXR1cm4gZGF0YS5tYXJrZXRzIHx8IFtdO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIEVycm9yICYmIGVycm9yLm5hbWUgPT09ICdBYm9ydEVycm9yJykge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihgUmVxdWVzdCB0aW1lb3V0IGZvciBzZXJpZXMgJHtzZXJpZXNUaWNrZXJ9YCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBmZXRjaGluZyBzZXJpZXMgJHtzZXJpZXNUaWNrZXJ9OmAsIGVycm9yKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gW107XG4gICAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0VGFnc0J5Q2F0ZWdvcmllcygpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPj4ge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7QkFTRV9VUkx9L3NlYXJjaC90YWdzX2J5X2NhdGVnb3JpZXNgKTtcbiAgICAgICAgaWYgKCFyZXNwb25zZS5vaykgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIGZldGNoIHRhZ3NcIik7XG5cbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIGRhdGEudGFnc19ieV9jYXRlZ29yaWVzIHx8IHt9O1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB0YWdzOlwiLCBlcnJvcik7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBcIkVjb25vbWljc1wiOiBbXCJJbnRlcmVzdCBSYXRlc1wiLCBcIkluZmxhdGlvblwiLCBcIkdEUFwiXSxcbiAgICAgICAgICAgIFwiUG9saXRpY3NcIjogW1wiRWxlY3Rpb25zXCIsIFwiUG9saWN5XCJdLFxuICAgICAgICAgICAgXCJUZWNobm9sb2d5XCI6IFtcIkFJXCIsIFwiSGFyZHdhcmVcIl0sXG4gICAgICAgICAgICBcIk90aGVyXCI6IFtdXG4gICAgICAgIH07XG4gICAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2VyaWVzQnlUYWdzKHRhZ3M6IHN0cmluZyk6IFByb21pc2U8U2VyaWVzW10+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfS9zZXJpZXM/dGFncz0ke3RhZ3N9YCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHJldHVybiBbXTtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgcmV0dXJuIGRhdGEuc2VyaWVzIHx8IFtdO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGZldGNoaW5nIHNlcmllcyBmb3IgdGFncyAke3RhZ3N9OmAsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNlcmllc0J5Q2F0ZWdvcnkoY2F0ZWdvcnk6IHN0cmluZyk6IFByb21pc2U8U2VyaWVzW10+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfS9zZXJpZXM/c2VyaWVzX2NhdGVnb3J5PSR7ZW5jb2RlVVJJQ29tcG9uZW50KGNhdGVnb3J5KX1gKTtcbiAgICAgICAgLy8gTm90ZTogVGhlIGRvY3VtZW50YXRpb24gbWlnaHQgc2F5IGBjYXRlZ29yeWAsIGJ1dCBzdGFuZGFyZCBLYWxzaGkgQVBJIHVzdWFsbHkgdXNlcyBgc2VyaWVzX2NhdGVnb3J5YCBvciBqdXN0IGBjYXRlZ29yeWAuIFxuICAgICAgICAvLyBUaGUgdXNlciBwcm92aWRlZCBsaW5rIGh0dHBzOi8vZG9jcy5rYWxzaGkuY29tL2FwaS1yZWZlcmVuY2UvbWFya2V0L2dldC1zZXJpZXMtbGlzdCBzYXlzIHBhcmFtZXRlcnMgYXJlIGBzZXJpZXNfdGlja2VyYCwgYHNlcmllc19jYXRlZ29yeWAsIGB0YWdzYC5cbiAgICAgICAgLy8gV2FpdCwgdXNlciBzYWlkIGAvc2VyaWVzP2NhdGVnb3J5PXh4eGAuIFxuICAgICAgICAvLyBMZXQncyB2ZXJpZnkgdGhlIHVzZXIncyBsaW5rIGRvY3VtZW50YXRpb24gaWYgcG9zc2libGUgb3IgdHJ1c3QgdGhlIHVzZXIuIFxuICAgICAgICAvLyBUaGUgdXNlciBleHBsaWNpdGx5IHdyb3RlIGAvc2VyaWVzP2NhdGVnb3J5PXh4eGAuXG4gICAgICAgIC8vIEhvd2V2ZXIsIHN0YW5kYXJkIHBhcmFtZXRlciBmb3IgY2F0ZWdvcnkgaW4gbWFueSBBUElzIGlzIG9mdGVuIGp1c3QgYGNhdGVnb3J5YC5cbiAgICAgICAgLy8gQnV0IGxldCdzIGNoZWNrIHRoZSB1c2VyIHByb3ZpZGVkIGxpbmsgaW4gbXkgaGVhZCAoSSBjYW4ndCBicm93c2UpLlxuICAgICAgICAvLyBBY3R1YWxseSBJIGNhbiBicm93c2UuXG4gICAgICAgIC8vIExldCdzIHVzZSBgY2F0ZWdvcnlgIGFzIHJlcXVlc3RlZCBieSB1c2VyLCBidXQgSSB3aWxsIGRvdWJsZSBjaGVjay5cbiAgICAgICAgLy8gQnV0IEkgd2lsbCBzdGljayB0byB3aGF0IHRoZSB1c2VyIHJlcXVlc3RlZCBgP2NhdGVnb3J5PWAuXG4gICAgICAgIC8vIFdhaXQsIHRoZSB1c2VyIHNhaWQgXCJDaGVjayBkb2N1bWVudGF0aW9uOiAuLi5cIi5cbiAgICAgICAgXG4gICAgICAgIC8vIEkgd2lsbCB0cnVzdCB0aGUgdXNlcidzIHNwZWNpZmljIHJlcXVlc3QgXCJwYXNzIGNhdGVnb3J5IGFzIHF1ZXJ5IHN0cmluZzogL3Nlcmllcz9jYXRlZ29yeT14eHhcIlxuICAgICAgICAvLyBCdXQgSSB3aWxsIGFsc28gaGFuZGxlIHRoZSBjYXNlIGlmIGl0IG5lZWRzIHRvIGJlIG1hcHBlZC5cbiAgICAgICAgLy8gQWN0dWFsbHksIGxldCdzIGxvb2sgYXQgYGdldFRhZ3NCeUNhdGVnb3JpZXNgLiBJdCB1c2VzIGB0YWdzX2J5X2NhdGVnb3JpZXNgLlxuICAgICAgICBcbiAgICAgICAgLy8gTGV0J3MgdHJ5IGBjYXRlZ29yeWAgZmlyc3QgYXMgdXNlciBhc2tlZC5cbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYCR7QkFTRV9VUkx9L3Nlcmllcz9jYXRlZ29yeT0ke2VuY29kZVVSSUNvbXBvbmVudChjYXRlZ29yeSl9YCk7XG4gICAgICAgIGlmICghcmVzLm9rKSByZXR1cm4gW107XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXMuanNvbigpO1xuICAgICAgICByZXR1cm4gZGF0YS5zZXJpZXMgfHwgW107XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgZmV0Y2hpbmcgc2VyaWVzIGZvciBjYXRlZ29yeSAke2NhdGVnb3J5fTpgLCBlcnJvcik7XG4gICAgICAgIHJldHVybiBbXTtcbiAgICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRNYXJrZXREZXRhaWxzKHRpY2tlcjogc3RyaW5nKTogUHJvbWlzZTxNYXJrZXREZXRhaWwgfCBudWxsPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vbWFya2V0cy8ke3RpY2tlcn1gKTtcbiAgICAgICAgaWYgKCFyZXNwb25zZS5vaykgcmV0dXJuIG51bGw7XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIHJldHVybiBkYXRhLm1hcmtldDtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBmZXRjaGluZyBtYXJrZXQgJHt0aWNrZXJ9OmAsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0T3JkZXJCb29rKHRpY2tlcjogc3RyaW5nKTogUHJvbWlzZTxPcmRlckJvb2sgfCBudWxsPiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vbWFya2V0cy8ke3RpY2tlcn0vb3JkZXJib29rYCk7XG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHJldHVybiBudWxsO1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICByZXR1cm4gZGF0YS5vcmRlcmJvb2s7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgZmV0Y2hpbmcgb3JkZXJib29rIGZvciAke3RpY2tlcn06YCwgZXJyb3IpO1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG59XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjhSQWdKc0IifQ==
}),
"[project]/web/components/MarketTable.module.css [app-ssr] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "active": "MarketTable-module__CHRjXG__active",
  "calendarIcon": "MarketTable-module__CHRjXG__calendarIcon",
  "controls": "MarketTable-module__CHRjXG__controls",
  "dateFilterContainer": "MarketTable-module__CHRjXG__dateFilterContainer",
  "dateSelect": "MarketTable-module__CHRjXG__dateSelect",
  "detailsBtn": "MarketTable-module__CHRjXG__detailsBtn",
  "filterContainer": "MarketTable-module__CHRjXG__filterContainer",
  "loadingState": "MarketTable-module__CHRjXG__loadingState",
  "marketSubtitle": "MarketTable-module__CHRjXG__marketSubtitle",
  "marketTitle": "MarketTable-module__CHRjXG__marketTitle",
  "price": "MarketTable-module__CHRjXG__price",
  "section": "MarketTable-module__CHRjXG__section",
  "segmentBtn": "MarketTable-module__CHRjXG__segmentBtn",
  "spin": "MarketTable-module__CHRjXG__spin",
  "table": "MarketTable-module__CHRjXG__table",
  "tableContainer": "MarketTable-module__CHRjXG__tableContainer",
  "titleCell": "MarketTable-module__CHRjXG__titleCell",
});
}),
"[project]/web/components/MarketTable.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MarketTable
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__ = __turbopack_context__.i("[project]/web/node_modules/lucide-react/dist/esm/icons/arrow-right.js [app-ssr] (ecmascript) <export default as ArrowRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__ = __turbopack_context__.i("[project]/web/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-ssr] (ecmascript) <export default as Loader2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__ = __turbopack_context__.i("[project]/web/node_modules/lucide-react/dist/esm/icons/calendar.js [app-ssr] (ecmascript) <export default as Calendar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$data$3a$b00ed9__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/web/lib/data:b00ed9 [app-ssr] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$data$3a$239617__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/web/lib/data:239617 [app-ssr] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$data$3a$4dc94e__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/web/lib/data:4dc94e [app-ssr] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/web/components/MarketTable.module.css [app-ssr] (css module)");
"use client";
;
;
;
;
;
;
;
// Calculate max_close_ts Unix timestamp for Kalshi API based on date filter
// This filters markets that close/expire before the target date
function getMaxCloseTimestamp(dateFilter) {
    if (dateFilter === "All time") return null;
    const now = new Date();
    let targetDate = new Date();
    switch(dateFilter){
        case "Today":
            targetDate.setHours(23, 59, 59, 999);
            break;
        case "Tomorrow":
            targetDate.setDate(now.getDate() + 1);
            targetDate.setHours(23, 59, 59, 999);
            break;
        case "This week":
            // Find next Sunday (end of week)
            const daysUntilSunday = 7 - now.getDay();
            targetDate.setDate(now.getDate() + daysUntilSunday);
            targetDate.setHours(23, 59, 59, 999);
            break;
        case "This month":
            targetDate.setMonth(now.getMonth() + 1, 0); // Last day of current month
            targetDate.setHours(23, 59, 59, 999);
            break;
        case "Next 3 months":
            targetDate.setMonth(now.getMonth() + 3);
            targetDate.setHours(23, 59, 59, 999);
            break;
        case "This year":
            targetDate.setMonth(11, 31); // December 31st of current year
            targetDate.setHours(23, 59, 59, 999);
            break;
    }
    // Return Unix timestamp (seconds since epoch)
    return Math.floor(targetDate.getTime() / 1000);
}
function MarketTable({ markets: initialMarkets, tagsByCategories }) {
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePathname"])();
    const { replace } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const initialCategory = searchParams.get("category") || "All";
    const initialTag = searchParams.get("tag");
    const initialDate = searchParams.get("date") || "All time";
    const [activeCategory, setActiveCategory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(initialCategory);
    const [activeSubTag, setActiveSubTag] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(initialTag);
    const [activeDate, setActiveDate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(initialDate);
    // Initialize displayed markets based on synchronous category filtering
    // Only use initialMarkets fallback if we are on "All" or if we want to show *something* while fetching
    // But since we are moving to async fetching for categories too, we might want to start with empty or initial if matches.
    const [displayedMarkets, setDisplayedMarkets] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(()=>{
        if (initialCategory === "All") {
            return initialMarkets;
        }
        // If category is set but no tag, we initially show fallback filtering 
        // until the async fetch completes (handled in useEffect).
        // This provides better UX than empty table.
        return initialMarkets.filter((m)=>m.category === initialCategory || !m.category && initialCategory === "Other");
    });
    // We are loading if there is a tag OR a category (that is not All) because now we fetch for categories too
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(!!initialTag || initialCategory !== "All");
    const categories = [
        "All",
        ...Object.keys(tagsByCategories).sort()
    ];
    const fetchMarkets = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async (category, tag, maxCloseTs)=>{
        setIsLoading(true);
        try {
            let seriesList;
            if (tag) {
                // 1. Get series for the tag
                seriesList = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$data$3a$b00ed9__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["getSeriesByTags"])(tag);
            } else if (category !== "All") {
                // 1. Get series for the category
                seriesList = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$data$3a$4dc94e__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["getSeriesByCategory"])(category);
            } else {
                // "All" category - we use initialMarkets, no need to fetch series
                setDisplayedMarkets(initialMarkets);
                setIsLoading(false);
                return;
            }
            console.log(`Fetching markets for ${seriesList.length} series with maxCloseTs: ${maxCloseTs}`);
            // 2. Get markets for each series
            // Reduce to first 5 series to avoid timeout issues
            const targetSeries = seriesList.slice(0, 5);
            // Fetch markets in batches of 3 to reduce concurrent requests
            const batchSize = 3;
            const allMarkets = [];
            for(let i = 0; i < targetSeries.length; i += batchSize){
                const batch = targetSeries.slice(i, i + batchSize);
                const batchPromises = batch.map((series)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$data$3a$239617__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["getMarketsBySeries"])(series.ticker, maxCloseTs));
                const batchResults = await Promise.all(batchPromises);
                allMarkets.push(...batchResults.flat());
            }
            // Remove duplicates
            const uniqueMarkets = Array.from(new Map(allMarkets.map((m)=>[
                    m.ticker,
                    m
                ])).values());
            // Sort by volume descending
            uniqueMarkets.sort((a, b)=>b.volume - a.volume);
            console.log(`Fetched ${uniqueMarkets.length} unique markets`);
            setDisplayedMarkets(uniqueMarkets);
        } catch (error) {
            console.error("Error loading markets:", error);
            // Fallback to local filtering if fetch fails
            if (!tag && category !== "All") {
                const filtered = initialMarkets.filter((m)=>m.category === category || !m.category && category === "Other");
                setDisplayedMarkets(filtered);
            }
        } finally{
            setIsLoading(false);
        }
    }, [
        initialMarkets
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const cat = searchParams.get("category") || "All";
        const tag = searchParams.get("tag");
        const date = searchParams.get("date") || "All time";
        setActiveCategory(cat);
        setActiveSubTag(tag);
        setActiveDate(date);
        const maxCloseTs = getMaxCloseTimestamp(date);
        if (tag || cat !== "All") {
            fetchMarkets(cat, tag, maxCloseTs);
        } else {
            setDisplayedMarkets(initialMarkets);
        }
    }, [
        searchParams,
        initialMarkets,
        fetchMarkets
    ]);
    const updateUrl = (newCategory, newTag, newDate)=>{
        const params = new URLSearchParams(searchParams);
        if (newCategory && newCategory !== "All") {
            params.set("category", newCategory);
        } else {
            params.delete("category");
        }
        if (newTag) {
            params.set("tag", newTag);
        } else {
            params.delete("tag");
        }
        const dateToUse = newDate !== undefined ? newDate : activeDate;
        if (dateToUse && dateToUse !== "All time") {
            params.set("date", dateToUse);
        } else {
            params.delete("date");
        }
        replace(`${pathname}?${params.toString()}`, {
            scroll: false
        });
    };
    const handleCategoryClick = (cat)=>{
        // When category changes, clear the tag
        updateUrl(cat, null);
    };
    const handleSubTagClick = (tag)=>{
        updateUrl(activeCategory, tag);
    };
    const handleDateChange = (date)=>{
        updateUrl(activeCategory, activeSubTag, date);
    };
    const subTags = activeCategory !== "All" && tagsByCategories[activeCategory] ? tagsByCategories[activeCategory] : [];
    const dateOptions = [
        "All time",
        "Today",
        "Tomorrow",
        "This week",
        "This month",
        "Next 3 months",
        "This year"
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].section,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].filterContainer,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].controls,
                            children: categories.map((cat)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].segmentBtn} ${activeCategory === cat ? __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].active : ""}`,
                                    onClick: ()=>handleCategoryClick(cat),
                                    children: cat
                                }, cat, false, {
                                    fileName: "[project]/web/components/MarketTable.tsx",
                                    lineNumber: 211,
                                    columnNumber: 25
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/web/components/MarketTable.tsx",
                            lineNumber: 209,
                            columnNumber: 17
                        }, this),
                        subTags.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].controls,
                            children: subTags.map((tag)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].segmentBtn} ${activeSubTag === tag ? __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].active : ""}`,
                                    onClick: ()=>handleSubTagClick(tag),
                                    children: tag
                                }, tag, false, {
                                    fileName: "[project]/web/components/MarketTable.tsx",
                                    lineNumber: 224,
                                    columnNumber: 33
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/web/components/MarketTable.tsx",
                            lineNumber: 222,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].dateFilterContainer,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__["Calendar"], {
                                    size: 16,
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].calendarIcon
                                }, void 0, false, {
                                    fileName: "[project]/web/components/MarketTable.tsx",
                                    lineNumber: 236,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                    value: activeDate,
                                    onChange: (e)=>handleDateChange(e.target.value),
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].dateSelect,
                                    children: dateOptions.map((option)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: option,
                                            children: option
                                        }, option, false, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 243,
                                            columnNumber: 33
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/web/components/MarketTable.tsx",
                                    lineNumber: 237,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/web/components/MarketTable.tsx",
                            lineNumber: 235,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/web/components/MarketTable.tsx",
                    lineNumber: 208,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].tableContainer,
                    children: isLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].loadingState,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].spin,
                            size: 32
                        }, void 0, false, {
                            fileName: "[project]/web/components/MarketTable.tsx",
                            lineNumber: 254,
                            columnNumber: 29
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/web/components/MarketTable.tsx",
                        lineNumber: 253,
                        columnNumber: 25
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].table,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            children: "Market"
                                        }, void 0, false, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 260,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            children: "Volume"
                                        }, void 0, false, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 261,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            children: "Yes Price"
                                        }, void 0, false, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 262,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            children: "Action"
                                        }, void 0, false, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 263,
                                            columnNumber: 33
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/web/components/MarketTable.tsx",
                                    lineNumber: 259,
                                    columnNumber: 29
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/web/components/MarketTable.tsx",
                                lineNumber: 258,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                children: [
                                    displayedMarkets.slice(0, 20).map((market)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].titleCell,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].marketTitle,
                                                            children: market.title
                                                        }, void 0, false, {
                                                            fileName: "[project]/web/components/MarketTable.tsx",
                                                            lineNumber: 270,
                                                            columnNumber: 41
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].marketSubtitle,
                                                            children: market.event_ticker
                                                        }, void 0, false, {
                                                            fileName: "[project]/web/components/MarketTable.tsx",
                                                            lineNumber: 271,
                                                            columnNumber: 41
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/web/components/MarketTable.tsx",
                                                    lineNumber: 269,
                                                    columnNumber: 37
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    children: market.volume.toLocaleString()
                                                }, void 0, false, {
                                                    fileName: "[project]/web/components/MarketTable.tsx",
                                                    lineNumber: 273,
                                                    columnNumber: 37
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].price,
                                                        children: [
                                                            market.yes_price,
                                                            "¢"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/web/components/MarketTable.tsx",
                                                        lineNumber: 275,
                                                        columnNumber: 41
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/web/components/MarketTable.tsx",
                                                    lineNumber: 274,
                                                    columnNumber: 37
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                        href: `/trade/${market.ticker}`,
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].detailsBtn,
                                                        children: [
                                                            "Details ",
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                                                size: 14
                                                            }, void 0, false, {
                                                                fileName: "[project]/web/components/MarketTable.tsx",
                                                                lineNumber: 279,
                                                                columnNumber: 53
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/web/components/MarketTable.tsx",
                                                        lineNumber: 278,
                                                        columnNumber: 41
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/web/components/MarketTable.tsx",
                                                    lineNumber: 277,
                                                    columnNumber: 37
                                                }, this)
                                            ]
                                        }, market.ticker, true, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 268,
                                            columnNumber: 33
                                        }, this)),
                                    displayedMarkets.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                            colSpan: 4,
                                            style: {
                                                textAlign: "center",
                                                padding: "2rem"
                                            },
                                            children: "No markets found"
                                        }, void 0, false, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 286,
                                            columnNumber: 41
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/web/components/MarketTable.tsx",
                                        lineNumber: 285,
                                        columnNumber: 37
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/web/components/MarketTable.tsx",
                                lineNumber: 266,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/web/components/MarketTable.tsx",
                        lineNumber: 257,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/web/components/MarketTable.tsx",
                    lineNumber: 251,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/web/components/MarketTable.tsx",
            lineNumber: 207,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/web/components/MarketTable.tsx",
        lineNumber: 206,
        columnNumber: 9
    }, this);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__20d7cfd7._.js.map