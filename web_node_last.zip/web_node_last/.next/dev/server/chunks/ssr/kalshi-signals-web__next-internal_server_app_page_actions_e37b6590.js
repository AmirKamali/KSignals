module.exports = [
"[project]/kalshi-signals-web/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=kalshi-signals-web__next-internal_server_app_page_actions_e37b6590.js.map