(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_62e13666._.js",
  "static/chunks/2374f_next_dist_compiled_react-dom_7b1e232c._.js",
  "static/chunks/2374f_next_dist_compiled_react-server-dom-turbopack_496a8291._.js",
  "static/chunks/2374f_next_dist_compiled_next-devtools_index_efe65cca.js",
  "static/chunks/2374f_next_dist_compiled_6e130f56._.js",
  "static/chunks/2374f_next_dist_client_fccbc5ca._.js",
  "static/chunks/2374f_next_dist_8009b5af._.js",
  "static/chunks/2374f_@swc_helpers_cjs_27b24b4b._.js"
],
    source: "entry"
});
