(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/web/components/HeroSection.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "actions": "HeroSection-module__suLlPW__actions",
  "backgroundEffects": "HeroSection-module__suLlPW__backgroundEffects",
  "badge": "HeroSection-module__suLlPW__badge",
  "badgeDot": "HeroSection-module__suLlPW__badgeDot",
  "badgeText": "HeroSection-module__suLlPW__badgeText",
  "benefitsList": "HeroSection-module__suLlPW__benefitsList",
  "benefitsTitle": "HeroSection-module__suLlPW__benefitsTitle",
  "bulletList": "HeroSection-module__suLlPW__bulletList",
  "content": "HeroSection-module__suLlPW__content",
  "fadeInDown": "HeroSection-module__suLlPW__fadeInDown",
  "fadeInUp": "HeroSection-module__suLlPW__fadeInUp",
  "featureCard": "HeroSection-module__suLlPW__featureCard",
  "featureGrid": "HeroSection-module__suLlPW__featureGrid",
  "featurePanel": "HeroSection-module__suLlPW__featurePanel",
  "float": "HeroSection-module__suLlPW__float",
  "glowPrimary": "HeroSection-module__suLlPW__glowPrimary",
  "glowSecondary": "HeroSection-module__suLlPW__glowSecondary",
  "gridPattern": "HeroSection-module__suLlPW__gridPattern",
  "hero": "HeroSection-module__suLlPW__hero",
  "iconWrapper": "HeroSection-module__suLlPW__iconWrapper",
  "layout": "HeroSection-module__suLlPW__layout",
  "metaRow": "HeroSection-module__suLlPW__metaRow",
  "panelHeader": "HeroSection-module__suLlPW__panelHeader",
  "panelLabel": "HeroSection-module__suLlPW__panelLabel",
  "panelStatus": "HeroSection-module__suLlPW__panelStatus",
  "panelSubtext": "HeroSection-module__suLlPW__panelSubtext",
  "pill": "HeroSection-module__suLlPW__pill",
  "pillGroup": "HeroSection-module__suLlPW__pillGroup",
  "positive": "HeroSection-module__suLlPW__positive",
  "previewDelta": "HeroSection-module__suLlPW__previewDelta",
  "previewGrid": "HeroSection-module__suLlPW__previewGrid",
  "previewHeader": "HeroSection-module__suLlPW__previewHeader",
  "previewItem": "HeroSection-module__suLlPW__previewItem",
  "previewLabel": "HeroSection-module__suLlPW__previewLabel",
  "previewMeta": "HeroSection-module__suLlPW__previewMeta",
  "previewPanel": "HeroSection-module__suLlPW__previewPanel",
  "previewSub": "HeroSection-module__suLlPW__previewSub",
  "previewTag": "HeroSection-module__suLlPW__previewTag",
  "previewTitle": "HeroSection-module__suLlPW__previewTitle",
  "pulse": "HeroSection-module__suLlPW__pulse",
  "statCard": "HeroSection-module__suLlPW__statCard",
  "statLabel": "HeroSection-module__suLlPW__statLabel",
  "statRow": "HeroSection-module__suLlPW__statRow",
  "statValue": "HeroSection-module__suLlPW__statValue",
  "statusDot": "HeroSection-module__suLlPW__statusDot",
  "subtitle": "HeroSection-module__suLlPW__subtitle",
  "title": "HeroSection-module__suLlPW__title",
});
}),
"[project]/web/components/HeroSection.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HeroSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__ = __turbopack_context__.i("[project]/web/node_modules/lucide-react/dist/esm/icons/arrow-right.js [app-client] (ecmascript) <export default as ArrowRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/web/components/HeroSection.module.css [app-client] (css module)");
"use client";
;
;
;
;
function HeroSection() {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(14);
    if ($[0] !== "e5118b8be2d1b9cbb7ab77d09d5f3583b3c78942f5f4b4dc6ba2e9db961995ac") {
        for(let $i = 0; $i < 14; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "e5118b8be2d1b9cbb7ab77d09d5f3583b3c78942f5f4b4dc6ba2e9db961995ac";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].backgroundEffects,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].gridPattern
                }, void 0, false, {
                    fileName: "[project]/web/components/HeroSection.tsx",
                    lineNumber: 16,
                    columnNumber: 52
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].glowPrimary
                }, void 0, false, {
                    fileName: "[project]/web/components/HeroSection.tsx",
                    lineNumber: 16,
                    columnNumber: 90
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].glowSecondary
                }, void 0, false, {
                    fileName: "[project]/web/components/HeroSection.tsx",
                    lineNumber: 16,
                    columnNumber: 128
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/web/components/HeroSection.tsx",
            lineNumber: 16,
            columnNumber: 10
        }, this);
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].badge,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].badgeDot
                }, void 0, false, {
                    fileName: "[project]/web/components/HeroSection.tsx",
                    lineNumber: 23,
                    columnNumber: 40
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].badgeText,
                    children: "Live Market Signals Active"
                }, void 0, false, {
                    fileName: "[project]/web/components/HeroSection.tsx",
                    lineNumber: 23,
                    columnNumber: 76
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/web/components/HeroSection.tsx",
            lineNumber: 23,
            columnNumber: 10
        }, this);
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    let t2;
    let t3;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].title,
            children: [
                "Trade on ",
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-gradient",
                    children: "Real World"
                }, void 0, false, {
                    fileName: "[project]/web/components/HeroSection.tsx",
                    lineNumber: 31,
                    columnNumber: 48
                }, this),
                " Events"
            ]
        }, void 0, true, {
            fileName: "[project]/web/components/HeroSection.tsx",
            lineNumber: 31,
            columnNumber: 10
        }, this);
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].subtitle,
            children: "Access AI-powered insights and probability analysis for the first regulated exchange dedicated to trading event outcomes."
        }, void 0, false, {
            fileName: "[project]/web/components/HeroSection.tsx",
            lineNumber: 32,
            columnNumber: 10
        }, this);
        $[3] = t2;
        $[4] = t3;
    } else {
        t2 = $[3];
        t3 = $[4];
    }
    let t4;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].metaRow,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].pillGroup,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].pill,
                        children: "AI probability shifts"
                    }, void 0, false, {
                        fileName: "[project]/web/components/HeroSection.tsx",
                        lineNumber: 41,
                        columnNumber: 76
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].pill,
                        children: "Order book pressure"
                    }, void 0, false, {
                        fileName: "[project]/web/components/HeroSection.tsx",
                        lineNumber: 41,
                        columnNumber: 134
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].pill,
                        children: "Headline-aware signals"
                    }, void 0, false, {
                        fileName: "[project]/web/components/HeroSection.tsx",
                        lineNumber: 41,
                        columnNumber: 190
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/web/components/HeroSection.tsx",
                lineNumber: 41,
                columnNumber: 42
            }, this)
        }, void 0, false, {
            fileName: "[project]/web/components/HeroSection.tsx",
            lineNumber: 41,
            columnNumber: 10
        }, this);
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    let t5;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].actions,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    className: "btn btn-primary",
                    children: [
                        "Start Trading ",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                            size: 18,
                            style: {
                                marginLeft: "0.5rem"
                            }
                        }, void 0, false, {
                            fileName: "[project]/web/components/HeroSection.tsx",
                            lineNumber: 48,
                            columnNumber: 92
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/web/components/HeroSection.tsx",
                    lineNumber: 48,
                    columnNumber: 42
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    className: "btn btn-outline",
                    children: "View All Markets"
                }, void 0, false, {
                    fileName: "[project]/web/components/HeroSection.tsx",
                    lineNumber: 50,
                    columnNumber: 23
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/web/components/HeroSection.tsx",
            lineNumber: 48,
            columnNumber: 10
        }, this);
        $[6] = t5;
    } else {
        t5 = $[6];
    }
    let t6;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].statCard,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].statValue,
                    children: "120+"
                }, void 0, false, {
                    fileName: "[project]/web/components/HeroSection.tsx",
                    lineNumber: 57,
                    columnNumber: 43
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].statLabel,
                    children: "Markets tracked live"
                }, void 0, false, {
                    fileName: "[project]/web/components/HeroSection.tsx",
                    lineNumber: 57,
                    columnNumber: 87
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/web/components/HeroSection.tsx",
            lineNumber: 57,
            columnNumber: 10
        }, this);
        $[7] = t6;
    } else {
        t6 = $[7];
    }
    let t7;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].statCard,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].statValue,
                    children: "93%"
                }, void 0, false, {
                    fileName: "[project]/web/components/HeroSection.tsx",
                    lineNumber: 64,
                    columnNumber: 43
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].statLabel,
                    children: "Signal coverage on volume"
                }, void 0, false, {
                    fileName: "[project]/web/components/HeroSection.tsx",
                    lineNumber: 64,
                    columnNumber: 86
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/web/components/HeroSection.tsx",
            lineNumber: 64,
            columnNumber: 10
        }, this);
        $[8] = t7;
    } else {
        t7 = $[8];
    }
    let t8;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].statRow,
            children: [
                t6,
                t7,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].statCard,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].statValue,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].positive,
                                children: "+7.2%"
                            }, void 0, false, {
                                fileName: "[project]/web/components/HeroSection.tsx",
                                lineNumber: 71,
                                columnNumber: 117
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/web/components/HeroSection.tsx",
                            lineNumber: 71,
                            columnNumber: 83
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].statLabel,
                            children: "Avg. edge vs. raw order book"
                        }, void 0, false, {
                            fileName: "[project]/web/components/HeroSection.tsx",
                            lineNumber: 71,
                            columnNumber: 169
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/web/components/HeroSection.tsx",
                    lineNumber: 71,
                    columnNumber: 50
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/web/components/HeroSection.tsx",
            lineNumber: 71,
            columnNumber: 10
        }, this);
        $[9] = t8;
    } else {
        t8 = $[9];
    }
    let t9;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].previewHeader,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].previewLabel,
                            children: "Signal preview"
                        }, void 0, false, {
                            fileName: "[project]/web/components/HeroSection.tsx",
                            lineNumber: 78,
                            columnNumber: 53
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].previewSub,
                            children: "Micro-moves we are watching right now"
                        }, void 0, false, {
                            fileName: "[project]/web/components/HeroSection.tsx",
                            lineNumber: 78,
                            columnNumber: 110
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/web/components/HeroSection.tsx",
                    lineNumber: 78,
                    columnNumber: 48
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].previewTag,
                    children: "Live feed"
                }, void 0, false, {
                    fileName: "[project]/web/components/HeroSection.tsx",
                    lineNumber: 78,
                    columnNumber: 194
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/web/components/HeroSection.tsx",
            lineNumber: 78,
            columnNumber: 10
        }, this);
        $[10] = t9;
    } else {
        t9 = $[10];
    }
    let t10;
    if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].previewItem,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].previewTitle,
                    children: "Election turnout"
                }, void 0, false, {
                    fileName: "[project]/web/components/HeroSection.tsx",
                    lineNumber: 85,
                    columnNumber: 47
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].previewMeta,
                    children: "Yes probability 58%"
                }, void 0, false, {
                    fileName: "[project]/web/components/HeroSection.tsx",
                    lineNumber: 85,
                    columnNumber: 106
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].previewDelta,
                    children: "+2.3% in last hour"
                }, void 0, false, {
                    fileName: "[project]/web/components/HeroSection.tsx",
                    lineNumber: 85,
                    columnNumber: 167
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/web/components/HeroSection.tsx",
            lineNumber: 85,
            columnNumber: 11
        }, this);
        $[11] = t10;
    } else {
        t10 = $[11];
    }
    let t11;
    if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].previewItem,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].previewTitle,
                    children: "Rate cut by June"
                }, void 0, false, {
                    fileName: "[project]/web/components/HeroSection.tsx",
                    lineNumber: 92,
                    columnNumber: 47
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].previewMeta,
                    children: "Order book leaning NO"
                }, void 0, false, {
                    fileName: "[project]/web/components/HeroSection.tsx",
                    lineNumber: 92,
                    columnNumber: 106
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].previewDelta,
                    children: "Spread tightening"
                }, void 0, false, {
                    fileName: "[project]/web/components/HeroSection.tsx",
                    lineNumber: 92,
                    columnNumber: 169
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/web/components/HeroSection.tsx",
            lineNumber: 92,
            columnNumber: 11
        }, this);
        $[12] = t11;
    } else {
        t11 = $[12];
    }
    let t12;
    if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].hero,
            children: [
                t0,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].layout,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].content,
                            children: [
                                t1,
                                t2,
                                t3,
                                t4,
                                t5,
                                t8,
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].previewPanel,
                                    children: [
                                        t9,
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].previewGrid,
                                            children: [
                                                t10,
                                                t11,
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].previewItem,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].previewTitle,
                                                            children: "Weekly jobless claims"
                                                        }, void 0, false, {
                                                            fileName: "[project]/web/components/HeroSection.tsx",
                                                            lineNumber: 99,
                                                            columnNumber: 285
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].previewMeta,
                                                            children: "Signal confidence High"
                                                        }, void 0, false, {
                                                            fileName: "[project]/web/components/HeroSection.tsx",
                                                            lineNumber: 99,
                                                            columnNumber: 349
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$HeroSection$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].previewDelta,
                                                            children: "Volatility watchlist"
                                                        }, void 0, false, {
                                                            fileName: "[project]/web/components/HeroSection.tsx",
                                                            lineNumber: 99,
                                                            columnNumber: 413
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/web/components/HeroSection.tsx",
                                                    lineNumber: 99,
                                                    columnNumber: 249
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/web/components/HeroSection.tsx",
                                            lineNumber: 99,
                                            columnNumber: 203
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/web/components/HeroSection.tsx",
                                    lineNumber: 99,
                                    columnNumber: 162
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/web/components/HeroSection.tsx",
                            lineNumber: 99,
                            columnNumber: 106
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/web/components/HeroSection.tsx",
                        lineNumber: 99,
                        columnNumber: 75
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/web/components/HeroSection.tsx",
                    lineNumber: 99,
                    columnNumber: 48
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/web/components/HeroSection.tsx",
            lineNumber: 99,
            columnNumber: 11
        }, this);
        $[13] = t12;
    } else {
        t12 = $[13];
    }
    return t12;
}
_c = HeroSection;
var _c;
__turbopack_context__.k.register(_c, "HeroSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/web/lib/kalshi.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getBackendMarkets",
    ()=>getBackendMarkets,
    "getHighVolumeMarkets",
    ()=>getHighVolumeMarkets,
    "getMarketDetails",
    ()=>getMarketDetails,
    "getMarketsBySeries",
    ()=>getMarketsBySeries,
    "getOrderBook",
    ()=>getOrderBook,
    "getSeriesByCategory",
    ()=>getSeriesByCategory,
    "getSeriesByTags",
    ()=>getSeriesByTags,
    "getTagsByCategories",
    ()=>getTagsByCategories
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/web/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const BACKEND_BASE_URL = __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.BACKEND_API_BASE_URL ?? "http://localhost:3006";
const KALSHI_BASE_URL = "https://api.elections.kalshi.com/trade-api/v2";
async function getHighVolumeMarkets(limit = 100) {
    const backend = await getBackendMarkets({
        pageSize: limit
    });
    if (backend.markets.length > 0) {
        return backend.markets.sort((a, b)=>b.volume - a.volume).slice(0, limit);
    }
    // Fallback to Kalshi directly if backend is unavailable
    try {
        const response = await fetch(`${KALSHI_BASE_URL}/markets?limit=${limit}&status=open`, {
            next: {
                revalidate: 60
            }
        });
        if (!response.ok) {
            console.warn(`Kalshi API returned ${response.status}`);
            return [];
        }
        const data = await response.json();
        const markets = data.markets || [];
        return markets.sort((a, b)=>b.volume - a.volume).slice(0, limit);
    } catch (error) {
        console.warn("Fallback fetch from Kalshi failed:", error);
        return [];
    }
}
async function getMarketsBySeries(seriesTicker, maxCloseTs = null) {
    try {
        let url = `${KALSHI_BASE_URL}/markets?series_ticker=${seriesTicker}&status=open`;
        if (maxCloseTs) {
            url += `&max_close_ts=${maxCloseTs}`;
        }
        const controller = new AbortController();
        const timeoutId = setTimeout(()=>controller.abort(), 10000); // 10 second timeout
        const response = await fetch(url, {
            signal: controller.signal,
            next: {
                revalidate: 60
            }
        });
        clearTimeout(timeoutId);
        if (!response.ok) {
            console.warn(`API returned ${response.status} for series ${seriesTicker}`);
            return [];
        }
        const data = await response.json();
        return data.markets || [];
    } catch (error) {
        if (error instanceof Error && error.name === 'AbortError') {
            console.error(`Request timeout for series ${seriesTicker}`);
        } else {
            console.error(`Error fetching series ${seriesTicker}:`, error);
        }
        return [];
    }
}
async function getTagsByCategories() {
    try {
        const response = await fetch(`${BACKEND_BASE_URL}/api/events/categories`, {
            next: {
                revalidate: 300
            }
        });
        if (!response.ok) {
            console.warn(`Backend tags response ${response.status}`);
            throw new Error("Failed to fetch tags");
        }
        const data = await response.json();
        const tags = data.tagsByCategories || data.tags_by_categories;
        return tags || {};
    } catch (error) {
        console.warn("Error fetching tags from backend, using defaults:", error);
        return {
            "Economics": [
                "Interest Rates",
                "Inflation",
                "GDP"
            ],
            "Politics": [
                "Elections",
                "Policy"
            ],
            "Technology": [
                "AI",
                "Hardware"
            ],
            "Other": []
        };
    }
}
async function getSeriesByTags(tags) {
    try {
        const response = await fetch(`${KALSHI_BASE_URL}/series?tags=${tags}`);
        if (!response.ok) return [];
        const data = await response.json();
        return data.series || [];
    } catch (error) {
        console.error(`Error fetching series for tags ${tags}:`, error);
        return [];
    }
}
async function getSeriesByCategory(category) {
    try {
        const res = await fetch(`${KALSHI_BASE_URL}/series?series_category=${encodeURIComponent(category)}`);
        if (!res.ok) return [];
        const data = await res.json();
        return data.series || [];
    } catch (error) {
        console.error(`Error fetching series for category ${category}:`, error);
        return [];
    }
}
async function getMarketDetails(ticker) {
    try {
        const response = await fetch(`${KALSHI_BASE_URL}/markets/${ticker}`);
        if (!response.ok) return null;
        const data = await response.json();
        return data.market;
    } catch (error) {
        console.error(`Error fetching market ${ticker}:`, error);
        return null;
    }
}
async function getOrderBook(ticker) {
    try {
        const response = await fetch(`${KALSHI_BASE_URL}/markets/${ticker}/orderbook`);
        if (!response.ok) return null;
        const data = await response.json();
        return data.orderbook;
    } catch (error) {
        console.error(`Error fetching orderbook for ${ticker}:`, error);
        return null;
    }
}
async function getBackendMarkets(params) {
    // Use Next.js API route for client-side calls, direct backend for server-side
    const isServer = ("TURBOPACK compile-time value", "object") === 'undefined';
    const baseUrl = ("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : '';
    const endpoint = ("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : '/api/markets';
    const url = new URL(endpoint, ("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : window.location.origin);
    if (params?.category) url.searchParams.set("category", params.category);
    if (params?.tag) url.searchParams.set("tag", params.tag);
    // Default to next 30 days when no filter is provided; allow explicit null to mean all_time
    const closeDateType = params?.close_date_type === undefined ? "next_30_days" : params.close_date_type;
    if (closeDateType) url.searchParams.set("close_date_type", closeDateType);
    if (params?.query) url.searchParams.set("query", params.query);
    url.searchParams.set("sort_type", params?.sort ?? "volume");
    url.searchParams.set("direction", params?.direction ?? "desc");
    if (params?.page && params.page > 1) url.searchParams.set("page", params.page.toString());
    if (params?.pageSize) url.searchParams.set("pageSize", params.pageSize.toString());
    try {
        const response = await fetch(url.toString(), {
            cache: 'no-store'
        });
        if (!response.ok) {
            console.warn(`Backend markets response ${response.status}`);
            return {
                markets: [],
                totalPages: 0,
                totalCount: 0,
                currentPage: params?.page ?? 1,
                pageSize: params?.pageSize ?? 50
            };
        }
        const data = await response.json();
        const markets = (data.markets || []).map(normalizeBackendMarket);
        const totalPages = Number(data.totalPages ?? 0);
        const totalCount = Number(data.count ?? markets.length);
        const currentPage = Number(data.currentPage ?? params?.page ?? 1);
        const pageSize = Number(data.pageSize ?? params?.pageSize ?? 50);
        return {
            markets,
            totalPages,
            totalCount,
            currentPage,
            pageSize,
            sort: data.sort_type ?? data.sort ?? params?.sort ?? "volume",
            direction: data.direction ?? params?.direction ?? "desc"
        };
    } catch (error) {
        console.warn("Falling back: unable to fetch backend markets", error instanceof Error ? error.message : error);
        return {
            markets: [],
            totalPages: 0,
            totalCount: 0,
            currentPage: params?.page ?? 1,
            pageSize: params?.pageSize ?? 50
        };
    }
}
function normalizeBackendMarket(raw) {
    const ticker = raw.tickerId ?? raw.ticker;
    const seriesTicker = raw.seriesTicker ?? raw.eventTicker ?? ticker;
    // Prefer lastPrice over yesBid as yesBid is often 0
    const lastPrice = raw.lastPrice;
    const noBid = raw.noBid ?? raw.no_price ?? raw.noPrice;
    const noAsk = raw.noAsk ?? raw.no_ask;
    const noPrice = noBid ?? noAsk;
    const yesBid = raw.yesBid ?? raw.yes_price ?? raw.yesPrice;
    const yesPrice = lastPrice ?? yesBid ?? (typeof noPrice === "number" ? Math.max(0, 100 - noPrice) : 0);
    const previousYesPrice = raw.previousPrice ?? raw.previousYesBid ?? raw.previous_yes_price ?? raw.previous_yes_bid;
    const previousNoPrice = raw.previousNoBid ?? raw.previous_no_price ?? raw.previous_no_bid ?? (typeof previousYesPrice === "number" ? 100 - previousYesPrice : undefined);
    const liquidity = raw.liquidity;
    const volume = raw.volume;
    const closeTime = raw.closeTime ?? raw.close_time;
    return {
        ticker: ticker ?? "",
        event_ticker: seriesTicker ?? "",
        title: raw.title ?? "",
        subtitle: raw.subtitle ?? "",
        yes_price: yesPrice,
        no_price: noPrice ?? (typeof yesPrice === "number" ? Math.max(0, 100 - yesPrice) : undefined),
        previous_yes_price: previousYesPrice,
        previous_no_price: previousNoPrice,
        volume: volume ?? 0,
        open_interest: liquidity ?? 0,
        liquidity: liquidity ?? 0,
        status: raw.status ?? "",
        category: raw.category ?? seriesTicker ?? "",
        close_time: closeTime,
        closeTime: closeTime
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/web/components/FormattedTitle.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
;
function escapeHtml(text) {
    return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function applyInlineFormatting(text) {
    // Apply minimal markdown-style formatting and strip the markers
    return text.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>").replace(/__(.+?)__/g, "<strong>$1</strong>").replace(/\*(.+?)\*/g, "<em>$1</em>").replace(/_(.+?)_/g, "<em>$1</em>").replace(/`(.+?)`/g, "<code>$1</code>");
}
function FormattedTitle(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(5);
    if ($[0] !== "0c32fb5359bd55fd10903674914b225a88b64cbec7b9e7f647eecc9160d0b301") {
        for(let $i = 0; $i < 5; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "0c32fb5359bd55fd10903674914b225a88b64cbec7b9e7f647eecc9160d0b301";
    }
    const { text } = t0;
    let t1;
    if ($[1] !== text) {
        t1 = applyInlineFormatting(escapeHtml(text));
        $[1] = text;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const html = t1;
    let t2;
    if ($[3] !== html) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            dangerouslySetInnerHTML: {
                __html: html
            }
        }, void 0, false, {
            fileName: "[project]/web/components/FormattedTitle.tsx",
            lineNumber: 35,
            columnNumber: 10
        }, this);
        $[3] = html;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    return t2;
}
_c = FormattedTitle;
const __TURBOPACK__default__export__ = /*#__PURE__*/ _c1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"])(FormattedTitle);
var _c, _c1;
__turbopack_context__.k.register(_c, "FormattedTitle");
__turbopack_context__.k.register(_c1, "%default%");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/web/components/MarketTable.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "active": "MarketTable-module__CHRjXG__active",
  "calendarIcon": "MarketTable-module__CHRjXG__calendarIcon",
  "clearButton": "MarketTable-module__CHRjXG__clearButton",
  "controls": "MarketTable-module__CHRjXG__controls",
  "dateApply": "MarketTable-module__CHRjXG__dateApply",
  "dateFilterContainer": "MarketTable-module__CHRjXG__dateFilterContainer",
  "dateSelect": "MarketTable-module__CHRjXG__dateSelect",
  "delta": "MarketTable-module__CHRjXG__delta",
  "filterContainer": "MarketTable-module__CHRjXG__filterContainer",
  "loadingState": "MarketTable-module__CHRjXG__loadingState",
  "marketSubtitle": "MarketTable-module__CHRjXG__marketSubtitle",
  "marketTitle": "MarketTable-module__CHRjXG__marketTitle",
  "noPrice": "MarketTable-module__CHRjXG__noPrice",
  "pageButton": "MarketTable-module__CHRjXG__pageButton",
  "pageIndicator": "MarketTable-module__CHRjXG__pageIndicator",
  "pagination": "MarketTable-module__CHRjXG__pagination",
  "price": "MarketTable-module__CHRjXG__price",
  "priceCell": "MarketTable-module__CHRjXG__priceCell",
  "searchBar": "MarketTable-module__CHRjXG__searchBar",
  "searchButton": "MarketTable-module__CHRjXG__searchButton",
  "searchIcon": "MarketTable-module__CHRjXG__searchIcon",
  "searchInput": "MarketTable-module__CHRjXG__searchInput",
  "section": "MarketTable-module__CHRjXG__section",
  "segmentBtn": "MarketTable-module__CHRjXG__segmentBtn",
  "sortActive": "MarketTable-module__CHRjXG__sortActive",
  "sortButton": "MarketTable-module__CHRjXG__sortButton",
  "sortIcon": "MarketTable-module__CHRjXG__sortIcon",
  "spin": "MarketTable-module__CHRjXG__spin",
  "table": "MarketTable-module__CHRjXG__table",
  "tableContainer": "MarketTable-module__CHRjXG__tableContainer",
  "titleCell": "MarketTable-module__CHRjXG__titleCell",
  "titleLink": "MarketTable-module__CHRjXG__titleLink",
  "trend": "MarketTable-module__CHRjXG__trend",
  "trendDown": "MarketTable-module__CHRjXG__trendDown",
  "trendIcon": "MarketTable-module__CHRjXG__trendIcon",
  "trendUp": "MarketTable-module__CHRjXG__trendUp",
});
}),
"[project]/web/components/MarketTable.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MarketTable
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__ = __turbopack_context__.i("[project]/web/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-client] (ecmascript) <export default as Loader2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__ = __turbopack_context__.i("[project]/web/node_modules/lucide-react/dist/esm/icons/calendar.js [app-client] (ecmascript) <export default as Calendar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$triangle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Triangle$3e$__ = __turbopack_context__.i("[project]/web/node_modules/lucide-react/dist/esm/icons/triangle.js [app-client] (ecmascript) <export default as Triangle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__ = __turbopack_context__.i("[project]/web/node_modules/lucide-react/dist/esm/icons/search.js [app-client] (ecmascript) <export default as Search>");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$kalshi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/lib/kalshi.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$FormattedTitle$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/web/components/FormattedTitle.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/web/components/MarketTable.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
const PAGE_SIZE = 20;
function formatCloseTime(closeTime) {
    if (!closeTime) return "Close time unavailable";
    const close = new Date(closeTime);
    if (Number.isNaN(close.getTime())) return "Close time unavailable";
    const now = new Date();
    const diffMs = close.getTime() - now.getTime();
    const absMinutes = Math.max(1, Math.round(Math.abs(diffMs) / (1000 * 60)));
    let value = absMinutes;
    let unit = "minutes";
    if (absMinutes >= 60) {
        const hours = Math.round(absMinutes / 60);
        if (hours < 48) {
            value = hours;
            unit = hours === 1 ? "hour" : "hours";
        } else {
            const days = Math.round(hours / 24);
            value = days;
            unit = days === 1 ? "day" : "days";
        }
    } else if (absMinutes === 1) {
        unit = "minute";
    }
    if (diffMs >= 0) {
        return `Close time in ${value} ${unit}`;
    }
    return `Closed ${value} ${unit} ago`;
}
function getTrendInfo(current, previous) {
    if (current === undefined || current === null) return null;
    if (previous === undefined || previous === null) return null;
    const diff = current - previous;
    if (!Number.isFinite(diff)) return null;
    if (diff === 0) {
        return {
            direction: "flat",
            diff
        };
    }
    return {
        direction: diff > 0 ? "up" : "down",
        diff
    };
}
function formatDelta(diff) {
    const abs = Math.abs(diff);
    if (abs >= 1) {
        return Math.round(abs).toString();
    }
    return abs.toFixed(2);
}
function MarketTable({ markets: initialMarkets, tagsByCategories }) {
    _s();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const { replace } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const initialCategory = searchParams.get("category") || "All";
    const initialTag = searchParams.get("tag");
    const initialDate = searchParams.get("date") || "next_30_days";
    const initialSort = searchParams.get("sort_type") || "volume";
    const initialDirection = searchParams.get("direction") || "desc";
    const initialPage = Math.max(1, parseInt(searchParams.get("page") || "1", 10));
    const initialPageSize = Math.max(1, parseInt(searchParams.get("pageSize") || `${PAGE_SIZE}`, 10));
    const initialQuery = searchParams.get("query") || "";
    const [activeCategory, setActiveCategory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialCategory);
    const [activeSubTag, setActiveSubTag] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialTag);
    const [activeDate, setActiveDate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialDate);
    const [activeSort, setActiveSort] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialSort);
    const [sortDirection, setSortDirection] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialDirection);
    const [currentPage, setCurrentPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialPage);
    const [pageSize] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialPageSize);
    const [totalPages, setTotalPages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const [totalCount, setTotalCount] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [searchValue, setSearchValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialQuery);
    const [activeQuery, setActiveQuery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialQuery);
    // Initialize displayed markets based on synchronous category filtering
    // Only use initialMarkets fallback if we are on "All" or if we want to show *something* while fetching
    // But since we are moving to async fetching for categories too, we might want to start with empty or initial if matches.
    const [displayedMarkets, setDisplayedMarkets] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "MarketTable.useState": ()=>{
            if (initialCategory === "All") {
                return initialMarkets;
            }
            // If category is set but no tag, we initially show fallback filtering 
            // until the async fetch completes (handled in useEffect).
            // This provides better UX than empty table.
            return initialMarkets.filter({
                "MarketTable.useState": (m)=>m.category === initialCategory || !m.category && initialCategory === "Other"
            }["MarketTable.useState"]);
        }
    }["MarketTable.useState"]);
    // We are loading if there is a tag OR a category (that is not All) because now we fetch for categories too
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const categories = [
        "All",
        ...Object.keys(tagsByCategories).sort()
    ];
    const fetchMarkets = (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "MarketTable.useCallback[fetchMarkets]": async (category, tag, query, dateFilter, sort, direction, page, size)=>{
            setIsLoading(true);
            try {
                const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$lib$2f$kalshi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getBackendMarkets"])({
                    category: category !== "All" ? category : null,
                    tag,
                    query: query && query.trim().length > 0 ? query : null,
                    close_date_type: dateFilter !== "all_time" ? dateFilter : null,
                    sort,
                    direction,
                    page,
                    pageSize: size
                });
                setDisplayedMarkets(response.markets);
                setTotalPages(Math.max(1, response.totalPages || 1));
                setTotalCount(response.totalCount || response.markets.length);
                setCurrentPage(response.currentPage || 1);
                setActiveSort(response.sort || sort);
                setSortDirection(response.direction || direction);
            } catch (error) {
                console.error("Error loading markets:", error);
                // Fallback to local filtering if fetch fails
                if (!tag && category !== "All") {
                    const filtered = initialMarkets.filter({
                        "MarketTable.useCallback[fetchMarkets].filtered": (m_0)=>m_0.category === category || !m_0.category && category === "Other"
                    }["MarketTable.useCallback[fetchMarkets].filtered"]);
                    setDisplayedMarkets(filtered);
                    setTotalPages(1);
                    setTotalCount(filtered.length);
                } else {
                    setTotalPages(1);
                    setTotalCount(initialMarkets.length);
                }
            } finally{
                setIsLoading(false);
            }
        }
    }["MarketTable.useCallback[fetchMarkets]"], [
        initialMarkets
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "MarketTable.useEffect": ()=>{
            const cat = searchParams.get("category") || "All";
            const tag_0 = searchParams.get("tag");
            const date = searchParams.get("date") || "next_30_days";
            const sort_0 = searchParams.get("sort_type") || "volume";
            const direction_0 = searchParams.get("direction") || "desc";
            const page_0 = Math.max(1, parseInt(searchParams.get("page") || "1", 10));
            const size_0 = Math.max(1, parseInt(searchParams.get("pageSize") || `${pageSize}`, 10));
            const query_0 = searchParams.get("query") || "";
            setActiveCategory(cat);
            setActiveSubTag(tag_0);
            setActiveDate(date);
            setActiveSort(sort_0);
            setSortDirection(direction_0);
            setCurrentPage(page_0);
            setActiveQuery(query_0);
            setSearchValue(query_0);
            fetchMarkets(cat, tag_0, query_0, date, sort_0, direction_0, page_0, size_0);
        }
    }["MarketTable.useEffect"], [
        searchParams,
        fetchMarkets,
        pageSize
    ]);
    const updateUrl = (newCategory, newTag, newDate, options)=>{
        const params = new URLSearchParams(searchParams);
        if (newCategory && newCategory !== "All") {
            params.set("category", newCategory);
        } else {
            params.delete("category");
        }
        if (newTag) {
            params.set("tag", newTag);
        } else {
            params.delete("tag");
        }
        const dateToUse = newDate !== undefined ? newDate : activeDate;
        if (dateToUse && dateToUse !== "all_time") {
            params.set("date", dateToUse);
        } else {
            params.delete("date");
        }
        const sortToUse = options?.sort ?? activeSort;
        const directionToUse = options?.direction ?? sortDirection;
        const pageToUse = options?.resetPage ? 1 : options?.page ?? currentPage;
        const queryToUse = options && "query" in options ? options.query : activeQuery;
        params.set("sort_type", sortToUse);
        params.set("direction", directionToUse);
        if (pageToUse && pageToUse > 1) {
            params.set("page", String(pageToUse));
        } else {
            params.delete("page");
        }
        if (pageSize && pageSize !== PAGE_SIZE) {
            params.set("pageSize", String(pageSize));
        } else {
            params.delete("pageSize");
        }
        if (queryToUse && queryToUse.trim().length > 0) {
            params.set("query", queryToUse.trim());
        } else {
            params.delete("query");
        }
        replace(`${pathname}?${params.toString()}`, {
            scroll: false
        });
    };
    const handleCategoryClick = (cat_0)=>{
        // When category changes, clear the tag
        updateUrl(cat_0, null, undefined, {
            resetPage: true
        });
    };
    const handleSubTagClick = (tag_1)=>{
        updateUrl(activeCategory, tag_1, undefined, {
            resetPage: true
        });
    };
    const handleDateChange = (date_0)=>{
        updateUrl(activeCategory, activeSubTag, date_0, {
            resetPage: true
        });
    };
    const handleSortClick = (sort_1)=>{
        const nextDirection = sort_1 === activeSort && sortDirection === "desc" ? "asc" : "desc";
        setActiveSort(sort_1);
        setSortDirection(nextDirection);
        setCurrentPage(1);
        updateUrl(activeCategory, activeSubTag, undefined, {
            sort: sort_1,
            direction: nextDirection,
            resetPage: true
        });
    };
    const handlePageChange = (page_1)=>{
        const safePage = Math.max(1, Math.min(page_1, totalPages));
        updateUrl(activeCategory, activeSubTag, undefined, {
            page: safePage
        });
    };
    const handleSearchSubmit = (event)=>{
        event.preventDefault();
        const trimmed = searchValue.trim();
        setActiveQuery(trimmed);
        setCurrentPage(1);
        updateUrl(activeCategory, activeSubTag, activeDate, {
            resetPage: true,
            query: trimmed.length > 0 ? trimmed : null
        });
    };
    const handleSearchClear = ()=>{
        setSearchValue("");
        setActiveQuery("");
        setCurrentPage(1);
        updateUrl(activeCategory, activeSubTag, activeDate, {
            resetPage: true,
            query: null
        });
    };
    const subTags = activeCategory !== "All" && tagsByCategories[activeCategory] ? tagsByCategories[activeCategory] : [];
    const dateOptions = [
        {
            value: "all_time",
            label: "All time"
        },
        {
            value: "next_24_hr",
            label: "Next 24 Hours"
        },
        {
            value: "next_48_hr",
            label: "Next 48 Hours"
        },
        {
            value: "next_7_days",
            label: "Next 7 Days"
        },
        {
            value: "next_30_days",
            label: "Next 30 Days"
        },
        {
            value: "next_90_days",
            label: "Next 90 Days"
        },
        {
            value: "this_year",
            label: "This Year"
        },
        {
            value: "next_year",
            label: "Next Year"
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].section,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].filterContainer,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].controls,
                            children: categories.map((cat_1)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].segmentBtn} ${activeCategory === cat_1 ? __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].active : ""}`,
                                    onClick: ()=>handleCategoryClick(cat_1),
                                    children: cat_1
                                }, cat_1, false, {
                                    fileName: "[project]/web/components/MarketTable.tsx",
                                    lineNumber: 304,
                                    columnNumber: 50
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/web/components/MarketTable.tsx",
                            lineNumber: 303,
                            columnNumber: 17
                        }, this),
                        subTags.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].controls,
                            children: subTags.map((tag_2)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].segmentBtn} ${activeSubTag === tag_2 ? __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].active : ""}`,
                                    onClick: ()=>handleSubTagClick(tag_2),
                                    children: tag_2
                                }, tag_2, false, {
                                    fileName: "[project]/web/components/MarketTable.tsx",
                                    lineNumber: 310,
                                    columnNumber: 51
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/web/components/MarketTable.tsx",
                            lineNumber: 309,
                            columnNumber: 44
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dateFilterContainer,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__["Calendar"], {
                                    size: 16,
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].calendarIcon
                                }, void 0, false, {
                                    fileName: "[project]/web/components/MarketTable.tsx",
                                    lineNumber: 316,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                    value: activeDate,
                                    onChange: (e)=>handleDateChange(e.target.value),
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dateSelect,
                                    children: dateOptions.map((option)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: option.value,
                                            children: option.label
                                        }, option.value, false, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 318,
                                            columnNumber: 56
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/web/components/MarketTable.tsx",
                                    lineNumber: 317,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/web/components/MarketTable.tsx",
                            lineNumber: 315,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/web/components/MarketTable.tsx",
                    lineNumber: 302,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].searchBar,
                    onSubmit: handleSearchSubmit,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__["Search"], {
                            size: 18,
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].searchIcon
                        }, void 0, false, {
                            fileName: "[project]/web/components/MarketTable.tsx",
                            lineNumber: 326,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            type: "text",
                            value: searchValue,
                            onChange: (e_0)=>setSearchValue(e_0.target.value),
                            placeholder: "Search markets by title or ticker",
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].searchInput
                        }, void 0, false, {
                            fileName: "[project]/web/components/MarketTable.tsx",
                            lineNumber: 327,
                            columnNumber: 21
                        }, this),
                        searchValue && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            onClick: handleSearchClear,
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].clearButton,
                            children: "Clear"
                        }, void 0, false, {
                            fileName: "[project]/web/components/MarketTable.tsx",
                            lineNumber: 328,
                            columnNumber: 37
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "submit",
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].searchButton,
                            children: "Search"
                        }, void 0, false, {
                            fileName: "[project]/web/components/MarketTable.tsx",
                            lineNumber: 331,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/web/components/MarketTable.tsx",
                    lineNumber: 325,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].tableContainer,
                    children: isLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].loadingState,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].spin,
                            size: 32
                        }, void 0, false, {
                            fileName: "[project]/web/components/MarketTable.tsx",
                            lineNumber: 338,
                            columnNumber: 29
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/web/components/MarketTable.tsx",
                        lineNumber: 337,
                        columnNumber: 34
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].table,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            children: "Market"
                                        }, void 0, false, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 342,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sortButton} ${activeSort === "volume" ? __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sortActive : ""}`,
                                                onClick: ()=>handleSortClick("volume"),
                                                "aria-label": `Sort by volume ${sortDirection === "desc" ? "descending" : "ascending"}`,
                                                children: [
                                                    "Volume",
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$triangle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Triangle$3e$__["Triangle"], {
                                                        size: 12,
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sortIcon,
                                                        style: sortDirection === "desc" ? undefined : {
                                                            transform: "rotate(180deg)"
                                                        }
                                                    }, void 0, false, {
                                                        fileName: "[project]/web/components/MarketTable.tsx",
                                                        lineNumber: 346,
                                                        columnNumber: 41
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/web/components/MarketTable.tsx",
                                                lineNumber: 344,
                                                columnNumber: 37
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 343,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            children: "Yes Price"
                                        }, void 0, false, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 351,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            children: "No Price"
                                        }, void 0, false, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 352,
                                            columnNumber: 33
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/web/components/MarketTable.tsx",
                                    lineNumber: 341,
                                    columnNumber: 29
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/web/components/MarketTable.tsx",
                                lineNumber: 340,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                children: [
                                    displayedMarkets.map((market, index)=>{
                                        const rowKey = market.ticker || market.event_ticker || `market-${index}`;
                                        const closeLabel = formatCloseTime(market.close_time || market.closeTime);
                                        const noPrice = market.no_price ?? Math.max(0, 100 - market.yes_price);
                                        const previousYes = market.previous_yes_price;
                                        const previousNo = market.previous_no_price ?? (typeof previousYes === "number" ? 100 - previousYes : undefined);
                                        const yesTrend = getTrendInfo(market.yes_price, previousYes);
                                        const noTrend = getTrendInfo(noPrice, previousNo);
                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].titleCell,
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                        href: `/trade/${market.ticker}`,
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].titleLink,
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].marketTitle,
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$FormattedTitle$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                    text: market.title
                                                                }, void 0, false, {
                                                                    fileName: "[project]/web/components/MarketTable.tsx",
                                                                    lineNumber: 368,
                                                                    columnNumber: 49
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/web/components/MarketTable.tsx",
                                                                lineNumber: 367,
                                                                columnNumber: 45
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].marketSubtitle,
                                                                children: closeLabel
                                                            }, void 0, false, {
                                                                fileName: "[project]/web/components/MarketTable.tsx",
                                                                lineNumber: 370,
                                                                columnNumber: 45
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/web/components/MarketTable.tsx",
                                                        lineNumber: 366,
                                                        columnNumber: 41
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/web/components/MarketTable.tsx",
                                                    lineNumber: 365,
                                                    columnNumber: 37
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    children: market.volume.toLocaleString()
                                                }, void 0, false, {
                                                    fileName: "[project]/web/components/MarketTable.tsx",
                                                    lineNumber: 373,
                                                    columnNumber: 37
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].priceCell,
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].price,
                                                                children: [
                                                                    market.yes_price,
                                                                    "¢"
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/web/components/MarketTable.tsx",
                                                                lineNumber: 376,
                                                                columnNumber: 45
                                                            }, this),
                                                            yesTrend && yesTrend.diff !== 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].trend} ${yesTrend.direction === "up" ? __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].trendUp : __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].trendDown}`,
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$triangle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Triangle$3e$__["Triangle"], {
                                                                        size: 10,
                                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].trendIcon,
                                                                        style: yesTrend.direction === "down" ? {
                                                                            transform: "rotate(180deg)"
                                                                        } : undefined
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/web/components/MarketTable.tsx",
                                                                        lineNumber: 378,
                                                                        columnNumber: 53
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].delta,
                                                                        children: [
                                                                            formatDelta(yesTrend.diff),
                                                                            "¢"
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/web/components/MarketTable.tsx",
                                                                        lineNumber: 381,
                                                                        columnNumber: 53
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/web/components/MarketTable.tsx",
                                                                lineNumber: 377,
                                                                columnNumber: 81
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/web/components/MarketTable.tsx",
                                                        lineNumber: 375,
                                                        columnNumber: 41
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/web/components/MarketTable.tsx",
                                                    lineNumber: 374,
                                                    columnNumber: 37
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].priceCell,
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].noPrice,
                                                                children: [
                                                                    noPrice,
                                                                    "¢"
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/web/components/MarketTable.tsx",
                                                                lineNumber: 387,
                                                                columnNumber: 45
                                                            }, this),
                                                            noTrend && noTrend.diff !== 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].trend} ${noTrend.direction === "up" ? __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].trendUp : __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].trendDown}`,
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$triangle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Triangle$3e$__["Triangle"], {
                                                                        size: 10,
                                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].trendIcon,
                                                                        style: noTrend.direction === "down" ? {
                                                                            transform: "rotate(180deg)"
                                                                        } : undefined
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/web/components/MarketTable.tsx",
                                                                        lineNumber: 389,
                                                                        columnNumber: 53
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].delta,
                                                                        children: [
                                                                            formatDelta(noTrend.diff),
                                                                            "¢"
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/web/components/MarketTable.tsx",
                                                                        lineNumber: 392,
                                                                        columnNumber: 53
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/web/components/MarketTable.tsx",
                                                                lineNumber: 388,
                                                                columnNumber: 79
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/web/components/MarketTable.tsx",
                                                        lineNumber: 386,
                                                        columnNumber: 41
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/web/components/MarketTable.tsx",
                                                    lineNumber: 385,
                                                    columnNumber: 37
                                                }, this)
                                            ]
                                        }, rowKey, true, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 364,
                                            columnNumber: 22
                                        }, this);
                                    }),
                                    displayedMarkets.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                            colSpan: 4,
                                            style: {
                                                textAlign: "center",
                                                padding: "2rem"
                                            },
                                            children: "No markets found"
                                        }, void 0, false, {
                                            fileName: "[project]/web/components/MarketTable.tsx",
                                            lineNumber: 399,
                                            columnNumber: 41
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/web/components/MarketTable.tsx",
                                        lineNumber: 398,
                                        columnNumber: 67
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/web/components/MarketTable.tsx",
                                lineNumber: 355,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/web/components/MarketTable.tsx",
                        lineNumber: 339,
                        columnNumber: 34
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/web/components/MarketTable.tsx",
                    lineNumber: 336,
                    columnNumber: 17
                }, this),
                !isLoading && totalPages > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].pagination,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].pageButton,
                            onClick: ()=>handlePageChange(currentPage - 1),
                            disabled: currentPage <= 1,
                            children: "Previous"
                        }, void 0, false, {
                            fileName: "[project]/web/components/MarketTable.tsx",
                            lineNumber: 410,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].pageIndicator,
                            children: [
                                "Page ",
                                currentPage,
                                " of ",
                                totalPages,
                                " ",
                                totalCount > 0 ? `• ${totalCount} markets` : ""
                            ]
                        }, void 0, true, {
                            fileName: "[project]/web/components/MarketTable.tsx",
                            lineNumber: 413,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$components$2f$MarketTable$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].pageButton,
                            onClick: ()=>handlePageChange(currentPage + 1),
                            disabled: currentPage >= totalPages,
                            children: "Next"
                        }, void 0, false, {
                            fileName: "[project]/web/components/MarketTable.tsx",
                            lineNumber: 416,
                            columnNumber: 25
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/web/components/MarketTable.tsx",
                    lineNumber: 409,
                    columnNumber: 50
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/web/components/MarketTable.tsx",
            lineNumber: 301,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/web/components/MarketTable.tsx",
        lineNumber: 300,
        columnNumber: 10
    }, this);
}
_s(MarketTable, "4juEgmUPxVDZ2PFkDj+0bqJPEGs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"],
        __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"],
        __TURBOPACK__imported__module__$5b$project$5d2f$web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = MarketTable;
var _c;
__turbopack_context__.k.register(_c, "MarketTable");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=web_4383b33d._.js.map