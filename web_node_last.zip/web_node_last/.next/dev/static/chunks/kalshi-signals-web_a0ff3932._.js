(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_b0219887._.js",
  "static/chunks/232d3_next_dist_compiled_react-dom_f50e48cc._.js",
  "static/chunks/232d3_next_dist_compiled_react-server-dom-turbopack_81fcee61._.js",
  "static/chunks/232d3_next_dist_compiled_next-devtools_index_102c025f.js",
  "static/chunks/232d3_next_dist_compiled_91aa290b._.js",
  "static/chunks/232d3_next_dist_client_3249228a._.js",
  "static/chunks/232d3_next_dist_e5616f0a._.js",
  "static/chunks/232d3_@swc_helpers_cjs_4ef48140._.js"
],
    source: "entry"
});
