(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/web_9533e481._.css",
  "static/chunks/web_1b7f167e._.js"
],
    source: "dynamic"
});
