(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/kalshi-signals-web_af5556a3._.css",
  "static/chunks/kalshi-signals-web_fd6ae2f6._.js"
],
    source: "dynamic"
});
