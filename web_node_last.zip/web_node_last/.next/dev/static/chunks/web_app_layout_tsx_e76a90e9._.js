(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__04daaf66._.css",
  "static/chunks/2374f_next_dist_4eb231b0._.js"
],
    source: "dynamic"
});
