(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/web_4383b33d._.js",
  "static/chunks/2374f_60423c46._.js",
  "static/chunks/web_components_6814387a._.css"
],
    source: "dynamic"
});
