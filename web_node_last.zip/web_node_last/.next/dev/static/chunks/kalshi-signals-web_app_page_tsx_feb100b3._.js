(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/kalshi-signals-web_50e4673a._.js",
  "static/chunks/kalshi-signals-web_components_00d439a4._.css"
],
    source: "dynamic"
});
