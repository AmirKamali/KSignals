(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/web_21d9ca26._.js",
  "static/chunks/web_components_a04c348d._.css"
],
    source: "dynamic"
});
