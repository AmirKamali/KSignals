var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__f3450c22._.js")
R.c("server/chunks/2374f_next_dist_esm_build_templates_app-route_865906b3.js")
R.c("server/chunks/web__next-internal_server_app_favicon_ico_route_actions_4b74bcf3.js")
R.m(78348)
module.exports=R.m(78348).exports
