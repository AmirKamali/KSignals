var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/signals/route.js")
R.c("server/chunks/[root-of-the-server]__98d88e7c._.js")
R.c("server/chunks/[root-of-the-server]__f3450c22._.js")
R.c("server/chunks/web__next-internal_server_app_api_signals_route_actions_6bf31668.js")
R.m(55997)
module.exports=R.m(55997).exports
