var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/markets/route.js")
R.c("server/chunks/[root-of-the-server]__196d51f9._.js")
R.c("server/chunks/[root-of-the-server]__f3450c22._.js")
R.c("server/chunks/web__next-internal_server_app_api_markets_route_actions_2f301b93.js")
R.m(31437)
module.exports=R.m(31437).exports
