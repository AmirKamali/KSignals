module.exports=[47986,(e,o,d)=>{}];

//# sourceMappingURL=web__next-internal_server_app_api_markets_route_actions_2f301b93.js.map