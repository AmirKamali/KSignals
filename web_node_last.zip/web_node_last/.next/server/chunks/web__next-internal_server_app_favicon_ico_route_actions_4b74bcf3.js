module.exports=[63002,(e,o,d)=>{}];

//# sourceMappingURL=web__next-internal_server_app_favicon_ico_route_actions_4b74bcf3.js.map