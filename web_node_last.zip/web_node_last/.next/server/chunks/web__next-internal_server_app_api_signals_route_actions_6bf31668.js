module.exports=[63678,(e,o,d)=>{}];

//# sourceMappingURL=web__next-internal_server_app_api_signals_route_actions_6bf31668.js.map