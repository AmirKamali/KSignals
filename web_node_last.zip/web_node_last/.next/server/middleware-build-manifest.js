globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/8632bd33261f6e9b.js",
    "static/chunks/c27fb849f701dc9f.js",
    "static/chunks/2c1f9347df9bd34b.js",
    "static/chunks/61289a814c039c53.js",
    "static/chunks/turbopack-dba4411785865cee.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];