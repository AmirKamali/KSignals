#!/usr/bin/env bash

set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="${ROOT_DIR}/.env"

if [[ -f "${ENV_FILE}" ]]; then
  # shellcheck disable=SC2046
  set -a
  # shellcheck disable=SC1090
  source "${ENV_FILE}"
  set +a
fi

BASE_URL="${KALSHI_API_BASE_URL:-https://api.elections.kalshi.com/trade-api/v2}"
ACCESS_KEY="${KALSHI_ACCESS_KEY_ID:-}"
if [[ -z "${ACCESS_KEY}" ]]; then
  echo "Error: KALSHI_ACCESS_KEY_ID is not set. Update .env or export it." >&2
  exit 1
fi

QUERY_STRING="${1:-limit=400&status=open}"
OUTPUT_FILE="${2:-markets.json}"

PATH_ONLY="/markets"
BODY=""

INLINE_KEY="${KALSHI_PRIVATE_KEY:-}"
KEY_FILE=""
TEMP_KEY=""

cleanup() {
  if [[ -n "${TEMP_KEY}" && -f "${TEMP_KEY}" ]]; then
    rm -f "${TEMP_KEY}"
  fi
}
trap cleanup EXIT

if [[ -n "${INLINE_KEY}" ]]; then
  TEMP_KEY="$(mktemp)"
  printf '%s' "${INLINE_KEY}" | perl -0pe 's/\\n/\n/g' > "${TEMP_KEY}"
  KEY_FILE="${TEMP_KEY}"
else
  KEY_FILE="${KALSHI_PRIVATE_KEY_PATH:-${ROOT_DIR}/../Market.txt}"
  if [[ ! -f "${KEY_FILE}" ]]; then
    echo "Error: Kalshi private key not found. Set KALSHI_PRIVATE_KEY or KALSHI_PRIVATE_KEY_PATH." >&2
    exit 1
  fi
fi

timestamp_ms="$(python3 - <<'PY'
import time
print(int(time.time() * 1000))
PY
)"

canonical_path="${PATH_ONLY}"
canonical_query=""
if [[ -n "${QUERY_STRING}" ]]; then
  canonical_query="?${QUERY_STRING}"
fi

canonical_payload="${timestamp_ms}GET${PATH_ONLY}${canonical_query}${BODY}"

signature="$(printf '%s' "${canonical_payload}" | openssl dgst -sha256 -sign "${KEY_FILE}" -binary | base64)"

FULL_URL="${BASE_URL}${PATH_ONLY}"
if [[ -n "${QUERY_STRING}" ]]; then
  FULL_URL="${FULL_URL}?${QUERY_STRING}"
fi

echo "Fetching ${FULL_URL}"

curl -sS "${FULL_URL}" \
  -H "Accept: application/json" \
  -H "User-Agent: kalshi-signals/cli" \
  -H "KALSHI-ACCESS-KEY: ${ACCESS_KEY}" \
  -H "KALSHI-ACCESS-SIGNATURE: ${signature}" \
  -H "KALSHI-ACCESS-TIMESTAMP: ${timestamp_ms}" \
  -o "${OUTPUT_FILE}"

echo "Saved response to ${OUTPUT_FILE}"
