"use client";

import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import Link from "next/link";

const navItems = [
  { label: "Markets", href: "#markets" },
  { label: "Signals", href: "#signals" },
  { label: "Coverage", href: "#coverage" },
];

export function Header() {
  return (
    <header className="sticky top-0 z-30 bg-white/80 backdrop-blur-xl border-b border-slate-200/60">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        <Link
          href="/"
          className="text-lg font-semibold tracking-tight text-slate-900"
        >
          Kalshi <span className="text-emerald-500">Signals</span>
        </Link>
        <nav className="hidden items-center gap-6 text-sm text-slate-600 md:flex">
          {navItems.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="transition hover:text-slate-900"
            >
              {item.label}
            </a>
          ))}
        </nav>
        <motion.a
          href="#markets"
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.98 }}
          className="group inline-flex items-center gap-2 rounded-full border border-slate-900/10 bg-slate-900 px-4 py-2 text-sm font-medium text-white shadow-lg shadow-emerald-500/10"
        >
          Request access
          <ArrowRight className="h-4 w-4 transition group-hover:translate-x-0.5" />
        </motion.a>
      </div>
    </header>
  );
}
