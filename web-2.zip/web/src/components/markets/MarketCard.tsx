"use client";

import { motion } from "framer-motion";
import { ArrowUpRight, TrendingUp } from "lucide-react";

import {
  formatCompact,
  formatExpiration,
  formatPercent,
  formatUsd,
  timeUntil,
} from "@/lib/format";
import type { MarketSummary } from "@/types/market";

type MarketCardProps = {
  market: MarketSummary;
};

export function MarketCard({ market }: MarketCardProps) {
  const yesProb = market.yesBid;
  const noProb = 1 - yesProb;
  const isPositive = market.trend >= 0;

  return (
    <motion.article
      whileHover={{ y: -4 }}
      className="group flex flex-col rounded-3xl border border-slate-100 bg-white/90 p-6 shadow-lg shadow-slate-200/60 backdrop-blur transition hover:border-emerald-200"
    >
      <div className="flex items-center justify-between text-xs font-medium uppercase tracking-[0.25em] text-slate-400">
        <span>{market.category}</span>
        <span className="text-slate-500">{market.ticker}</span>
      </div>
      <h3 className="mt-3 text-lg font-semibold text-slate-900">
        {market.question}
      </h3>
      <p className="mt-1 text-xs text-slate-500">
        Closes {formatExpiration(market.closeTime)} · {timeUntil(market.closeTime)} left
      </p>

      <div className="mt-5 grid gap-3 rounded-2xl border border-slate-100 bg-slate-50/60 p-4 text-sm font-medium text-slate-700 md:grid-cols-2">
        <div className="rounded-xl border border-white bg-white/70 p-3">
          <p className="text-xs font-semibold uppercase tracking-wide text-emerald-600">
            {market.yesLabel}
          </p>
          <p className="mt-2 text-2xl font-semibold text-slate-900">
            {formatPercent(yesProb)}
          </p>
          <p className="text-xs text-slate-500">
            ${market.yesBid.toFixed(2)} bid / ${market.yesAsk.toFixed(2)} ask
          </p>
        </div>
        <div className="rounded-xl border border-slate-100 bg-gradient-to-br from-slate-900 to-slate-800 p-3 text-white">
          <p className="text-xs font-semibold uppercase tracking-wide text-emerald-300">
            {market.noLabel}
          </p>
          <p className="mt-2 text-2xl font-semibold">
            {formatPercent(noProb)}
          </p>
          <p className="text-xs text-slate-200">
            ${market.noBid.toFixed(2)} bid / ${market.noAsk.toFixed(2)} ask
          </p>
        </div>
      </div>

      <div className="mt-5 flex flex-wrap items-center gap-4 text-sm text-slate-600">
        <div className="inline-flex items-center gap-2 rounded-full border border-slate-200 px-3 py-1">
          <TrendingUp
            className={`h-4 w-4 ${isPositive ? "text-emerald-500" : "text-rose-500"}`}
          />
          {`${isPositive ? "+" : ""}${(market.trend * 100).toFixed(1)} pts`}
        </div>
        <div className="text-xs uppercase tracking-wider text-slate-500">
          {market.confidenceLabel}
        </div>
      </div>

      <dl className="mt-6 grid grid-cols-3 gap-3 text-center text-xs font-semibold uppercase tracking-wide text-slate-400">
        <div className="rounded-2xl border border-slate-100 bg-white/70 p-3">
          <dt>Liquidity</dt>
          <dd className="mt-1 text-base text-slate-900">
            {formatUsd(market.liquidityUsd)}
          </dd>
        </div>
        <div className="rounded-2xl border border-slate-100 bg-white/70 p-3">
          <dt>24h vol</dt>
          <dd className="mt-1 text-base text-slate-900">
            {formatCompact(market.volume24hContracts)}
          </dd>
        </div>
        <div className="rounded-2xl border border-slate-100 bg-white/70 p-3">
          <dt>Open Int</dt>
          <dd className="mt-1 text-base text-slate-900">
            {formatCompact(market.openInterestContracts)}
          </dd>
        </div>
      </dl>

      <div className="mt-6 flex items-center justify-between text-sm text-slate-500">
        <p>Notional ${market.notionalValue.toFixed(2)}</p>
        <button className="inline-flex items-center gap-1 text-emerald-600 transition hover:gap-2">
          Inspect trade
          <ArrowUpRight className="h-4 w-4" />
        </button>
      </div>
    </motion.article>
  );
}
