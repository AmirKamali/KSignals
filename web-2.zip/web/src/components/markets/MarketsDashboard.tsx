"use client";

import { AnimatePresence, motion } from "framer-motion";
import { Loader2, RefreshCw } from "lucide-react";
import { useEffect, useMemo, useState } from "react";

import type { MarketSummary } from "@/types/market";
import { MarketCard } from "./MarketCard";

const statusFilters: { label: string; value: string | null }[] = [
  { label: "Open", value: "open" },
  { label: "Closed", value: "closed" },
  { label: "Settled", value: "settled" },
];

type MarketsDashboardProps = {
  initialMarkets: MarketSummary[];
  categories: string[];
};

export function MarketsDashboard({
  initialMarkets,
  categories,
}: MarketsDashboardProps) {
  const [markets, setMarkets] = useState(initialMarkets);
  const [status, setStatus] = useState<string | null>("open");
  const [category, setCategory] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [updatedAt, setUpdatedAt] = useState<Date | null>(new Date());
  const [refreshToken, setRefreshToken] = useState(0);

  const allCategories = useMemo(() => {
    const dedup = new Set<string>(
      [...categories, ...markets.map((m) => m.category)].filter(Boolean)
    );
    return Array.from(dedup);
  }, [categories, markets]);

  useEffect(() => {
    let abort = false;
    async function load() {
      setLoading(true);
      setError(null);

      const params = new URLSearchParams({ limit: "24" });
      if (status) params.set("status", status);
      if (category) params.set("category", category);

      try {
        const response = await fetch(`/api/markets?${params.toString()}`, {
          cache: "no-store",
        });
        if (!response.ok) {
          throw new Error(await response.text());
        }
        const data = (await response.json()) as { markets: MarketSummary[] };
        if (abort) return;
        setMarkets(data.markets);
        setUpdatedAt(new Date());
      } catch {
        if (abort) return;
        setError("Unable to refresh markets right now.");
      } finally {
        if (!abort) {
          setLoading(false);
        }
      }
    }

    load();
    return () => {
      abort = true;
    };
  }, [status, category, refreshToken]);

  const filteredMarkets = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) {
      return markets;
    }

    return markets.filter((market) =>
      market.question.toLowerCase().includes(q)
    );
  }, [markets, search]);

  const lastUpdatedLabel = updatedAt
    ? updatedAt.toLocaleTimeString("en-US", {
        hour: "2-digit",
        minute: "2-digit",
      })
    : "–";

  return (
    <section className="space-y-6" id="markets">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.3em] text-emerald-600">
            Live board
          </p>
          <h2 className="text-3xl font-semibold text-slate-900">
            Current Kalshi markets
          </h2>
          <p className="text-sm text-slate-500">
            Updated {lastUpdatedLabel} · Streaming direct from Kalshi
          </p>
        </div>
        <button
          onClick={() => setRefreshToken((token) => token + 1)}
          className="inline-flex items-center gap-2 rounded-full border border-slate-200 px-4 py-2 text-sm font-medium text-slate-600 shadow-sm transition hover:border-emerald-200 hover:text-emerald-600"
        >
          <RefreshCw className="h-4 w-4" />
          Sync feed
        </button>
      </div>

      <div className="flex flex-wrap gap-3">
        {statusFilters.map((filter) => (
          <button
            key={filter.label}
            onClick={() => setStatus(filter.value)}
            className={`rounded-full px-4 py-2 text-sm font-medium transition ${
              status === filter.value
                ? "bg-slate-900 text-white shadow-lg"
                : "border border-slate-200 text-slate-600 hover:border-emerald-200 hover:text-emerald-600"
            }`}
          >
            {filter.label}
          </button>
        ))}
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <button
          onClick={() => setCategory(null)}
          className={`rounded-full border px-3 py-1 text-xs font-semibold uppercase tracking-wide ${
            category === null
              ? "border-slate-900 bg-slate-900 text-white"
              : "border-slate-200 text-slate-600"
          }`}
        >
          All categories
        </button>
        {allCategories.map((cat) => (
          <button
            key={cat}
            onClick={() => setCategory(cat === category ? null : cat)}
            className={`rounded-full border px-3 py-1 text-xs font-semibold uppercase tracking-wide transition ${
              category === cat
                ? "border-emerald-300 bg-emerald-50 text-emerald-700"
                : "border-slate-200 text-slate-500 hover:border-emerald-200 hover:text-emerald-600"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      <div className="relative">
        <input
          type="search"
          value={search}
          onChange={(event) => setSearch(event.target.value)}
          placeholder="Search by question, theme, or ticker…"
          className="w-full rounded-2xl border border-slate-200 bg-white/60 px-4 py-3 text-sm text-slate-700 placeholder:text-slate-400 focus:border-emerald-400 focus:outline-none"
        />
        {loading && (
          <Loader2 className="absolute right-4 top-1/2 h-4 w-4 animate-spin text-emerald-500" />
        )}
      </div>

      {error && (
        <p className="rounded-2xl border border-rose-200 bg-rose-50/60 px-4 py-3 text-sm text-rose-700">
          {error}
        </p>
      )}

      <AnimatePresence mode="popLayout">
        <motion.div
          layout
          className="grid gap-6 lg:grid-cols-2"
          id="coverage"
        >
          {filteredMarkets.map((market) => (
            <MarketCard key={market.ticker} market={market} />
          ))}
          {filteredMarkets.length === 0 && !loading && (
            <p className="rounded-3xl border border-slate-100 bg-white/80 p-8 text-center text-sm text-slate-500">
              No markets match that filter yet. Try a different combination.
            </p>
          )}
        </motion.div>
      </AnimatePresence>
    </section>
  );
}
