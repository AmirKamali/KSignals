"use client";

import { motion } from "framer-motion";

import { formatPercent } from "@/lib/format";
import type { MarketSummary } from "@/types/market";

type SignalTickerProps = {
  markets: MarketSummary[];
};

export function SignalTicker({ markets }: SignalTickerProps) {
  const highlights = markets
    .slice(0, 6)
    .map((market) => ({
      ticker: market.ticker,
      label: market.question,
      odds: formatPercent(market.yesBid),
      direction: market.trend >= 0 ? "Bullish" : "Bearish",
    }));

  const marqueeItems = [...highlights, ...highlights];

  if (highlights.length === 0) {
    return null;
  }

  return (
    <div
      className="overflow-hidden rounded-3xl border border-emerald-100 bg-emerald-50/60 p-3"
      id="signals"
    >
      <motion.div
        animate={{ x: ["0%", "-50%"] }}
        transition={{ repeat: Infinity, duration: 20, ease: "linear" }}
        className="flex min-w-max gap-6"
      >
        {marqueeItems.map((signal, index) => (
          <div
            key={`${signal.ticker}-${index}`}
            className="flex min-w-[240px] items-center gap-3 rounded-2xl border border-emerald-100 bg-white/80 px-4 py-2 shadow-sm"
          >
            <span className="text-xs font-semibold uppercase tracking-widest text-emerald-600">
              {signal.ticker}
            </span>
            <p className="flex-1 text-sm text-slate-700">{signal.label}</p>
            <span className="text-sm font-semibold text-slate-900">
              {signal.odds}
            </span>
          </div>
        ))}
      </motion.div>
    </div>
  );
}
