"use client";

import { motion } from "framer-motion";
import { Activity, ShieldCheck, Waves } from "lucide-react";

import { formatPercent, formatUsd } from "@/lib/format";

export type HeroStats = {
  activeMarkets: number;
  avgConviction: number;
  totalLiquidity: number;
  spotlight?: {
    question: string;
    yesBid: number;
    category: string;
  };
};

const statIcons = [
  Activity,
  ShieldCheck,
  Waves,
] as const;

export function Hero({ stats }: { stats: HeroStats }) {
  const statEntries = [
    {
      label: "Live Signals",
      value: stats.activeMarkets.toLocaleString(),
      hint: "Across macro, politics & crypto",
    },
    {
      label: "Avg. conviction",
      value: formatPercent(stats.avgConviction),
      hint: "Weighted by liquidity",
    },
    {
      label: "Tracked liquidity",
      value: formatUsd(stats.totalLiquidity),
      hint: "Real money on Kalshi order books",
    },
  ];

  return (
    <section className="relative isolate overflow-hidden rounded-3xl border border-white/60 bg-gradient-to-b from-white via-white to-emerald-50 p-8 shadow-2xl shadow-emerald-500/20">
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_top,_rgba(52,211,153,0.25),_transparent_55%)]" />
      <div className="grid gap-10 md:grid-cols-2 md:gap-16">
        <div className="space-y-6">
          <p className="inline-flex items-center gap-2 rounded-full border border-emerald-500/30 px-3 py-1 text-xs font-semibold uppercase tracking-[0.2em] text-emerald-700">
            Kalshi signals
          </p>
          <h1 className="text-4xl font-semibold tracking-tight text-slate-900 md:text-5xl">
            Trade-grade intelligence for{" "}
            <span className="text-emerald-500">event markets.</span>
          </h1>
          <p className="text-lg text-slate-600">
            Stream Kalshi&apos;s live markets, see institutional odds, and spot
            momentum before mainstream feeds catch up. Designed for quants,
            macro desks, and founders who need the fast read.
          </p>
          <div className="flex flex-wrap gap-4 text-sm font-medium">
            <motion.a
              href="#markets"
              whileHover={{ y: -2 }}
              className="rounded-full bg-emerald-500 px-6 py-3 text-white shadow-lg shadow-emerald-400/40"
            >
              View live board
            </motion.a>
            <motion.a
              href="https://kalshi.com"
              target="_blank"
              rel="noreferrer"
              whileHover={{ y: -2 }}
              className="rounded-full border border-slate-300 px-6 py-3 text-slate-700 backdrop-blur"
            >
              Explore Kalshi
            </motion.a>
          </div>
        </div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="space-y-4 rounded-2xl border border-slate-200 bg-white/90 p-6 shadow-xl backdrop-blur"
        >
          <p className="text-sm font-semibold text-slate-500">
            Live conviction snapshot
          </p>
          <div className="grid gap-4 md:grid-cols-3">
            {statEntries.map((entry, idx) => {
              const Icon = statIcons[idx];
              return (
                <div
                  key={entry.label}
                  className="rounded-2xl border border-slate-100 bg-gradient-to-b from-white to-slate-50 p-4 shadow-sm"
                >
                  <div className="mb-3 inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-slate-400">
                    <Icon className="h-4 w-4 text-emerald-500" />
                    {entry.label}
                  </div>
                  <p className="text-2xl font-semibold text-slate-900">
                    {entry.value}
                  </p>
                  <p className="text-xs text-slate-500">{entry.hint}</p>
                </div>
              );
            })}
          </div>
          {stats.spotlight && (
            <motion.div
              whileHover={{ scale: 1.01 }}
              className="rounded-2xl border border-emerald-200 bg-gradient-to-r from-emerald-50 via-white to-emerald-50/40 p-5"
            >
              <p className="text-xs font-semibold uppercase tracking-[0.3em] text-emerald-600">
                Spotlight
              </p>
              <h3 className="mt-2 text-lg font-semibold text-slate-900">
                {stats.spotlight.question}
              </h3>
              <div className="mt-4 flex items-center justify-between">
                <div>
                  <p className="text-xs text-slate-500">
                    {stats.spotlight.category}
                  </p>
                  <p className="text-2xl font-semibold text-emerald-600">
                    {formatPercent(stats.spotlight.yesBid)}
                  </p>
                </div>
                <motion.span
                  animate={{ opacity: [0.6, 1, 0.6] }}
                  transition={{ duration: 2.4, repeat: Infinity }}
                  className="rounded-full bg-emerald-500/10 px-3 py-1 text-xs font-medium text-emerald-600"
                >
                  Live odds
                </motion.span>
              </div>
            </motion.div>
          )}
        </motion.div>
      </div>
    </section>
  );
}
