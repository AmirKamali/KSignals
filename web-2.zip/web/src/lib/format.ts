const usdFormatter = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  maximumFractionDigits: 0,
});

const percentFormatter = new Intl.NumberFormat("en-US", {
  style: "percent",
  maximumFractionDigits: 0,
});

const compactFormatter = new Intl.NumberFormat("en-US", {
  notation: "compact",
  maximumFractionDigits: 1,
});

const timeFormatter = new Intl.DateTimeFormat("en-US", {
  month: "short",
  day: "numeric",
  hour: "numeric",
  minute: "numeric",
});

export function formatUsd(value: number): string {
  if (!Number.isFinite(value)) {
    return "$0";
  }

  if (value < 100000) {
    return `$${value.toLocaleString("en-US", {
      maximumFractionDigits: 0,
    })}`;
  }

  return usdFormatter.format(value);
}

export function formatCompact(value: number): string {
  if (!Number.isFinite(value)) {
    return "0";
  }
  return compactFormatter.format(value);
}

export function formatPercent(probability: number): string {
  return percentFormatter.format(probability);
}

export function formatExpiration(isoDate: string): string {
  const date = new Date(isoDate);
  return timeFormatter.format(date);
}

export function timeUntil(isoDate: string): string {
  const target = new Date(isoDate).getTime();
  const diff = target - Date.now();
  if (diff <= 0) {
    return "Settling";
  }

  const hours = Math.floor(diff / (1000 * 60 * 60));
  if (hours >= 24) {
    const days = Math.floor(hours / 24);
    return `${days}d ${hours % 24}h`;
  }

  if (hours >= 1) {
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    return `${hours}h ${minutes}m`;
  }

  const minutes = Math.floor(diff / (1000 * 60));
  return `${minutes}m`;
}
