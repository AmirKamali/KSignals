import { NextResponse } from "next/server";

import { marketRepository } from "@/server/repositories/marketRepository";
import type { MarketSummary } from "@/types/market";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const limit = clampLimit(url.searchParams.get("limit"));
  const status = url.searchParams.get("status") || undefined;
  const category = url.searchParams.get("category") || undefined;
  const eventTicker = url.searchParams.get("event_ticker") || undefined;

  try {
    const markets = await marketRepository.listMarkets(
      {
        status,
        category,
        event_ticker: eventTicker,
      },
      limit
    );

    return NextResponse.json<{ markets: MarketSummary[] }>({ markets });
  } catch (error) {
    console.error("Markets API failed", error);
    return NextResponse.json(
      { error: "Unable to load markets" },
      { status: 500 }
    );
  }
}

function clampLimit(value: string | null): number {
  const parsed = Number(value);
  if (Number.isFinite(parsed)) {
    return Math.min(Math.max(1, Math.trunc(parsed)), 48);
  }
  return 24;
}
