export const dynamic = "force-dynamic";

import { Header } from "@/components/layout/Header";
import { MarketsDashboard } from "@/components/markets/MarketsDashboard";
import { Hero, type HeroStats } from "@/components/sections/Hero";
import { SignalTicker } from "@/components/sections/SignalTicker";
import { marketRepository } from "@/server/repositories/marketRepository";
import type { MarketSummary } from "@/types/market";

export default async function Home() {
  const markets = await marketRepository.listMarkets();
  const heroStats = buildHeroStats(markets);
  const categories = Array.from(
    new Set(markets.map((market) => market.category))
  ).filter((category): category is string => Boolean(category));

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <div className="absolute inset-x-0 top-0 -z-10 h-[420px] bg-gradient-to-b from-emerald-100 to-transparent" />
      <Header />
      <main className="mx-auto flex max-w-6xl flex-col gap-12 px-4 py-10 md:px-6 md:py-12">
        <Hero stats={heroStats} />
        <SignalTicker markets={markets} />
        <MarketsDashboard initialMarkets={markets} categories={categories} />
        <Callout />
      </main>
    </div>
  );
}

function Callout() {
  return (
    <section className="rounded-3xl border border-slate-200 bg-white px-6 py-10 text-center shadow-xl shadow-emerald-100">
      <p className="text-xs font-semibold uppercase tracking-[0.4em] text-emerald-600">
        Built for desks & founders
      </p>
      <h3 className="mt-4 text-3xl font-semibold text-slate-900">
        Drop Kalshi Signals into your stack.
      </h3>
      <p className="mt-2 text-sm text-slate-500">
        Query our API, embed this board, or stream the feed over websockets.
        Each tier ships with webhook delivery, audit trails, and SOC-2 controls.
      </p>
      <div className="mt-6 flex flex-wrap justify-center gap-4 text-sm font-medium">
        <a
          href="mailto:signals@kalshi.com"
          className="rounded-full bg-slate-900 px-6 py-3 text-white"
        >
          Book a demo
        </a>
        <a
          href="https://docs.kalshi.com"
          className="rounded-full border border-slate-200 px-6 py-3 text-slate-700"
        >
          Read the docs
        </a>
      </div>
    </section>
  );
}

function buildHeroStats(markets: MarketSummary[]): HeroStats {
  const totalLiquidity = markets.reduce(
    (sum, market) => sum + (market.liquidityUsd || 0),
    0
  );

  let weightedProb = 0;
  let totalWeight = 0;
  markets.forEach((market) => {
    const weight = Math.max(market.liquidityUsd, 1);
    weightedProb += market.yesBid * weight;
    totalWeight += weight;
  });

  const avgConviction = totalWeight ? weightedProb / totalWeight : 0.5;

  const spotlight = markets
    .slice()
    .sort((a, b) => b.liquidityUsd - a.liquidityUsd)[0];

  return {
    activeMarkets: markets.length,
    avgConviction,
    totalLiquidity,
    spotlight: spotlight
      ? {
          question: spotlight.question,
          yesBid: spotlight.yesBid,
          category: spotlight.category,
        }
      : undefined,
  };
}
