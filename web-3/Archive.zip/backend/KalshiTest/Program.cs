﻿using System;
using System.IO;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static async Task Main(string[] args)
    {
        try
        {
            Console.WriteLine("Starting Kalshi Connectivity Test...");

            // Configuration
            string baseUrl = "https://api.elections.kalshi.com/trade-api/v2";
            string keyId = "7be80ee6-6dcd-4274-b7c3-14030b982f90";
            string privateKeyPath = "../../../Market.txt";

            if (!File.Exists(privateKeyPath))
            {
                Console.WriteLine("ERROR: Private key file not found!");
                return;
            }

            var pem = File.ReadAllText(privateKeyPath);
            using var rsa = RSA.Create();
            rsa.ImportFromPem(pem);

            using var client = new HttpClient();
            
            Console.WriteLine("\nTesting /markets endpoint...");
            var method = HttpMethod.Get;
            // FIX: Use status=open instead of active
            var path = "/markets?limit=5&status=open";
            var url = baseUrl + path;

            var timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds().ToString();
            var msg = timestamp + method.Method.ToUpper() + "/trade-api/v2" + path;
            
            Console.WriteLine($"Signing Message: {msg}");

            var signatureBytes = rsa.SignData(Encoding.UTF8.GetBytes(msg), HashAlgorithmName.SHA256, RSASignaturePadding.Pss);
            var signature = Convert.ToBase64String(signatureBytes);

            var request = new HttpRequestMessage(method, url);
            request.Headers.Add("KALSHI-ACCESS-KEY", keyId);
            request.Headers.Add("KALSHI-ACCESS-SIGNATURE", signature);
            request.Headers.Add("KALSHI-ACCESS-TIMESTAMP", timestamp);

            Console.WriteLine("Sending request...");
            var response = await client.SendAsync(request);

            Console.WriteLine($"Response Status: {response.StatusCode}");
            var content = await response.Content.ReadAsStringAsync();
            Console.WriteLine($"Response Content Preview: {content.Substring(0, Math.Min(500, content.Length))}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"EXCEPTION: {ex.Message}");
        }
    }
}
