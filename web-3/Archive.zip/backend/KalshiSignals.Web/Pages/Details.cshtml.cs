using KalshiSignals.Web.Models;
using KalshiSignals.Web.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Threading.Tasks;

namespace KalshiSignals.Web.Pages
{
    public class DetailsModel : PageModel
    {
        private readonly KalshiService _kalshiService;
        private readonly LLMService _llmService;

        public DetailsModel(KalshiService kalshiService, LLMService llmService)
        {
            _kalshiService = kalshiService;
            _llmService = llmService;
        }

        public Market Market { get; set; }
        public Signal Signal { get; set; }

        public async Task<IActionResult> OnGetAsync(string ticker)
        {
            if (string.IsNullOrEmpty(ticker))
            {
                return RedirectToPage("./Index");
            }

            Market = await _kalshiService.GetMarketAsync(ticker);
            if (Market == null)
            {
                return NotFound();
            }

            // Get LLM Signal
            // We use current Yes price (approx midpoint or Ask) as input
            var price = Market.YesAsk > 0 ? Market.YesAsk : Market.YesBid;
            Signal = await _llmService.AnalyzeMarketAsync(Market.Ticker, Market.Title, (double)price / 100.0);

            return Page();
        }
    }
}


