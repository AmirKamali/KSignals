using KalshiSignals.Web.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KalshiSignals.Web.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;
        private readonly KalshiService _kalshiService;

        public IndexModel(ILogger<IndexModel> logger, KalshiService kalshiService)
        {
            _logger = logger;
            _kalshiService = kalshiService;
        }

        public List<Market> TopMarkets { get; set; } = new List<Market>();
        public List<Market> MarketTable { get; set; } = new List<Market>();
        public string CurrentCategory { get; set; } = "All";
        public string ErrorMessage { get; set; }

        public async Task OnGetAsync(string category = "All")
        {
            CurrentCategory = category;
            var markets = await _kalshiService.GetMarketsAsync(100);

            if (markets == null || !markets.Any())
            {
                ErrorMessage = "No markets found. Please check API configuration or connectivity.";
                return;
            }

            // Top 6 by Volume for Grid
            TopMarkets = markets.OrderByDescending(m => m.Volume).Take(6).ToList();

            // For Table
            if (category != "All")
            {
                // Simple client-side filtering mock
                MarketTable = markets.Where(m => m.Title.Contains(category) || m.EventTicker.Contains(category)).ToList();
            }
            else
            {
                MarketTable = markets.OrderByDescending(m => m.Volume).Skip(6).Take(20).ToList();
            }
        }
    }
}
