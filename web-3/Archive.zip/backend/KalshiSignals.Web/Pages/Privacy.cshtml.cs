﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KalshiSignals.Web.Pages;

public class PrivacyModel : PageModel
{
    public void OnGet()
    {
    }
}

