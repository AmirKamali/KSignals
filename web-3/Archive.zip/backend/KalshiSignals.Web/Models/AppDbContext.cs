using Microsoft.EntityFrameworkCore;

namespace KalshiSignals.Web.Models
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        public DbSet<Signal> Signals { get; set; }
    }

    public class Signal
    {
        public int Id { get; set; }
        public string MarketTicker { get; set; }
        public string TradeTitle { get; set; }
        public double Odds { get; set; }
        public double WinningPercentage { get; set; }
        public string Analysis { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}


