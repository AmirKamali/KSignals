using Microsoft.AspNetCore.Mvc;
using KalshiSignals.Web.Services;
using KalshiSignals.Web.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;

namespace KalshiSignals.Web.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class SignalsController : ControllerBase
    {
        private readonly KalshiService _kalshiService;
        private readonly LLMService _llmService;
        private readonly ILogger<SignalsController> _logger;

        public SignalsController(KalshiService kalshiService, LLMService llmService, ILogger<SignalsController> logger)
        {
            _kalshiService = kalshiService;
            _llmService = llmService;
            _logger = logger;
        }

        [HttpGet("markets")]
        public async Task<IActionResult> GetMarkets()
        {
            var markets = await _kalshiService.GetMarketsAsync(limit: 100);
            return Ok(markets);
        }

        [HttpGet("top-volume")]
        public async Task<IActionResult> GetTopVolume()
        {
            var markets = await _kalshiService.GetMarketsAsync(limit: 100);
            var topMarkets = markets.OrderByDescending(m => m.Volume).Take(6).ToList();
            return Ok(topMarkets);
        }

        [HttpGet("trade/{ticker}")]
        public async Task<IActionResult> GetTradeDetails(string ticker)
        {
            var market = await _kalshiService.GetMarketAsync(ticker);
            if (market == null)
            {
                return NotFound("Market not found");
            }

            // Current price estimation (YesAsk is in cents, e.g., 50 means 50 cents)
            // Use YesAsk as current price for buying "Yes"
            double price = market.YesAsk; 
            
            var signal = await _llmService.AnalyzeMarketAsync(market.Ticker, market.Title, price);

            return Ok(new
            {
                Market = market,
                Signal = signal
            });
        }
    }
}


