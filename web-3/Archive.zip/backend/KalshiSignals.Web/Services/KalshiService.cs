using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace KalshiSignals.Web.Services
{
    public class KalshiService
    {
        private readonly HttpClient _httpClient;
        private readonly IConfiguration _configuration;
        private readonly ILogger<KalshiService> _logger;
        private readonly string _baseUrl;

        public KalshiService(HttpClient httpClient, IConfiguration configuration, ILogger<KalshiService> logger)
        {
            _httpClient = httpClient;
            _configuration = configuration;
            _logger = logger;
            _baseUrl = _configuration["Kalshi:BaseUrl"] ?? "https://api.elections.kalshi.com/trade-api/v2";
        }

        public async Task<List<Market>> GetMarketsAsync(int limit = 100)
        {
             // Endpoint: /markets
             // Filter by status=open. Using the public unauthenticated endpoint.
             var url = $"{_baseUrl}/markets?limit={limit}&status=open";
             
             try 
             {
                 var response = await _httpClient.GetAsync(url);
                 
                 if (!response.IsSuccessStatusCode)
                 {
                     _logger.LogError($"Error fetching markets: {response.StatusCode}");
                     var errorContent = await response.Content.ReadAsStringAsync();
                     _logger.LogError(errorContent);
                     return new List<Market>();
                 }

                 var content = await response.Content.ReadAsStringAsync();
                 var result = JsonConvert.DeserializeObject<MarketsResponse>(content);
                 return result?.Markets ?? new List<Market>();
             }
             catch (Exception ex)
             {
                 _logger.LogError(ex, "Exception fetching markets");
                 return new List<Market>();
             }
        }
        
        public async Task<Market> GetMarketAsync(string ticker)
        {
             var url = $"{_baseUrl}/markets/{ticker}";
             
             try
             {
                 var response = await _httpClient.GetAsync(url);
                 
                 if (!response.IsSuccessStatusCode)
                 {
                     _logger.LogWarning($"Market {ticker} not found or error: {response.StatusCode}");
                     return null;
                 }

                 var content = await response.Content.ReadAsStringAsync();
                 var result = JsonConvert.DeserializeObject<MarketResponse>(content);
                 return result?.Market;
             }
             catch (Exception ex)
             {
                 _logger.LogError(ex, $"Exception fetching market {ticker}");
                 return null;
             }
        }
    }

    // Models for API Response
    public class MarketsResponse
    {
        [JsonProperty("markets")]
        public List<Market> Markets { get; set; }
    }
    
    public class MarketResponse
    {
        [JsonProperty("market")]
        public Market Market { get; set; }
    }

    public class Market
    {
        [JsonProperty("ticker")]
        public string Ticker { get; set; }

        [JsonProperty("event_ticker")]
        public string EventTicker { get; set; }

        [JsonProperty("title")]
        public string Title { get; set; }

        [JsonProperty("subtitle")]
        public string Subtitle { get; set; }
        
        [JsonProperty("yes_bid")]
        public long YesBid { get; set; }
        
        [JsonProperty("yes_ask")]
        public long YesAsk { get; set; }

        [JsonProperty("volume")]
        public long Volume { get; set; }
        
        [JsonProperty("open_interest")]
        public long OpenInterest { get; set; }

        [JsonProperty("liquidity")]
        public long Liquidity { get; set; }
    }
}
