import React from 'react';

interface MarketTitleProps {
  title: string;
  limit?: number;
  isDetails?: boolean;
  className?: string;
}

export default function MarketTitle({ title, limit, isDetails, className = '' }: MarketTitleProps) {
  // Heuristic: If it looks like a question or specific event sentence, don't split.
  // Markets often have titles like "Will X happen?" or include dates like "Nov 20, 2025".
  const isSentence = title.startsWith('Will ') || title.includes('?') || (title.match(/,\s*\d{4}/) !== null);
  
  if (isSentence) {
    // Render as a normal string, potentially removing markdown bolding ** ** if present
    const cleanTitle = title.replace(/\*\*/g, '');
    return <span className={className}>{cleanTitle}</span>;
  }

  // Check if it's a comma-separated list
  const parts = title.split(',').map(p => p.trim()).filter(Boolean);
  
  // If it's just a normal sentence (no commas or just one part), render as text
  if (parts.length <= 1) {
    return <span className={className}>{title}</span>;
  }

  // Logic for displaying lists
  if (isDetails) {
    return (
      <div className={`flex flex-wrap gap-2 my-2 ${className}`}>
        {parts.map((part, i) => {
          // distinct styling for Yes/No prefixes if present
          const isYes = part.toLowerCase().startsWith('yes ');
          const isNo = part.toLowerCase().startsWith('no ');
          let content = part;
          let badgeClass = "bg-gray-100 text-gray-800 border-gray-200";

          if (isYes) {
            content = part.substring(4); // remove "yes "
            badgeClass = "bg-green-50 text-green-700 border-green-200";
          } else if (isNo) {
            content = part.substring(3); // remove "no "
            badgeClass = "bg-red-50 text-red-700 border-red-200";
          }

          return (
            <span key={i} className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium border ${badgeClass}`}>
              {isYes && <span className="mr-1.5 text-xs font-bold uppercase">YES</span>}
              {isNo && <span className="mr-1.5 text-xs font-bold uppercase">NO</span>}
              {content}
            </span>
          );
        })}
      </div>
    );
  }

  // For preview cards/tables (truncated view)
  const displayParts = limit ? parts.slice(0, limit) : parts;
  const remaining = parts.length - displayParts.length;

  return (
    <div className={`flex flex-col gap-0.5 ${className}`}>
      {displayParts.map((part, i) => (
        <span key={i} className="text-sm leading-snug block truncate text-gray-800">
          • {part}
        </span>
      ))}
      {remaining > 0 && (
        <span className="text-xs text-gray-500 font-medium mt-1">
          +{remaining} others
        </span>
      )}
    </div>
  );
}
