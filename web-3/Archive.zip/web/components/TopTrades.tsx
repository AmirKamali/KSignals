import { Market } from '../lib/api';
import Link from 'next/link';
import MarketTitle from './MarketTitle';

interface TopTradesProps {
  markets: Market[];
}

export default function TopTrades({ markets }: TopTradesProps) {
  return (
    <section className="py-12 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8 text-gray-900">Trending High Volume</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {markets.map((market) => (
            <Link href={`/trade/${market.ticker}`} key={market.ticker} className="block group">
              <div className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow border border-gray-100 h-full flex flex-col">
                <div className="flex justify-between items-start mb-4">
                  <span className="bg-green-100 text-green-800 text-xs font-bold px-2 py-1 rounded uppercase">
                    High Vol
                  </span>
                  <span className="text-gray-500 text-sm">{market.ticker}</span>
                </div>
                <div className="mb-2 min-h-[3rem] flex items-center">
                  <div className="group-hover:text-green-700 transition-colors w-full">
                    <MarketTitle title={market.title} limit={3} className="font-semibold" />
                  </div>
                </div>
                <p className="text-gray-600 text-sm mb-4 flex-grow line-clamp-2">{market.subtitle}</p>
                <div className="flex justify-between items-center mt-4 pt-4 border-t border-gray-100">
                  <div>
                    <span className="text-xs text-gray-500 block">Volume</span>
                    <span className="font-mono font-medium">{market.volume.toLocaleString()}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-xs text-gray-500 block">Yes Price</span>
                    <span className="font-bold text-green-600">{market.yes_ask}¢</span>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
