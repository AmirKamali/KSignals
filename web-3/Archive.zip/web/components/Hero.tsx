import Link from 'next/link';

export default function Hero() {
  return (
    <section className="bg-black text-white py-20 relative overflow-hidden">
      <div className="container mx-auto px-4 text-center relative z-10">
        <h1 className="text-5xl font-bold mb-6 tracking-tighter">Kalshi Signals</h1>
        <p className="text-xl mb-8 text-gray-300 max-w-2xl mx-auto">
          Data-driven insights and AI predictions for the world's premier event contracts market.
        </p>
        <div className="flex justify-center gap-4">
          <Link href="#markets" className="bg-green-500 hover:bg-green-600 text-black font-bold py-3 px-8 rounded-full transition-colors">
            Explore Markets
          </Link>
          <button className="bg-transparent border border-white hover:bg-white hover:text-black font-bold py-3 px-8 rounded-full transition-colors">
            Sign Up
          </button>
        </div>
      </div>
      {/* Abstract background element */}
      <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-gray-900 to-black opacity-50 z-0"></div>
    </section>
  );
}


