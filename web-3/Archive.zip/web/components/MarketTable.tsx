'use client';

import { useState } from 'react';
import { Market } from '../lib/api';
import Link from 'next/link';
import MarketTitle from './MarketTitle';

interface MarketTableProps {
  markets: Market[];
}

const CATEGORIES = ['All', 'Politics', 'Economics', 'Science', 'Culture'];

export default function MarketTable({ markets }: MarketTableProps) {
  const [activeCategory, setActiveCategory] = useState('All');

  // Simple client-side filtering mock (since API doesn't send categories yet or we need to infer)
  // In real app, use 'category' field if available.
  const filteredMarkets = activeCategory === 'All' 
    ? markets 
    : markets.filter(m => m.title.includes(activeCategory) || m.subtitle.includes(activeCategory)); 
    // Just a loose search for demo purposes

  return (
    <section id="markets" className="py-12 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8">All Markets</h2>
        
        {/* Segmented Controls */}
        <div className="flex flex-wrap gap-2 mb-8">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-6 py-2 rounded-full text-sm font-medium transition-colors ${
                activeCategory === cat
                  ? 'bg-black text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Table */}
        <div className="overflow-x-auto rounded-lg border border-gray-200">
          <table className="w-full text-left">
            <thead className="bg-gray-50 text-gray-500 text-xs uppercase font-semibold">
              <tr>
                <th className="px-6 py-4">Title</th>
                <th className="px-6 py-4 text-right">Volume</th>
                <th className="px-6 py-4 text-right">Yes Price (Odds)</th>
                <th className="px-6 py-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredMarkets.map((market) => (
                <tr key={market.ticker} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="font-medium text-gray-900">
                      <MarketTitle title={market.title} limit={2} />
                    </div>
                    <div className="text-xs text-gray-500 mt-1">{market.subtitle}</div>
                  </td>
                  <td className="px-6 py-4 text-right font-mono text-sm">
                    {market.volume.toLocaleString()}
                  </td>
                  <td className="px-6 py-4 text-right font-mono font-medium text-green-600">
                    {market.yes_ask}¢
                  </td>
                  <td className="px-6 py-4 text-right">
                    <Link 
                      href={`/trade/${market.ticker}`}
                      className="inline-block bg-white border border-gray-300 hover:border-gray-400 text-gray-700 text-sm font-medium px-4 py-2 rounded-lg transition-colors"
                    >
                      Details
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filteredMarkets.length === 0 && (
          <div className="text-center py-12 text-gray-500">No markets found in this category.</div>
        )}
      </div>
    </section>
  );
}
