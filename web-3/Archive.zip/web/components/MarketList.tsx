'use client';

import { useEffect, useState, useCallback, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Market } from '@/types/market';
import MarketCard from './MarketCard';
import { getMarketCategory, getCategoryDisplayName } from '@/lib/categorize-market';

export default function MarketList() {
  const [markets, setMarkets] = useState<Market[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState<'all' | 'open' | 'closed'>('open');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const fetchMarkets = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      const params = new URLSearchParams({
        limit: '200',
      });

      if (filter !== 'all') {
        params.append('status', filter);
      }

      const response = await fetch(`/api/markets?${params}`);

      if (!response.ok) {
        throw new Error('Failed to fetch markets');
      }

      const data = await response.json();
      setMarkets(data.markets || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setLoading(false);
    }
  }, [filter]);

  useEffect(() => {
    fetchMarkets();
  }, [fetchMarkets]);

  // Extract unique categories and create a mapping for display names
  const categories = useMemo(() => {
    const categorySet = new Set<string>();
    markets.forEach((market) => {
      const category = getMarketCategory(market);
      categorySet.add(category);
    });
    return ['all', ...Array.from(categorySet).sort()];
  }, [markets]);

  // Filter markets by category
  const filteredMarkets = useMemo(() => {
    if (selectedCategory === 'all') {
      return markets;
    }
    return markets.filter((market) => getMarketCategory(market) === selectedCategory);
  }, [markets, selectedCategory]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
          className="w-12 h-12 border-4 border-primary-500 border-t-transparent rounded-full"
        />
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="text-red-500 text-lg font-semibold mb-2">Error</div>
          <div className="text-gray-600">{error}</div>
          <button
            onClick={fetchMarkets}
            className="mt-4 px-4 py-2 bg-primary-500 text-white rounded-lg hover:bg-primary-600 transition-colors"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Status Filters */}
      <div className="flex flex-wrap gap-3">
        {['all', 'open', 'closed'].map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f as typeof filter)}
            className={`px-4 py-2 rounded-lg font-medium transition-all ${
              filter === f
                ? 'bg-primary-500 text-white shadow-lg shadow-primary-500/30'
                : 'bg-white text-gray-600 hover:bg-gray-50 border border-gray-200'
            }`}
          >
            {f === 'open' ? 'Active' : f.charAt(0).toUpperCase() + f.slice(1)}
          </button>
        ))}
      </div>

      {/* Category Filters */}
      {categories.length > 1 && (
        <div>
          <h3 className="text-sm font-semibold text-gray-700 mb-3">Categories</h3>
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <motion.button
                key={category}
                onClick={() => setSelectedCategory(category)}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                  selectedCategory === category
                    ? 'bg-primary-500 text-white shadow-md'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {getCategoryDisplayName(category)}
                {category !== 'all' && (
                  <span className="ml-2 text-xs opacity-75">
                    ({markets.filter((m) => getMarketCategory(m) === category).length})
                  </span>
                )}
              </motion.button>
            ))}
          </div>
        </div>
      )}

      {/* Market Count */}
      <div className="flex justify-between items-center">
        <p className="text-sm text-gray-600">
          Showing <span className="font-semibold text-gray-900">{filteredMarkets.length}</span> market{filteredMarkets.length !== 1 ? 's' : ''}
        </p>
      </div>

      {/* Markets Grid */}
      {filteredMarkets.length === 0 ? (
        <div className="text-center py-12 text-gray-500">
          No markets found
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredMarkets.map((market, index) => (
            <MarketCard key={market.ticker} market={market} index={index} />
          ))}
        </div>
      )}
    </div>
  );
}
