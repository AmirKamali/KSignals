'use client';

import { motion } from 'framer-motion';
import { Market } from '@/types/market';
import { getMarketCategory } from '@/lib/categorize-market';

interface MarketCardProps {
  market: Market;
  index: number;
}

export default function MarketCard({ market, index }: MarketCardProps) {
  const priceChange = market.last_price - market.previous_price;
  const priceChangePercent = market.previous_price !== 0
    ? ((priceChange / market.previous_price) * 100).toFixed(2)
    : '0.00';
  const isPositive = priceChange >= 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.05 }}
      whileHover={{ scale: 1.02, boxShadow: '0 10px 30px rgba(34, 197, 94, 0.2)' }}
      className="bg-white rounded-xl p-6 shadow-lg border border-gray-100 hover:border-primary-300 transition-all cursor-pointer"
    >
      {/* Header */}
      <div className="flex justify-between items-start mb-4">
        <div className="flex-1">
          <div className="mb-2">
            <span className="inline-block px-2 py-1 rounded-md text-xs font-medium bg-primary-50 text-primary-700">
              {getMarketCategory(market)}
            </span>
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-1">
            {market.title || market.yes_sub_title}
          </h3>
          <p className="text-sm text-gray-500">{market.subtitle}</p>
        </div>
        <div className="ml-4">
          <span className={`px-3 py-1 rounded-full text-xs font-medium ${
            market.status === 'open'
              ? 'bg-primary-100 text-primary-700'
              : 'bg-gray-100 text-gray-600'
          }`}>
            {market.status}
          </span>
        </div>
      </div>

      {/* Odds Section */}
      <div className="grid grid-cols-2 gap-4 mb-4">
        <div className="bg-gradient-to-br from-primary-50 to-primary-100 rounded-lg p-4">
          <div className="text-xs font-medium text-primary-700 mb-1">YES</div>
          <div className="text-2xl font-bold text-primary-900">
            {market.yes_bid}¢
          </div>
          <div className="text-xs text-primary-600 mt-1">
            Bid: {market.yes_bid}¢ | Ask: {market.yes_ask}¢
          </div>
        </div>

        <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg p-4">
          <div className="text-xs font-medium text-gray-700 mb-1">NO</div>
          <div className="text-2xl font-bold text-gray-900">
            {market.no_bid}¢
          </div>
          <div className="text-xs text-gray-600 mt-1">
            Bid: {market.no_bid}¢ | Ask: {market.no_ask}¢
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="grid grid-cols-3 gap-3 pt-4 border-t border-gray-100">
        <div>
          <div className="text-xs text-gray-500 mb-1">Last Price</div>
          <div className="flex items-center gap-1">
            <span className="text-sm font-semibold text-gray-900">
              {market.last_price}¢
            </span>
            <span className={`text-xs font-medium ${
              isPositive ? 'text-primary-600' : 'text-red-600'
            }`}>
              {isPositive ? '+' : ''}{priceChangePercent}%
            </span>
          </div>
        </div>

        <div>
          <div className="text-xs text-gray-500 mb-1">Volume 24h</div>
          <div className="text-sm font-semibold text-gray-900">
            {market.volume_24h.toLocaleString()}
          </div>
        </div>

        <div>
          <div className="text-xs text-gray-500 mb-1">Liquidity</div>
          <div className="text-sm font-semibold text-gray-900">
            ${market.liquidity_dollars.toLocaleString()}
          </div>
        </div>
      </div>

      {/* Ticker */}
      <div className="mt-3 pt-3 border-t border-gray-100">
        <span className="text-xs font-mono text-gray-400">{market.ticker}</span>
      </div>
    </motion.div>
  );
}
