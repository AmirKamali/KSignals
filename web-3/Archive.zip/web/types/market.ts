export interface Market {
  ticker: string;
  event_ticker: string;
  market_type: 'binary' | 'scalar';
  title: string;
  subtitle: string;
  yes_sub_title: string;
  no_sub_title: string;
  open_time: string;
  close_time: string;
  expiration_time: string;
  status: string;
  yes_bid: number;
  yes_bid_dollars: number;
  yes_ask: number;
  yes_ask_dollars: number;
  no_bid: number;
  no_bid_dollars: number;
  no_ask: number;
  no_ask_dollars: number;
  last_price: number;
  last_price_dollars: number;
  previous_price: number;
  previous_price_dollars: number;
  volume: number;
  volume_24h: number;
  liquidity: number;
  liquidity_dollars: number;
  open_interest: number;
  category: string;
  result?: string;
  can_close_early: boolean;
}

export interface GetMarketsResponse {
  markets: Market[];
  cursor?: string;
}

export interface MarketFilters {
  event_ticker?: string;
  series_ticker?: string;
  max_close_ts?: number;
  min_close_ts?: number;
  status?: string;
  tickers?: string;
  limit?: number;
  cursor?: string;
}
