const API_BASE_URL = 'http://localhost:5137/api/signals';

export interface Market {
  ticker: string;
  event_ticker: string;
  title: string;
  subtitle: string;
  yes_bid: number;
  yes_ask: number;
  volume: number;
  open_interest: number;
  liquidity: number;
}

export interface Signal {
  id: number;
  marketTicker: string;
  tradeTitle: string;
  odds: number;
  winningPercentage: number;
  analysis: string;
  createdAt: string;
}

export interface TradeDetailsResponse {
  market: Market;
  signal: Signal;
}

export async function getMarkets(limit: number = 100): Promise<Market[]> {
  const res = await fetch(`${API_BASE_URL}/markets`);
  if (!res.ok) throw new Error('Failed to fetch markets');
  return res.json();
}

export async function getTopVolumeMarkets(): Promise<Market[]> {
  const res = await fetch(`${API_BASE_URL}/top-volume`);
  if (!res.ok) throw new Error('Failed to fetch top markets');
  return res.json();
}

export async function getTradeDetails(ticker: string): Promise<TradeDetailsResponse> {
  const res = await fetch(`${API_BASE_URL}/trade/${ticker}`);
  if (!res.ok) throw new Error('Failed to fetch trade details');
  return res.json();
}
