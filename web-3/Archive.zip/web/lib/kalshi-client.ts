import * as crypto from 'crypto';
import * as fs from 'fs';
import * as path from 'path';

interface KalshiConfig {
  apiBaseUrl: string;
  accessKeyId: string;
  privateKeyPath?: string;
  privateKey?: string;
}

export class KalshiClient {
  private config: KalshiConfig;
  private privateKey: string;

  constructor(config: KalshiConfig) {
    this.config = config;

    // Load private key
    if (config.privateKey) {
      this.privateKey = config.privateKey;
    } else if (config.privateKeyPath) {
      const keyPath = path.resolve(process.cwd(), config.privateKeyPath);
      this.privateKey = fs.readFileSync(keyPath, 'utf-8');
    } else {
      throw new Error('Either privateKey or privateKeyPath must be provided');
    }
  }

  private generateSignature(method: string, path: string, body: string = ''): {
    timestamp: string;
    signature: string;
  } {
    const timestampMs = Date.now();
    const timestampStr = timestampMs.toString();

    // Create the message to sign: timestamp + method + path + body
    const message = timestampStr + method + path + body;

    // Sign with RSA-SHA256
    const sign = crypto.createSign('RSA-SHA256');
    sign.update(message);
    const signature = sign.sign(this.privateKey, 'base64');

    return {
      timestamp: timestampStr,
      signature: signature,
    };
  }

  async request<T>(
    endpoint: string,
    options: {
      method?: string;
      body?: any;
      params?: Record<string, any>;
    } = {}
  ): Promise<T> {
    const method = options.method || 'GET';
    // Remove leading slash from endpoint if present to properly join with base URL
    const cleanEndpoint = endpoint.startsWith('/') ? endpoint.slice(1) : endpoint;
    const baseUrl = this.config.apiBaseUrl.endsWith('/') ? this.config.apiBaseUrl : this.config.apiBaseUrl + '/';
    const url = new URL(cleanEndpoint, baseUrl);

    // Add query parameters
    if (options.params) {
      Object.entries(options.params).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          url.searchParams.append(key, String(value));
        }
      });
    }

    const path = url.pathname + url.search;
    const body = options.body ? JSON.stringify(options.body) : '';

    // Generate signature
    const { timestamp, signature } = this.generateSignature(method, path, body);

    const headers: Record<string, string> = {
      'KALSHI-ACCESS-KEY': this.config.accessKeyId,
      'KALSHI-ACCESS-SIGNATURE': signature,
      'KALSHI-ACCESS-TIMESTAMP': timestamp,
      'Content-Type': 'application/json',
    };

    const response = await fetch(url.toString(), {
      method,
      headers,
      body: body || undefined,
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Kalshi API error (${response.status}): ${errorText}`);
    }

    return response.json();
  }

  // Market endpoints
  async getMarkets(filters?: {
    event_ticker?: string;
    series_ticker?: string;
    max_close_ts?: number;
    min_close_ts?: number;
    status?: string;
    tickers?: string;
    limit?: number;
    cursor?: string;
  }) {
    return this.request('/markets', {
      method: 'GET',
      params: filters,
    });
  }

  async getMarket(ticker: string) {
    return this.request(`/markets/${ticker}`, {
      method: 'GET',
    });
  }

  async getEvents(filters?: {
    limit?: number;
    cursor?: string;
    status?: string;
    series_ticker?: string;
  }) {
    return this.request('/events', {
      method: 'GET',
      params: filters,
    });
  }
}

// Singleton instance
let kalshiClient: KalshiClient | null = null;

export function getKalshiClient(): KalshiClient {
  if (!kalshiClient) {
    kalshiClient = new KalshiClient({
      apiBaseUrl: process.env.KALSHI_API_BASE_URL || '',
      accessKeyId: process.env.KALSHI_ACCESS_KEY_ID || '',
      privateKeyPath: process.env.KALSHI_PRIVATE_KEY_PATH,
      privateKey: process.env.KALSHI_PRIVATE_KEY,
    });
  }
  return kalshiClient;
}
