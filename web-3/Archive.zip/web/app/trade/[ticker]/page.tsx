import { getTradeDetails } from '../../../lib/api';
import Link from 'next/link';
import MarketTitle from '../../../components/MarketTitle';

interface PageProps {
  params: {
    ticker: string;
  };
}

export const dynamic = 'force-dynamic';

export default async function TradeDetailsPage({ params }: PageProps) {
  const { ticker } = params;
  const data = await getTradeDetails(ticker);
  const { market, signal } = data;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header / Nav */}
      <header className="bg-white border-b border-gray-200 p-4">
        <div className="container mx-auto flex justify-between items-center">
          <Link href="/" className="font-bold text-xl tracking-tight">Kalshi Signals</Link>
          <Link href="/" className="text-sm text-gray-500 hover:text-black">← Back to Markets</Link>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Header Section */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 mb-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <span className="bg-gray-100 text-gray-600 px-2 py-1 rounded text-xs font-mono">{market.ticker}</span>
                <span className="text-gray-400 text-xs uppercase tracking-wider">{market.event_ticker}</span>
              </div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                <MarketTitle title={market.title} isDetails />
              </h1>
              <p className="text-lg text-gray-600">{market.subtitle}</p>
            </div>
            <div className="flex gap-8 text-center md:text-right border-t md:border-t-0 md:border-l border-gray-100 pt-6 md:pt-0 md:pl-8">
              <div>
                <div className="text-sm text-gray-500 mb-1">Volume</div>
                <div className="text-2xl font-mono font-semibold">{market.volume.toLocaleString()}</div>
              </div>
              <div>
                <div className="text-sm text-gray-500 mb-1">Liquidity</div>
                <div className="text-2xl font-mono font-semibold">${market.liquidity.toLocaleString()}</div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Market Stats Column */}
          <div className="md:col-span-1 space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h3 className="font-bold text-gray-900 mb-4 pb-2 border-b border-gray-100">Current Market</h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Yes Bid</span>
                  <span className="font-mono font-bold text-green-600">{market.yes_bid}¢</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Yes Ask</span>
                  <span className="font-mono font-bold text-red-600">{market.yes_ask}¢</span>
                </div>
                <div className="flex justify-between items-center pt-2 border-t border-gray-100">
                  <span className="text-gray-600">Implied Odds</span>
                  <span className="font-mono font-bold text-gray-900">{market.yes_ask}%</span>
                </div>
              </div>
              <a 
                href={`https://kalshi.com/markets/${market.ticker}`} 
                target="_blank" 
                rel="noopener noreferrer"
                className="mt-6 block w-full bg-black text-white text-center py-3 rounded-lg font-bold hover:bg-gray-800 transition-colors"
              >
                Trade on Kalshi
              </a>
            </div>
          </div>

          {/* Predictions Column */}
          <div className="md:col-span-2 space-y-6">
            
            {/* AI Prediction Card */}
            <div className="bg-gradient-to-br from-indigo-900 to-blue-800 text-white rounded-xl shadow-lg overflow-hidden">
              <div className="p-6 border-b border-white/10">
                <h2 className="text-xl font-bold flex items-center gap-2">
                  <svg className="w-5 h-5 text-yellow-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>
                  Kalshi Signal Predictions
                </h2>
              </div>
              <div className="p-6 grid md:grid-cols-2 gap-8">
                <div>
                  <div className="text-indigo-200 text-sm mb-1">Predicted Win Probability</div>
                  <div className="text-5xl font-bold text-white mb-2">{signal.winningPercentage}%</div>
                  <div className="flex items-center gap-2">
                     <div className={`h-2 flex-grow rounded-full bg-black/30 overflow-hidden`}>
                        <div className="h-full bg-yellow-400" style={{ width: `${signal.winningPercentage}%` }}></div>
                     </div>
                  </div>
                </div>
                <div>
                   <div className="text-indigo-200 text-sm mb-1">Calculated True Odds</div>
                   <div className="text-3xl font-bold text-white mb-4">{signal.odds}</div>
                   <div className="text-sm text-indigo-100 bg-white/10 p-3 rounded-lg">
                     Created {new Date(signal.createdAt).toLocaleTimeString()}
                   </div>
                </div>
              </div>
              <div className="px-6 pb-6">
                <div className="bg-white/5 rounded-lg p-4 border border-white/10">
                  <h3 className="text-sm font-bold text-indigo-200 mb-2 uppercase tracking-wider">AI Analysis</h3>
                  <p className="text-indigo-50 leading-relaxed">
                    {signal.analysis}
                  </p>
                </div>
              </div>
            </div>

            {/* Additional Stats (Mock) */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h3 className="font-bold text-gray-900 mb-4">Historical Performance</h3>
              <div className="h-48 bg-gray-50 rounded flex items-center justify-center text-gray-400">
                 Chart Placeholder
              </div>
            </div>

          </div>
        </div>
      </main>
    </div>
  );
}
