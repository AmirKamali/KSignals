import { NextRequest, NextResponse } from 'next/server';
import { getKalshiClient } from '@/lib/kalshi-client';
import { GetMarketsResponse, MarketFilters } from '@/types/market';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;

    const filters: MarketFilters = {
      event_ticker: searchParams.get('event_ticker') || undefined,
      series_ticker: searchParams.get('series_ticker') || undefined,
      status: searchParams.get('status') || undefined,
      tickers: searchParams.get('tickers') || undefined,
      limit: searchParams.get('limit') ? parseInt(searchParams.get('limit')!) : 100,
      cursor: searchParams.get('cursor') || undefined,
    };

    const client = getKalshiClient();
    const data = await client.getMarkets(filters);

    return NextResponse.json(data);
  } catch (error) {
    console.error('Error fetching markets:', error);
    return NextResponse.json(
      { error: 'Failed to fetch markets', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}
