import Hero from '../components/Hero';
import TopTrades from '../components/TopTrades';
import MarketTable from '../components/MarketTable';
import { getMarkets, getTopVolumeMarkets } from '../lib/api';

// Force dynamic rendering so we get fresh data
export const dynamic = 'force-dynamic';

export default async function Home() {
  // Fetch data server-side
  const [markets, topMarkets] = await Promise.all([
    getMarkets(100),
    getTopVolumeMarkets()
  ]);

  return (
    <main className="min-h-screen bg-white font-sans">
      <Hero />
      <TopTrades markets={topMarkets} />
      <MarketTable markets={markets} />
      
      <footer className="bg-gray-900 text-gray-400 py-12 text-center text-sm">
        <p>© 2025 Kalshi Signals. Not affiliated with Kalshi.</p>
      </footer>
    </main>
  );
}
