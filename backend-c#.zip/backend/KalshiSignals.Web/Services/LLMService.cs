using System;
using System.Threading.Tasks;
using KalshiSignals.Web.Models;

namespace KalshiSignals.Web.Services
{
    public class LLMService
    {
        private readonly Random _random = new Random();

        public async Task<Signal> AnalyzeMarketAsync(string ticker, string title, double currentPrice)
        {
            // Simulate LLM processing time
            await Task.Delay(500);

            // Mock logic
            var winningChance = currentPrice / 100.0; 
            // Add some "insight" variation
            var variation = (_random.NextDouble() * 0.1) - 0.05; // +/- 5%
            var predictedChance = Math.Clamp(winningChance + variation, 0.01, 0.99);
            
            var signal = new Signal
            {
                MarketTicker = ticker,
                TradeTitle = title,
                Odds = Math.Round(predictedChance * 100, 1), // as percentage
                WinningPercentage = Math.Round(predictedChance * 100, 1),
                Analysis = GenerateMockAnalysis(title, predictedChance),
                CreatedAt = DateTime.UtcNow
            };

            return signal;
        }

        private string GenerateMockAnalysis(string title, double chance)
        {
            var sentiment = chance > 0.5 ? "bullish" : "bearish";
            var confidence = chance > 0.7 || chance < 0.3 ? "High" : "Moderate";
            
            return $"Based on recent news and volume analysis for '{title}', our models indicate a {sentiment} trend with {confidence} confidence. " +
                   $"Key factors include market volatility and historical settlement data. " +
                   $"Projected winning probability is {chance:P1}.";
        }
    }
}

