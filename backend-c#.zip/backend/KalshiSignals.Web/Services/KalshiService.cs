using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace KalshiSignals.Web.Services
{
    public class KalshiService
    {
        private readonly HttpClient _httpClient;
        private readonly IConfiguration _configuration;
        private readonly ILogger<KalshiService> _logger;
        private readonly string _baseUrl;
        private readonly string _keyId;
        private readonly RSA _rsa;

        public KalshiService(HttpClient httpClient, IConfiguration configuration, ILogger<KalshiService> logger)
        {
            _httpClient = httpClient;
            _configuration = configuration;
            _logger = logger;

            _baseUrl = _configuration["Kalshi:BaseUrl"];
            _keyId = _configuration["Kalshi:KeyId"];
            var privateKeyPath = _configuration["Kalshi:PrivateKeyPath"];

            // Load Private Key
            _rsa = RSA.Create();
            // Resolve path relative to content root or execution? 
            // Assuming relative to where the app runs (backend/KalshiSignals.Web) -> ../../Market.txt
            // However, safer to use absolute or check existence.
            if (File.Exists(privateKeyPath))
            {
                var pem = File.ReadAllText(privateKeyPath);
                _rsa.ImportFromPem(pem);
            }
            else
            {
                // Try resolving relative to project root
                var path = Path.Combine(Directory.GetCurrentDirectory(), privateKeyPath);
                if (File.Exists(path))
                {
                    var pem = File.ReadAllText(path);
                    _rsa.ImportFromPem(pem);
                }
                else
                {
                    _logger.LogWarning($"Private key not found at {privateKeyPath} or {path}");
                }
            }
        }

        public async Task<List<Market>> GetMarketsAsync(int limit = 100)
        {
             // Endpoint: /markets
             // Filter by status=open
             var request = CreateRequest(HttpMethod.Get, "/markets?limit=" + limit + "&status=open");
             var response = await _httpClient.SendAsync(request);
             
             if (!response.IsSuccessStatusCode)
             {
                 _logger.LogError($"Error fetching markets: {response.StatusCode}");
                 var errorContent = await response.Content.ReadAsStringAsync();
                 _logger.LogError(errorContent);
                 return new List<Market>();
             }

             var content = await response.Content.ReadAsStringAsync();
             var result = JsonConvert.DeserializeObject<MarketsResponse>(content);
             return result?.Markets ?? new List<Market>();
        }
        
        public async Task<Market> GetMarketAsync(string ticker)
        {
             var request = CreateRequest(HttpMethod.Get, $"/markets/{ticker}");
             var response = await _httpClient.SendAsync(request);
             
             if (!response.IsSuccessStatusCode)
             {
                 return null;
             }

             var content = await response.Content.ReadAsStringAsync();
             // The response for single market might be wrapped
             var result = JsonConvert.DeserializeObject<MarketResponse>(content);
             return result?.Market;
        }

        private HttpRequestMessage CreateRequest(HttpMethod method, string path)
        {
            // Remove base url from path if present for signing
            var uri = new Uri(_baseUrl + path);
            var pathAndQuery = uri.PathAndQuery; // /trade-api/v2/markets...

            var timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds().ToString();
            var msg = timestamp + method.Method.ToUpper() + pathAndQuery;
            
            // For GET there is no body. If POST, add body string.
            
            var signatureBytes = _rsa.SignData(Encoding.UTF8.GetBytes(msg), HashAlgorithmName.SHA256, RSASignaturePadding.Pss);
            var signature = Convert.ToBase64String(signatureBytes);

            var request = new HttpRequestMessage(method, uri);
            request.Headers.Add("KALSHI-ACCESS-KEY", _keyId);
            request.Headers.Add("KALSHI-ACCESS-SIGNATURE", signature);
            request.Headers.Add("KALSHI-ACCESS-TIMESTAMP", timestamp);
            
            return request;
        }
    }

    // Models for API Response
    public class MarketsResponse
    {
        [JsonProperty("markets")]
        public List<Market> Markets { get; set; }
    }
    
    public class MarketResponse
    {
         [JsonProperty("market")]
         public Market Market { get; set; }
    }

    public class Market
    {
        [JsonProperty("ticker")]
        public string Ticker { get; set; }

        [JsonProperty("event_ticker")]
        public string EventTicker { get; set; }

        [JsonProperty("title")]
        public string Title { get; set; }

        [JsonProperty("subtitle")]
        public string Subtitle { get; set; }
        
        [JsonProperty("yes_bid")]
        public long YesBid { get; set; }
        
        [JsonProperty("yes_ask")]
        public long YesAsk { get; set; }

        [JsonProperty("volume")]
        public long Volume { get; set; }
        
        [JsonProperty("open_interest")]
        public long OpenInterest { get; set; }

        [JsonProperty("liquidity")]
        public long Liquidity { get; set; }
        
        // Odds can be inferred from yes_bid / yes_ask (price in cents)
        // Price 1-99 cents.
    }
}

