import { NextRequest, NextResponse } from 'next/server';
import { getKalshiClient } from '@/lib/kalshi-client';

export const dynamic = 'force-dynamic';

export async function GET(
  request: NextRequest,
  { params }: { params: { ticker: string } }
) {
  try {
    const client = getKalshiClient();
    const data = await client.getMarket(params.ticker);

    return NextResponse.json(data);
  } catch (error) {
    console.error('Error fetching market:', error);
    return NextResponse.json(
      { error: 'Failed to fetch market', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}
