# Kalshi Signals

A modern, real-time dashboard for viewing Kalshi prediction market data with live odds, volume, and liquidity tracking.

## Features

- 🔴 **Live Market Data**: Real-time updates from Kalshi API
- 📊 **Market Cards**: Beautiful cards showing YES/NO odds, bid/ask spreads
- 🎨 **Modern UI**: Clean white theme with green accents using Tailwind CSS
- ✨ **Smooth Animations**: Framer Motion for buttery-smooth interactions
- 🏗️ **Scalable Architecture**: Clean service layer pattern with TypeScript
- 🔐 **Secure Authentication**: RSA-SHA256 signature-based API authentication

## Tech Stack

- **Framework**: Next.js 14 (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS
- **Animations**: Framer Motion
- **API**: Kalshi Trade API v2

## Getting Started

### Prerequisites

- Node.js 18+ and npm
- Kalshi API credentials (access key ID and private key)

### Installation

1. Install dependencies:
```bash
npm install
```

2. Environment variables are already configured in `.env.local`:
```env
KALSHI_API_BASE_URL=https://api.elections.kalshi.com/trade-api/v2
KALSHI_ACCESS_KEY_ID=7be80ee6-6dcd-4274-b7c3-14030b982f90
KALSHI_PRIVATE_KEY_PATH=../Market.txt
```

3. Ensure your private key file (`Market.txt`) exists in the parent directory

4. Run the development server:
```bash
npm run dev
```

5. Open [http://localhost:3000](http://localhost:3000) in your browser

The app will load and display **active markets by default**. You can switch between All, Active, and Closed using the filter buttons.

## Project Structure

```
web/
├── app/
│   ├── api/
│   │   └── markets/          # API routes for market data
│   ├── layout.tsx            # Root layout
│   ├── page.tsx              # Home page
│   └── globals.css           # Global styles
├── components/
│   ├── MarketCard.tsx        # Individual market card component
│   └── MarketList.tsx        # Market list with filters
├── lib/
│   └── kalshi-client.ts      # Kalshi API client service layer
├── types/
│   └── market.ts             # TypeScript type definitions
└── public/                   # Static assets
```

## Architecture

### API Service Layer

The `KalshiClient` class in `lib/kalshi-client.ts` provides a clean abstraction for the Kalshi API:

- **Authentication**: Automatic RSA-SHA256 signature generation
- **Type Safety**: Full TypeScript support
- **Singleton Pattern**: Single client instance across the app
- **Error Handling**: Consistent error handling with detailed messages

### API Routes

Next.js API routes act as a secure backend proxy:

- `/api/markets` - Get all markets with filters
- `/api/markets/[ticker]` - Get specific market details

This keeps API credentials server-side and prevents CORS issues.

### Component Architecture

- **MarketList**: Fetches data, handles loading/error states, provides filtering
- **MarketCard**: Displays individual market with animations and odds
- All components use TypeScript for type safety

## Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm start` - Start production server
- `npm run lint` - Run ESLint

## API Documentation

For more information about the Kalshi API:
- [Kalshi API Documentation](https://docs.kalshi.com)
- [API Reference](https://docs.kalshi.com/reference/api-keys)

## License

Private project - All rights reserved
