import { Market } from '@/types/market';

export function getMarketCategory(market: Market): string {
  // If category is already set, use it
  if (market.category && market.category.trim()) {
    return market.category;
  }

  // Otherwise, derive category from ticker/event_ticker
  const ticker = market.event_ticker?.toUpperCase() || market.ticker?.toUpperCase() || '';

  // Sports categories
  if (ticker.includes('NFL') || ticker.includes('FOOTBALL')) return 'Sports - NFL';
  if (ticker.includes('NBA') || ticker.includes('BASKETBALL')) return 'Sports - NBA';
  if (ticker.includes('MLB') || ticker.includes('BASEBALL')) return 'Sports - MLB';
  if (ticker.includes('NHL') || ticker.includes('HOCKEY')) return 'Sports - NHL';
  if (ticker.includes('FIFA') || ticker.includes('SOCCER')) return 'Sports - Soccer';
  if (ticker.includes('TENNIS')) return 'Sports - Tennis';
  if (ticker.includes('GOLF')) return 'Sports - Golf';
  if (ticker.includes('UFC') || ticker.includes('MMA')) return 'Sports - Combat';

  // Politics categories
  if (ticker.includes('PRES') || ticker.includes('ELECTION') || ticker.includes('CONGRESS')) return 'Politics';
  if (ticker.includes('SENATE') || ticker.includes('GOVERNOR')) return 'Politics';

  // Economics/Finance
  if (ticker.includes('ECON') || ticker.includes('GDP') || ticker.includes('INFLATION')) return 'Economics';
  if (ticker.includes('FED') || ticker.includes('RATE')) return 'Economics';
  if (ticker.includes('STOCK') || ticker.includes('SPX') || ticker.includes('DOW')) return 'Finance';
  if (ticker.includes('BTC') || ticker.includes('ETH') || ticker.includes('CRYPTO')) return 'Crypto';

  // Entertainment
  if (ticker.includes('OSCAR') || ticker.includes('EMMY') || ticker.includes('GRAMMY')) return 'Entertainment';
  if (ticker.includes('MOVIE') || ticker.includes('BOX OFFICE')) return 'Entertainment';
  if (ticker.includes('MUSIC')) return 'Entertainment';

  // Science & Tech
  if (ticker.includes('SPACE') || ticker.includes('NASA') || ticker.includes('SPACEX')) return 'Science & Tech';
  if (ticker.includes('AI') || ticker.includes('TECH')) return 'Science & Tech';

  // Weather
  if (ticker.includes('WEATHER') || ticker.includes('HURRICANE') || ticker.includes('TEMP')) return 'Weather';

  // Default
  return 'Other';
}

export function getCategoryDisplayName(category: string): string {
  if (category === 'all') return 'All Markets';

  const displayMap: Record<string, string> = {
    'Sports - NFL': '🏈 NFL',
    'Sports - NBA': '🏀 NBA',
    'Sports - MLB': '⚾ MLB',
    'Sports - NHL': '🏒 NHL',
    'Sports - Soccer': '⚽ Soccer',
    'Sports - Tennis': '🎾 Tennis',
    'Sports - Golf': '⛳ Golf',
    'Sports - Combat': '🥊 Combat Sports',
    'Politics': '🏛️ Politics',
    'Economics': '📈 Economics',
    'Finance': '💰 Finance',
    'Crypto': '₿ Crypto',
    'Entertainment': '🎬 Entertainment',
    'Science & Tech': '🔬 Science & Tech',
    'Weather': '🌤️ Weather',
    'Other': '📊 Other',
  };

  return displayMap[category] || category;
}
