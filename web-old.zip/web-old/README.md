# Kalshi Signals

Modern Next.js dashboard that streams Kalshi market data, highlights odds shifts, and keeps traders focused on conviction. Built with the App Router, Tailwind CSS v4, and Framer Motion for smooth UI choreography.

## Stack

- **Next.js 16 / React 19** – App Router, server components, API routes.
- **Tailwind CSS v4** – custom theme + glassmorphism styling.
- **Framer Motion** – hero + card animations.
- **Zod-ready data layer** – repository/service split for Kalshi API access.

## Project layout

```
src/
  app/              → Route tree + API handlers
  components/       → Pure UI (layout, sections, markets)
  lib/              → Formatters & shared helpers
  server/
    config/         → Kalshi credentials & runtime config
    services/       → Low-level API client w/ request signing
    repositories/   → Domain-centric data shaping for the UI
```

This keeps secrets and fetch logic on the server while React components stay dumb and reusable.

## Getting started

```bash
cd web
cp .env.example .env.local            # fill in with your credentials
npm install
npm run dev
```

Visit `http://localhost:3000` to see the live dashboard.

> ℹ️ If credentials are missing at build time, the UI falls back to high-quality mock data so the site still compiles and designers can iterate on layout.

## Kalshi credentials

1. Set `KALSHI_ACCESS_KEY_ID` to your access key ID (the repo owner provided `7be80ee6-6dcd-4274-b7c3-14030b982f90`).
2. Provide the private key **either** inline via `KALSHI_PRIVATE_KEY="-----BEGIN..."` **or** point `KALSHI_PRIVATE_KEY_PATH` at a PEM file (the repository root’s `Market.txt` is used by default).
3. The service signs every request with RSA-PSS using the canonical `timestamp + METHOD + path + query + body` string.

> ⚠️ Never commit actual keys. Keep `.env.local` and `Market.txt` out of version control.

## Useful scripts

| Command         | Description                          |
| --------------- | ------------------------------------ |
| `npm run dev`   | Start Next.js in development mode    |
| `npm run build` | Create an optimized production build |
| `npm run lint`  | Run ESLint                           |

## Extending

- Add new repositories for other Kalshi endpoints (`events`, `positions`, etc.).
- Consume `GET /api/markets` from client components if you need incremental regeneration or polling.
- Drop in alerts/notifications by hooking into the repository output (e.g., trigger when `trend` crosses thresholds).
