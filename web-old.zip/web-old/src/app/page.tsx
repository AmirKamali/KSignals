import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { Hero } from "@/components/sections/Hero";
import { StatsBar } from "@/components/sections/StatsBar";
import { MarketBoard } from "@/components/markets/MarketBoard";
import { SignalTicker } from "@/components/sections/SignalTicker";
import { marketRepository } from "@/server/repositories/marketRepository";

export default async function Home() {
  const markets = await marketRepository.listFeaturedMarkets(27);
  const totalContracts = markets.reduce(
    (sum, market) => sum + market.volume24hContracts,
    0
  );
  const liquiditySum = markets.reduce(
    (acc, market) => acc + (market.liquidityUsd || 1),
    0
  );
  const liquidityWeightedProbability =
    liquiditySum === 0
      ? 0
      : markets.reduce(
          (acc, market) => acc + market.yesBid * (market.liquidityUsd || 1),
          0
        ) / liquiditySum;

  const signals = markets
    .slice()
    .sort((a, b) => Math.abs(b.trend) - Math.abs(a.trend))
    .slice(0, 4);

  return (
    <div className="mx-auto flex min-h-screen max-w-6xl flex-col gap-8 px-4 py-10 md:px-8 lg:py-16">
      <Header />
      <Hero />
      <StatsBar
        total={markets.length}
        avgProbability={liquidityWeightedProbability || 0}
        totalContracts={totalContracts}
      />
      <SignalTicker signals={signals} />
      <MarketBoard markets={markets} />
      <Footer />
    </div>
  );
}
