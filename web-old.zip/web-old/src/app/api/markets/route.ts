import { NextResponse } from "next/server";

import { marketRepository } from "@/server/repositories/marketRepository";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const limit = Number(searchParams.get("limit") ?? "24");

  try {
    const markets = await marketRepository.listFeaturedMarkets(limit);
    return NextResponse.json({ markets });
  } catch (error) {
    console.error("Failed to load markets", error);
    return NextResponse.json(
      { error: "Unable to fetch markets" },
      { status: 500 }
    );
  }
}
