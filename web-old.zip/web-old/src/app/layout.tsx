import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Kalshi Signals",
  description:
    "Real-time snapshot of Kalshi markets with curated odds, trends, and liquidity signals.",
  metadataBase: new URL("https://kalshi-signals.local"),
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
