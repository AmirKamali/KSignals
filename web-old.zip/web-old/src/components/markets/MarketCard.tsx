"use client";

import { motion } from "framer-motion";
import { ArrowUpRight, Clock, TrendingUp } from "lucide-react";

import type { MarketSummary } from "@/server/types/market";
import {
  formatContracts,
  formatPercent,
  formatTrend,
  formatUsd,
  formatUsdCents,
  timeUntilClose,
} from "@/lib/formatters";

type MarketCardProps = {
  market: MarketSummary;
};

export function MarketCard({ market }: MarketCardProps) {
  const yesProbability = market.yesBid || market.yesAsk;
  const noProbability = market.noBid || market.noAsk;

  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      className="group flex flex-col rounded-[1.5rem] border border-white/70 bg-white/80 p-6 shadow-[0_20px_45px_rgba(15,23,42,0.08)] backdrop-blur-xl transition hover:-translate-y-1 hover:shadow-[0_25px_55px_rgba(15,23,42,0.12)]"
    >
      <div className="flex items-center justify-between">
        <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-600">
          {market.category}
        </span>
        <span className="text-xs font-medium uppercase tracking-wide text-emerald-600">
          {market.confidenceLabel}
        </span>
      </div>

      <h3 className="mt-4 text-lg font-semibold text-slate-900">
        {market.question}
      </h3>
      <p className="text-sm text-slate-500">{market.ticker}</p>

      <div className="mt-6 grid gap-3 md:grid-cols-2">
        <MarketSideButton
          side="Yes"
          label={market.yesLabel}
          probability={yesProbability}
          bid={market.yesBid}
          ask={market.yesAsk}
          accent
        />
        <MarketSideButton
          side="No"
          label={market.noLabel}
          probability={noProbability}
          bid={market.noBid}
          ask={market.noAsk}
        />
      </div>

      <div className="mt-6 flex flex-wrap items-center gap-4 text-sm text-slate-500">
        <span className="inline-flex items-center gap-2">
          <Clock className="h-4 w-4 text-slate-400" />
          {timeUntilClose(market.closeTime)}
        </span>
        <span className="inline-flex items-center gap-2">
          <TrendingUp className="h-4 w-4 text-slate-400" />
          {formatTrend(market.trend)}
        </span>
        <span>{formatContracts(market.volume24hContracts)} / 24h</span>
      </div>

      <section className="mt-6 flex flex-col gap-2 rounded-2xl border border-dashed border-emerald-200 bg-emerald-50/60 px-4 py-4 text-sm text-emerald-900">
        <div className="flex flex-wrap justify-between gap-4">
          <Metric label="Depth" value={formatUsd(market.liquidityUsd)} />
          <Metric
            label="Open interest"
            value={formatContracts(market.openInterestContracts)}
          />
          <Metric
            label="Contract size"
            value={`${formatUsdCents(market.notionalValue)}`}
          />
        </div>
        <a
          className="inline-flex items-center gap-2 text-sm font-semibold text-emerald-700 hover:text-emerald-800"
          href={`https://kalshi.com/markets/${market.ticker}`}
          target="_blank"
          rel="noreferrer"
        >
          Trade on Kalshi
          <ArrowUpRight className="h-4 w-4" />
        </a>
      </section>
    </motion.article>
  );
}

type SideButtonProps = {
  side: "Yes" | "No";
  label: string;
  probability: number;
  bid: number;
  ask: number;
  accent?: boolean;
};

function MarketSideButton({
  side,
  label,
  probability,
  bid,
  ask,
  accent,
}: SideButtonProps) {
  const cleanedLabel = normalizeSideLabel(label, side);

  return (
    <button
      type="button"
      className={`rounded-2xl border px-4 py-4 text-left transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 ${
        accent
          ? "border-emerald-500 bg-emerald-600/90 text-white hover:bg-emerald-600 focus-visible:outline-emerald-700"
          : "border-slate-200 bg-white text-slate-700 hover:border-slate-300 focus-visible:outline-slate-400"
      }`}
      aria-label={`${side} position: ${cleanedLabel}`}
    >
      <div className="flex items-center justify-between">
        <span
          className={`text-xs font-semibold uppercase ${
            accent ? "text-white/70" : "text-slate-500"
          }`}
        >
          {side} side
        </span>
        <span className="text-2xl font-semibold">
          {probability ? formatPercent(probability) : "—"}
        </span>
      </div>
      <p
        className={`mt-2 text-sm leading-snug ${
          accent ? "text-white/90" : "text-slate-600"
        } line-clamp-2`}
      >
        {cleanedLabel}
      </p>
      <div
        className={`mt-4 flex justify-between text-xs font-semibold ${
          accent ? "text-white" : "text-slate-500"
        }`}
      >
        <span>
          Bid{" "}
          <strong>{bid ? formatUsdCents(bid) : "—"}</strong>
        </span>
        <span>
          Ask{" "}
          <strong>{ask ? formatUsdCents(ask) : "—"}</strong>
        </span>
      </div>
    </button>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-xs font-semibold uppercase tracking-wide text-emerald-600">
        {label}
      </p>
      <p className="text-base font-semibold">{value}</p>
    </div>
  );
}

function normalizeSideLabel(label: string, side: "Yes" | "No"): string {
  if (!label) {
    return side === "Yes" ? "Bet on YES" : "Bet on NO";
  }

  const segments = label.split(/[,|]/).map((segment) => segment.trim());
  const desiredPrefix = side.toLowerCase();
  const candidate =
    segments.find((segment) =>
      segment.toLowerCase().startsWith(desiredPrefix)
    ) ?? segments[0];

  const cleaned = candidate.replace(/^(yes|no)\s+/i, "").trim();
  return cleaned || (side === "Yes" ? "Bet on YES" : "Bet on NO");
}
