"use client";

import { useMemo, useState } from "react";
import { motion } from "framer-motion";

import type { MarketSummary } from "@/server/types/market";
import { MarketCard } from "@/components/markets/MarketCard";

type MarketBoardProps = {
  markets: MarketSummary[];
};

export function MarketBoard({ markets }: MarketBoardProps) {
  const categories = useMemo(() => {
    const unique = Array.from(new Set(markets.map((m) => m.category))).sort();
    return ["All", ...unique];
  }, [markets]);

  const [activeCategory, setActiveCategory] = useState("All");

  const filtered = useMemo(() => {
    if (activeCategory === "All") {
      return markets;
    }
    return markets.filter((market) => market.category === activeCategory);
  }, [activeCategory, markets]);

  return (
    <section id="now" className="space-y-6">
      <div className="flex flex-wrap gap-2">
        {categories.map((category) => (
          <button
            key={category}
            type="button"
            onClick={() => setActiveCategory(category)}
            className={`rounded-full px-4 py-2 text-sm font-medium transition ${
              activeCategory === category
                ? "bg-slate-900 text-white shadow-lg shadow-slate-900/20"
                : "bg-white/80 text-slate-600 hover:bg-white"
            }`}
          >
            {category}
          </button>
        ))}
      </div>

      <motion.div
        layout
        className="grid gap-6 md:grid-cols-2 xl:grid-cols-3"
        id="focus"
      >
        {filtered.map((market) => (
          <MarketCard key={market.ticker} market={market} />
        ))}
      </motion.div>
    </section>
  );
}
