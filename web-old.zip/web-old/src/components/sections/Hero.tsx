"use client";

import { motion } from "framer-motion";

export function Hero() {
  return (
    <section className="relative overflow-hidden rounded-[2.25rem] border border-white/80 bg-white/90 p-10 shadow-[0_40px_120px_rgba(15,23,42,0.12)] backdrop-blur-xl">
      <motion.div
        initial={{ opacity: 0, y: 18 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-6"
      >
        <span className="inline-flex items-center gap-2 rounded-full border border-emerald-100 bg-emerald-50 px-4 py-1 text-xs font-semibold text-emerald-700">
          <span className="h-2 w-2 rounded-full bg-emerald-500" />
          Live Kalshi feed
        </span>
        <div className="space-y-4">
          <h1 className="text-4xl font-semibold leading-tight text-slate-900 md:text-5xl">
            Signals for every Kalshi market, curated for fast conviction.
          </h1>
          <p className="max-w-2xl text-lg text-slate-600">
            Monitor open interest, liquidity, and probability shifts across the
            exchange. Kalshi Signals distills the firehose into a sleek
            dashboard designed for elite macro and election traders.
          </p>
        </div>
        <div className="flex flex-wrap gap-3">
          <a
            href="#now"
            className="inline-flex items-center justify-center rounded-full bg-emerald-500 px-6 py-3 text-sm font-semibold text-white shadow-lg shadow-emerald-500/40 hover:bg-emerald-600"
          >
            Browse live markets
          </a>
          <a
            href="https://docs.kalshi.com/welcome"
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center justify-center rounded-full border border-slate-200 px-6 py-3 text-sm font-semibold text-slate-700 hover:bg-slate-50"
          >
            API reference
          </a>
        </div>
      </motion.div>
      <div className="pointer-events-none absolute -right-10 -top-10 h-48 w-48 rounded-full bg-emerald-200/40 blur-3xl" />
      <div className="pointer-events-none absolute bottom-0 right-16 h-32 w-32 rounded-full bg-emerald-100/60 blur-2xl" />
    </section>
  );
}
