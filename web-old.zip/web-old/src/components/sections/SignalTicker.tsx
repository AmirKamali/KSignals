import { Sparkles } from "lucide-react";

import type { MarketSummary } from "@/server/types/market";
import { formatTrend, timeUntilClose } from "@/lib/formatters";

type SignalTickerProps = {
  signals: MarketSummary[];
};

export function SignalTicker({ signals }: SignalTickerProps) {
  return (
    <section className="rounded-[1.75rem] border border-white/70 bg-white/90 p-5 shadow-inner shadow-white/60">
      <div className="mb-4 flex items-center gap-2 text-sm font-semibold text-slate-600">
        <Sparkles className="h-4 w-4 text-emerald-500" />
        Signal tape
      </div>
      {signals.length === 0 ? (
        <p className="text-sm text-slate-500">
          No standout moves just yet. Markets will light up as soon as liquidity
          shifts.
        </p>
      ) : (
        <div className="flex flex-wrap gap-3">
          {signals.map((signal) => (
            <div
              key={signal.ticker}
              className="flex flex-col gap-1 rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm shadow-sm shadow-slate-200/60"
            >
              <span className="text-xs font-semibold uppercase text-slate-400">
                {signal.category}
              </span>
              <p className="font-semibold text-slate-800">{signal.question}</p>
              <p className="text-xs text-slate-500">
                {formatTrend(signal.trend)} · {timeUntilClose(signal.closeTime)}
              </p>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
