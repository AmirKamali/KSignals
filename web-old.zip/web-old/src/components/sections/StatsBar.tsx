import { formatContracts } from "@/lib/formatters";

type StatsBarProps = {
  total: number;
  avgProbability: number;
  totalContracts: number;
};

const Stat = ({
  label,
  value,
  helper,
}: {
  label: string;
  value: string;
  helper: string;
}) => (
  <div className="flex w-full flex-col rounded-2xl border border-white/70 bg-white/80 px-6 py-5 shadow-sm shadow-slate-200/60 backdrop-blur-md sm:w-auto">
    <span className="text-xs font-semibold uppercase tracking-wide text-emerald-600">
      {label}
    </span>
    <span className="text-2xl font-semibold text-slate-900">{value}</span>
    <span className="text-sm text-slate-500">{helper}</span>
  </div>
);

export function StatsBar({
  total,
  avgProbability,
  totalContracts,
}: StatsBarProps) {
  return (
    <section className="grid gap-4 sm:grid-cols-3">
      <Stat
        label="Tracked Markets"
        value={`${total}`}
        helper="Open Kalshi contracts streaming in"
      />
      <Stat
        label="Avg Yes Probability"
        value={`${Math.round(avgProbability * 100)}%`}
        helper="Weighted by liquidity"
      />
      <Stat
        label="24h Exchange Volume"
        value={formatContracts(totalContracts)}
        helper="Contracts traded across highlights"
      />
    </section>
  );
}
