export function Footer() {
  return (
    <footer className="mt-12 flex flex-col gap-2 text-sm text-slate-500 md:flex-row md:items-center md:justify-between">
      <p>© {new Date().getFullYear()} Kalshi Signals. Insight layer for Kalshi markets.</p>
      <p>
        Built with{" "}
        <a
          className="font-medium text-emerald-600 hover:text-emerald-700"
          href="https://kalshi.com"
          target="_blank"
          rel="noreferrer"
        >
          Kalshi Trade API
        </a>
        .
      </p>
    </footer>
  );
}
