const currency = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  maximumFractionDigits: 0,
});

const preciseCurrency = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

const percent = new Intl.NumberFormat("en-US", {
  style: "percent",
  maximumFractionDigits: 0,
});

const compactNumber = new Intl.NumberFormat("en-US", {
  notation: "compact",
  maximumFractionDigits: 1,
});

const relativeFormatter = new Intl.RelativeTimeFormat("en", {
  numeric: "auto",
});

export function formatUsd(value: number): string {
  return currency.format(value);
}

export function formatUsdCents(value: number): string {
  return preciseCurrency.format(value);
}

export function formatPercent(value: number): string {
  return percent.format(value);
}

export function formatCompactNumber(value: number): string {
  return compactNumber.format(value);
}

export function formatContracts(value: number): string {
  return `${formatCompactNumber(value)} contracts`;
}

export function formatTrend(value: number): string {
  if (value === 0) return "flat";
  const bps = Math.round(Math.abs(value) * 10000);
  const prefix = value > 0 ? "+" : "-";
  return `${prefix}${bps} bps`;
}

export function timeUntilClose(isoDate: string): string {
  const target = new Date(isoDate).getTime();
  const now = Date.now();
  const diffMs = target - now;
  const diffHours = diffMs / (1000 * 60 * 60);

  if (!Number.isFinite(diffHours)) {
    return "N/A";
  }

  if (Math.abs(diffHours) < 24) {
    return relativeFormatter.format(Math.round(diffHours), "hour");
  }

  const diffDays = diffHours / 24;
  return relativeFormatter.format(Math.round(diffDays), "day");
}
