import "server-only";

import crypto from "node:crypto";

import { getKalshiConfig, type KalshiConfig } from "@/server/config/kalshiConfig";
import type { ApiMarket, MarketQuery } from "@/server/types/market";

type GetMarketsResponse = {
  markets: ApiMarket[];
  cursor?: string | null;
};

type RequestOptions = {
  method?: "GET" | "POST" | "PUT" | "DELETE";
  body?: unknown;
  searchParams?: Record<string, string | number | boolean | undefined>;
};

export class KalshiApiService {
  constructor(private readonly config: KalshiConfig = getKalshiConfig()) {}

  async getMarkets(params: MarketQuery = {}): Promise<GetMarketsResponse> {
    return this.request("/markets", { method: "GET", searchParams: params });
  }

  private async request<T>(
    path: string,
    options: RequestOptions
  ): Promise<T> {
    const method = options.method ?? "GET";
    const bodyString =
      options.body && method !== "GET" ? JSON.stringify(options.body) : "";

    const search = buildSearchParams(options.searchParams);
    const canonicalPath = search ? `${path}?${search}` : path;
    const url = `${this.config.baseUrl}${canonicalPath}`;

    const { signature, timestamp } = this.signRequest(
      method,
      path,
      search,
      bodyString
    );

    const headers: HeadersInit = {
      Accept: "application/json",
      "User-Agent": "kalshi-signals/1.0",
      "KALSHI-ACCESS-KEY": this.config.accessKey,
      "KALSHI-ACCESS-SIGNATURE": signature,
      "KALSHI-ACCESS-TIMESTAMP": timestamp,
    };

    if (bodyString) {
      headers["Content-Type"] = "application/json";
    }

    const response = await fetch(url, {
      method,
      headers,
      body: bodyString || undefined,
      cache: "no-store",
    });

    if (!response.ok) {
      const errorBody = await response.text();
      throw new Error(
        `Kalshi request failed (${response.status}): ${errorBody || "Unknown"}`
      );
    }

    return (await response.json()) as T;
  }

  private signRequest(
    method: string,
    path: string,
    search: string,
    body: string
  ) {
    const timestamp = Date.now().toString();
    const canonical = `${timestamp}${method.toUpperCase()}${path}${
      search ? `?${search}` : ""
    }${body ?? ""}`;

    const signer = crypto.createSign("RSA-SHA256");
    signer.update(canonical);
    signer.end();

    const signature = signer.sign(this.config.privateKey, "base64");

    return { signature, timestamp };
  }
}

function buildSearchParams(
  params: RequestOptions["searchParams"]
): string {
  if (!params) {
    return "";
  }

  const search = new URLSearchParams();

  Object.entries(params).forEach(([key, value]) => {
    if (value === undefined || value === null || value === "") {
      return;
    }
    search.set(key, String(value));
  });

  return search.toString();
}
