import "server-only";

import fs from "node:fs";
import path from "node:path";

export type KalshiConfig = {
  baseUrl: string;
  accessKey: string;
  privateKey: string;
};

let cachedConfig: KalshiConfig | null = null;

export function getKalshiConfig(): KalshiConfig {
  if (cachedConfig) {
    return cachedConfig;
  }

  const baseUrl =
    process.env.KALSHI_API_BASE_URL ??
    "https://api.elections.kalshi.com/trade-api/v2";
  const accessKey = process.env.KALSHI_ACCESS_KEY_ID;
  if (!accessKey) {
    throw new Error(
      "Missing KALSHI_ACCESS_KEY_ID. Add it to .env.local before running the app."
    );
  }

  const privateKey = readPrivateKey();

  cachedConfig = {
    baseUrl,
    accessKey,
    privateKey,
  };

  return cachedConfig;
}

export function hasKalshiCredentials(): boolean {
  const accessKey = process.env.KALSHI_ACCESS_KEY_ID;
  if (!accessKey) {
    return false;
  }

  if (process.env.KALSHI_PRIVATE_KEY) {
    return true;
  }

  const keyPath =
    process.env.KALSHI_PRIVATE_KEY_PATH ??
    path.resolve(process.cwd(), "../Market.txt");

  return fs.existsSync(keyPath);
}

function readPrivateKey(): string {
  const inlineKey = process.env.KALSHI_PRIVATE_KEY;
  if (inlineKey) {
    return normalizeKey(inlineKey);
  }

  const keyPath =
    process.env.KALSHI_PRIVATE_KEY_PATH ??
    path.resolve(process.cwd(), "../Market.txt");

  if (!fs.existsSync(keyPath)) {
    throw new Error(
      `Kalshi private key not found. Provide KALSHI_PRIVATE_KEY or KALSHI_PRIVATE_KEY_PATH (expected at ${keyPath}).`
    );
  }

  return fs.readFileSync(keyPath, "utf8").toString();
}

function normalizeKey(key: string): string {
  return key.replace(/\\n/g, "\n");
}
