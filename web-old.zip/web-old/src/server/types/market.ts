export type ApiMarket = {
  ticker: string;
  event_ticker: string;
  title?: string | null;
  subtitle?: string | null;
  yes_sub_title?: string | null;
  no_sub_title?: string | null;
  category?: string | null;
  rules_primary?: string | null;
  status: string;
  close_time: string;
  latest_expiration_time: string;
  yes_bid?: number | null;
  yes_ask?: number | null;
  no_bid?: number | null;
  no_ask?: number | null;
  yes_bid_dollars?: string | null;
  yes_ask_dollars?: string | null;
  no_bid_dollars?: string | null;
  no_ask_dollars?: string | null;
  volume_24h?: number | null;
  liquidity?: number | null;
  liquidity_dollars?: string | null;
  open_interest?: number | null;
  previous_yes_bid?: number | null;
  previous_yes_bid_dollars?: string | null;
  notional_value?: number | null;
  notional_value_dollars?: string | null;
};

export type MarketQuery = {
  limit?: number;
  status?: string;
  cursor?: string;
  category?: string;
  event_ticker?: string;
  tags?: string;
};

export type MarketSummary = {
  ticker: string;
  eventTicker: string;
  question: string;
  status: string;
  category: string;
  closeTime: string;
  liquidityUsd: number;
  volume24hContracts: number;
  openInterestContracts: number;
  yesBid: number;
  yesAsk: number;
  noBid: number;
  noAsk: number;
  trend: number;
  confidenceLabel: string;
  yesLabel: string;
  noLabel: string;
  notionalValue: number;
};
