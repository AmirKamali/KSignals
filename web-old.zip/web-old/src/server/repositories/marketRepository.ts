import "server-only";

import { KalshiApiService } from "@/server/services/kalshiApiService";
import { hasKalshiCredentials } from "@/server/config/kalshiConfig";
import type { ApiMarket, MarketSummary } from "@/server/types/market";

class MarketRepository {
  constructor(private readonly api: KalshiApiService | null = resolveApi()) {}

  async listFeaturedMarkets(limit = 24): Promise<MarketSummary[]> {
    if (!this.api) {
      return fallbackMarkets.slice(0, limit);
    }

    try {
      const response = await this.api.getMarkets({
        limit,
        status: "open",
      });

      return response.markets
        .sort((a, b) => (b.liquidity ?? 0) - (a.liquidity ?? 0))
        .map((market) => this.toSummary(market));
    } catch (error) {
      console.error("Failed to fetch Kalshi markets", error);
      return fallbackMarkets.slice(0, limit);
    }
  }

  private toSummary(market: ApiMarket): MarketSummary {
    const yesBid = toNumber(market.yes_bid_dollars, market.yes_bid);
    const yesAsk = toNumber(market.yes_ask_dollars, market.yes_ask);
    const noBid = toNumber(market.no_bid_dollars, market.no_bid);
    const noAsk = toNumber(market.no_ask_dollars, market.no_ask);
    const liquidityUsd = toNumber(market.liquidity_dollars, market.liquidity);
    const previousYesBid = toNumber(
      market.previous_yes_bid_dollars,
      market.previous_yes_bid
    );
    const notionalValue = toNumber(
      market.notional_value_dollars,
      market.notional_value
    );

    const question =
      market.subtitle ||
      market.title ||
      market.yes_sub_title ||
      `Market ${market.ticker}`;

    const trend = +(yesBid - previousYesBid).toFixed(2);

    return {
      ticker: market.ticker,
      eventTicker: market.event_ticker,
      question,
      status: market.status,
      category: market.category || "General",
      closeTime: market.close_time,
      liquidityUsd,
      volume24hContracts: market.volume_24h ?? 0,
      openInterestContracts: market.open_interest ?? 0,
      yesBid,
      yesAsk,
      noBid,
      noAsk,
      trend,
      confidenceLabel: confidenceLabel(yesBid),
      yesLabel: market.yes_sub_title || "Yes side",
      noLabel: market.no_sub_title || "No side",
      notionalValue: notionalValue || 1,
    };
  }
}

function toNumber(
  dollarsValue?: string | null,
  centsValue?: number | null
): number {
  if (typeof centsValue === "number" && Number.isFinite(centsValue)) {
    return +(centsValue / 100).toFixed(2);
  }

  if (!dollarsValue) {
    return 0;
  }

  const parsed = Number(dollarsValue);
  return Number.isNaN(parsed) ? 0 : +parsed.toFixed(2);
}

function confidenceLabel(probability: number): string {
  if (probability >= 0.7) return "High conviction";
  if (probability >= 0.45) return "Balanced market";
  return "Early signal";
}

export const marketRepository = new MarketRepository();

function resolveApi(): KalshiApiService | null {
  if (!hasKalshiCredentials()) {
    return null;
  }

  try {
    return new KalshiApiService();
  } catch (error) {
    console.error("Unable to initialize Kalshi API service", error);
    return null;
  }
}

const fallbackMarkets: MarketSummary[] = [
  {
    ticker: "KSG-TRIAL-1",
    eventTicker: "KSG-TRIAL",
    question: "Will the Senate stay Democratic?",
    status: "mock",
    category: "Elections",
    closeTime: new Date(Date.now() + 1000 * 60 * 60 * 72).toISOString(),
    liquidityUsd: 250000,
    volume24hContracts: 18800,
    openInterestContracts: 92000,
    yesBid: 0.62,
    yesAsk: 0.64,
    noBid: 0.36,
    noAsk: 0.38,
    trend: 0.04,
    confidenceLabel: "High conviction",
    yesLabel: "Democrats keep the Senate",
    noLabel: "Republicans flip the Senate",
    notionalValue: 1,
  },
  {
    ticker: "KSG-TRIAL-2",
    eventTicker: "KSG-TRIAL",
    question: "Will CPI print above 3.3% this month?",
    status: "mock",
    category: "Macro",
    closeTime: new Date(Date.now() + 1000 * 60 * 60 * 24).toISOString(),
    liquidityUsd: 185000,
    volume24hContracts: 16100,
    openInterestContracts: 61000,
    yesBid: 0.41,
    yesAsk: 0.43,
    noBid: 0.57,
    noAsk: 0.59,
    trend: -0.02,
    confidenceLabel: "Balanced market",
    yesLabel: "Headline CPI > 3.3%",
    noLabel: "Headline CPI ≤ 3.3%",
    notionalValue: 1,
  },
  {
    ticker: "KSG-TRIAL-3",
    eventTicker: "KSG-TRIAL",
    question: "Will the Fed cut rates at the next meeting?",
    status: "mock",
    category: "Federal Reserve",
    closeTime: new Date(Date.now() + 1000 * 60 * 60 * 120).toISOString(),
    liquidityUsd: 210000,
    volume24hContracts: 14400,
    openInterestContracts: 48000,
    yesBid: 0.28,
    yesAsk: 0.3,
    noBid: 0.69,
    noAsk: 0.71,
    trend: 0.01,
    confidenceLabel: "Early signal",
    yesLabel: "Fed cuts in next meeting",
    noLabel: "Fed holds or hikes",
    notionalValue: 1,
  },
  {
    ticker: "KSG-TRIAL-4",
    eventTicker: "KSG-TRIAL",
    question: "Will BTC close above $90K this quarter?",
    status: "mock",
    category: "Crypto",
    closeTime: new Date(Date.now() + 1000 * 60 * 60 * 24 * 15).toISOString(),
    liquidityUsd: 98000,
    volume24hContracts: 5600,
    openInterestContracts: 20500,
    yesBid: 0.35,
    yesAsk: 0.37,
    noBid: 0.63,
    noAsk: 0.65,
    trend: -0.03,
    confidenceLabel: "Balanced market",
    yesLabel: "BTC settles > $90K",
    noLabel: "BTC settles ≤ $90K",
    notionalValue: 1,
  },
  {
    ticker: "KSG-TRIAL-5",
    eventTicker: "KSG-TRIAL",
    question: "Will unemployment tick above 4.2%?",
    status: "mock",
    category: "Labor",
    closeTime: new Date(Date.now() + 1000 * 60 * 60 * 48).toISOString(),
    liquidityUsd: 120000,
    volume24hContracts: 6700,
    openInterestContracts: 33000,
    yesBid: 0.48,
    yesAsk: 0.5,
    noBid: 0.5,
    noAsk: 0.52,
    trend: 0.015,
    confidenceLabel: "Balanced market",
    yesLabel: "Unemployment > 4.2%",
    noLabel: "Unemployment ≤ 4.2%",
    notionalValue: 1,
  },
  {
    ticker: "KSG-TRIAL-6",
    eventTicker: "KSG-TRIAL",
    question: "Will a major tech bill pass this session?",
    status: "mock",
    category: "Policy",
    closeTime: new Date(Date.now() + 1000 * 60 * 60 * 8).toISOString(),
    liquidityUsd: 64000,
    volume24hContracts: 2300,
    openInterestContracts: 12000,
    yesBid: 0.22,
    yesAsk: 0.24,
    noBid: 0.76,
    noAsk: 0.78,
    trend: -0.01,
    confidenceLabel: "Early signal",
    yesLabel: "Bill passes",
    noLabel: "Bill stalls out",
    notionalValue: 1,
  },
];
